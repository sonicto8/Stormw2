/**
 * STORMWATCH — Serviço de tempo real dos comentários da comunidade.
 *
 * Funções:
 *  1. Socket.io (path "/", porta 3010) — difunde `comment:new` a todos os
 *     clientes quando a API principal publica um comentário. O path "/" é
 *     obrigatório para o gateway (XTransformPort) encaminhar corretamente;
 *     por isso o socket.io interceta todo o tráfego desta porta.
 *     (A porta 3003 pertence ao alerts-service, ver guia PWA.)
 *  2. Porta interna 3004 (apenas 127.0.0.1) — endpoint HTTP POST /notify
 *     usado pela rota Next /api/comments para injetar novos comentários.
 *  3. Memória dos últimos 60 comentários para `comments:recent` (histórico
 *     imediato ao ligar). A fonte de verdade persistida é a base de dados
 *     Prisma da aplicação principal; este serviço só difunde.
 */
import { createServer } from 'http';
import { Server } from 'socket.io';

interface CommunityComment {
  id: string;
  nickname: string;
  message: string;
  lat: number | null;
  lon: number | null;
  placeName: string | null;
  weatherLabel: string | null;
  temperature: number | null;
  createdAt: string;
  mine?: boolean;
}

const recent: CommunityComment[] = [];

function handleNotify(req: import('http').IncomingMessage, res: import('http').ServerResponse): void {
  if (req.method !== 'POST') {
    res.writeHead(405, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: false, error: 'método não permitido' }));
    return;
  }
  let body = '';
  req.on('data', (chunk) => {
    body += chunk;
    if (body.length > 256 * 1024) req.destroy();
  });
  req.on('end', () => {
    try {
      const parsed = JSON.parse(body) as { comment?: CommunityComment };
      const comment = parsed.comment;
      if (comment && typeof comment.id === 'string' && typeof comment.message === 'string') {
        recent.push(comment);
        if (recent.length > 60) recent.shift();
        io.emit('comment:new', comment);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, clients: io.engine.clientsCount }));
        console.log(`[comment-service] difundido comentário ${comment.id}`);
      } else {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'payload inválido' }));
      }
    } catch {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: false, error: 'JSON inválido' }));
    }
  });
}

// ——— Porta interna (3004): apenas localhost, para a API principal notificar. ———
const internalServer = createServer((req, res) => {
  if (req.url === '/notify' || req.url?.startsWith('/notify?')) {
    handleNotify(req, res);
    return;
  }
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, clients: io.engine.clientsCount, buffered: recent.length }));
    return;
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ ok: false, error: 'não encontrado' }));
});

// ——— Porta pública (3003): socket.io com path "/" (exigido pelo gateway). ———
const httpServer = createServer();

const io = new Server(httpServer, {
  // DO NOT change the path, it is used by Caddy to forward the request to the correct port
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
});

io.on('connection', (socket) => {
  console.log(`[comment-service] cliente ligado: ${socket.id} (total: ${io.engine.clientsCount})`);

  // Histórico imediato ao ligar (últimos comentários em memória).
  socket.emit('comments:recent', recent.slice(-60));

  socket.on('disconnect', (reason) => {
    console.log(`[comment-service] cliente desligado: ${socket.id} (${reason})`);
  });

  socket.on('error', (error) => {
    console.error(`[comment-service] erro no socket ${socket.id}:`, error);
  });
});

const PORT = 3010;
const INTERNAL_PORT = 3004;

httpServer.listen(PORT, () => {
  console.log(`[comment-service] socket.io em tempo real na porta ${PORT} (path "/")`);
});

internalServer.listen(INTERNAL_PORT, '127.0.0.1', () => {
  console.log(`[comment-service] notificações internas em 127.0.0.1:${INTERNAL_PORT}`);
});

process.on('SIGTERM', () => {
  console.log('[comment-service] SIGTERM — a encerrar…');
  httpServer.close(() => process.exit(0));
  internalServer.close();
});

process.on('SIGINT', () => {
  console.log('[comment-service] SIGINT — a encerrar…');
  httpServer.close(() => process.exit(0));
  internalServer.close();
});
