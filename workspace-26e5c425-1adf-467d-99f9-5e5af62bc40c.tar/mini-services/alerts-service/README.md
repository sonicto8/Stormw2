# STORMWATCH alerts-service

Serviço de alertas em tempo real (Terminal 2 do guia de instalação no iPhone).
Corre na **porta 3003** e é consumido pela aplicação via gateway com
`?XTransformPort=3003`.

## O que faz

1. **Polling do IPMA a cada 5 minutos** (`warnings_www.json`), com validação
   Zod e deteção de avisos novos por diff determinístico de IDs.
2. **Web Push (VAPID)** para todos os dispositivos subscritos quando surge um
   aviso oficial novo. Subscrições guardadas em `data/subscriptions.json`.
3. **SSE** (`GET /api/stream`) para atualização instantânea dentro da app
   (eventos `alert:new` e `poll`, keep-alive a cada 25 s).
4. **Persistência** do último estado visto em `data/state.json` — depois de um
   reinício não reenvia push de avisos que já eram conhecidos.

## Endpoints

| Método | Caminho          | Descrição                                              |
| ------ | ---------------- | ------------------------------------------------------ |
| GET    | `/api/status`    | Estado do serviço + chave pública VAPID                |
| GET    | `/api/alerts`    | Avisos IPMA ativos (normalizados, iguais à app)        |
| GET    | `/api/poll`      | Força um ciclo de polling (máx. 1 por 10 s)            |
| GET    | `/api/stream`    | SSE: `alert:new`, `poll`, keep-alive                   |
| POST   | `/api/subscribe` | `{ subscription }` — guarda a subscrição Web Push      |
| POST   | `/api/unsubscribe` | `{ endpoint }` — remove a subscrição                 |
| POST   | `/api/test`      | `{ subscription? }` — envia «STORMWATCH — Notificações ativadas» |

## Configurar as chaves VAPID

As chaves VAPID são geradas localmente (não dependem de nenhum serviço
externo). Para (re)gerar:

```bash
cd mini-services/alerts-service
bunx web-push generate-vapid-keys
```

Escreve os valores num ficheiro `.env` nesta pasta:

```env
VAPID_PUBLIC_KEY=...
VAPID_PRIVATE_KEY=...
VAPID_SUBJECT=mailto:alerts@stormwatch.pt
```

**Se as chaves não estiverem definidas**, o serviço continua a funcionar
(SSE e `/api/alerts`) e a app mostra claramente
«Notificações push não configuradas» nas Definições — nunca falha em silêncio.

## Arrancar

```bash
cd mini-services/alerts-service
bun install
bun run dev
```

Saída esperada:

```
[STORMWATCH alerts-service] listening on port 3003
```

## Notas iOS (PWA)

As notificações Web Push em PWAs iOS exigem iOS 16.4+, a app instalada no
ecrã principal via Safari e aberta pelo ícone pelo menos uma vez. Mesmo assim,
o iOS só entrega notificações enquanto a app está em segundo plano (não
fechada por completo) — limitação do sistema, documentada no guia de
instalação.
