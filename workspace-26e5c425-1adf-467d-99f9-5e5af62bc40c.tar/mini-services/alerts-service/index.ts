/**
 * STORMWATCH alerts-service — serviço de alertas em tempo real.
 *
 * Responsabilidades (guia PWA — Terminal 2, porta 3003):
 *  1. Polling do IPMA (warnings_www.json) a cada 5 minutos, com validação
 *     Zod e deteção de avisos NOVOS por diff determinístico de IDs.
 *  2. Web Push (VAPID) para todos os dispositivos subscritos quando surge
 *     um aviso novo; chaves lidas das variáveis de ambiente — se ausentes,
 *     o serviço continua a funcionar e reporta `pushConfigured: false`.
 *  3. API HTTP consumida pela app via gateway (XTransformPort=3003):
 *     · GET  /api/status      — estado do serviço + chave pública VAPID
 *     · GET  /api/alerts      — avisos IPMA ativos (normalizados)
 *     · GET  /api/poll        — força um ciclo de polling (limitado)
 *     · GET  /api/stream      — SSE: `alert:new`, `poll`, keep-alive
 *     · POST /api/subscribe   — guarda uma subscrição Web Push
 *     · POST /api/unsubscribe — remove por endpoint
 *     · POST /api/test        — notificação de teste ("Notificações ativadas")
 *  4. Persistência local em `data/` (subscrições + último estado visto),
 *     para não reenviar push de avisos antigos após reinício.
 */
import { createServer, type IncomingMessage, type ServerResponse } from 'http';
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'fs';
import webpush from 'web-push';
import { diffWarnings, normalizeWarnings, type NormalizedWarning } from './diff';

// ——— Configuração ———

const PORT = 3003;
const POLL_INTERVAL_MS = 5 * 60 * 1000; // o serviço polla o IPMA a cada 5 min
const FIRST_POLL_DELAY_MS = 2500;
const FORCED_POLL_COOLDOWN_MS = 10_000;
const FETCH_TIMEOUT_MS = 30_000; // o IPMA costuma responder em ~10–15 s
const IPMA_URL = 'https://api.ipma.pt/open-data/forecast/warnings/warnings_www.json';
const DATA_DIR = new URL('./data/', import.meta.url).pathname;

const LEVEL_PT: Record<NormalizedWarning['level'], string> = {
  yellow: 'Aviso amarelo',
  orange: 'Aviso laranja',
  red: 'Aviso vermelho',
};

// ——— Web Push (VAPID) ———

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY ?? '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY ?? '';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT ?? 'mailto:alerts@stormwatch.pt';
const pushConfigured = VAPID_PUBLIC_KEY.length > 0 && VAPID_PRIVATE_KEY.length > 0;

if (pushConfigured) {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
  console.log('[STORMWATCH alerts-service] Web Push configurado (chaves VAPID presentes).');
} else {
  console.warn(
    '[STORMWATCH alerts-service] Web Push NÃO configurado — faltam VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY no .env. ' +
      'O serviço continua a difundir por SSE e a servir avisos.',
  );
}

// ——— Subscrições ———

interface StoredSubscription {
  endpoint: string;
  keys: { p256dh: string; auth: string };
  expirationTime: number | null;
  createdAt: string;
}

interface StoredState {
  seenWarnings: NormalizedWarning[];
  lastPollAt: string | null;
  /** true depois de concluída a primeira polling — ativa a difusão de novos. */
  hasBaseline: boolean;
}

let subscriptions: StoredSubscription[] = [];
let state: StoredState = { seenWarnings: [], lastPollAt: null, hasBaseline: false };
let pollingError: string | null = null;
let lastForcedPoll = 0;

function readJsonFile(path: string): unknown | null {
  try {
    return JSON.parse(readFileSync(path, 'utf8')) as unknown;
  } catch {
    return null;
  }
}

function writeJsonFile(path: string, value: unknown): void {
  mkdirSync(DATA_DIR, { recursive: true });
  const tmp = `${path}.tmp`;
  writeFileSync(tmp, JSON.stringify(value));
  renameSync(tmp, path);
}

function loadPersistence(): void {
  const rawSubs = readJsonFile(`${DATA_DIR}subscriptions.json`);
  if (Array.isArray(rawSubs)) {
    subscriptions = (rawSubs as unknown[]).filter(isValidSubscription);
  }
  const rawState = readJsonFile(`${DATA_DIR}state.json`) as StoredState | null;
  if (rawState && Array.isArray(rawState.seenWarnings)) {
    state = {
      seenWarnings: rawState.seenWarnings,
      lastPollAt: rawState.lastPollAt ?? null,
      hasBaseline: rawState.hasBaseline === true,
    };
  }
  console.log(
    `[STORMWATCH alerts-service] estado carregado: ${subscriptions.length} subscrição(ões), ${state.seenWarnings.length} aviso(s) conhecidos.`,
  );
}

function isValidSubscription(value: unknown): value is StoredSubscription {
  if (typeof value !== 'object' || value === null) return false;
  const v = value as Record<string, unknown>;
  const keys = v.keys as Record<string, unknown> | undefined;
  return (
    typeof v.endpoint === 'string' &&
    v.endpoint.startsWith('https://') &&
    typeof keys === 'object' &&
    keys !== null &&
    typeof keys.p256dh === 'string' &&
    typeof keys.auth === 'string'
  );
}

function saveSubscriptions(): void {
  writeJsonFile(`${DATA_DIR}subscriptions.json`, subscriptions);
}

function saveState(): void {
  writeJsonFile(`${DATA_DIR}state.json`, state);
}

// ——— SSE ———

interface StreamClient {
  res: ServerResponse;
  connectedAt: number;
}

const streamClients = new Set<StreamClient>();

function broadcast(event: string, payload: unknown): void {
  const frame = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of streamClients) {
    try {
      client.res.write(frame);
    } catch {
      streamClients.delete(client);
    }
  }
}

setInterval(() => {
  for (const client of streamClients) {
    try {
      client.res.write(': keep-alive\n\n');
    } catch {
      streamClients.delete(client);
    }
  }
}, 25_000).unref();

// ——— Polling do IPMA ———

async function fetchIpmaWarnings(): Promise<NormalizedWarning[]> {
  const res = await fetch(IPMA_URL, { signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
  if (!res.ok) throw new Error(`IPMA respondeu ${res.status}`);
  const raw: unknown = await res.json();
  return normalizeWarnings(raw);
}

async function sendPushToAll(title: string, body: string, tag: string): Promise<{ sent: number; failures: number }> {
  if (!pushConfigured) return { sent: 0, failures: 0 };
  const payload = JSON.stringify({ title, body, url: '/', tag });
  let sent = 0;
  let failures = 0;
  const remaining: StoredSubscription[] = [];

  for (const sub of subscriptions) {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: sub.keys, expirationTime: sub.expirationTime },
        payload,
      );
      sent += 1;
      remaining.push(sub);
    } catch (err) {
      const status = typeof err === 'object' && err !== null && 'statusCode' in err ? Number((err as { statusCode: unknown }).statusCode) : 0;
      if (status === 404 || status === 410) {
        failures += 1;
        console.warn(`[STORMWATCH alerts-service] subscrição obsoleta removida (${status}).`);
      } else {
        failures += 1;
        remaining.push(sub);
        console.warn(`[STORMWATCH alerts-service] falha de push (${status || 'sem estado'}) — subscrição mantida.`);
      }
    }
  }

  if (remaining.length !== subscriptions.length) {
    subscriptions = remaining;
    saveSubscriptions();
  }
  return { sent, failures };
}

async function pollOnce(): Promise<void> {
  try {
    const current = await fetchIpmaWarnings();
    const diff = diffWarnings(state.seenWarnings, current, { baseline: state.hasBaseline });
    pollingError = null;
    state = { seenWarnings: current, lastPollAt: new Date().toISOString(), hasBaseline: true };
    saveState();

    console.log(
      `[STORMWATCH alerts-service] IPMA: ${current.length} aviso(s) ativo(s) · ${diff.added.length} novo(s) · ${diff.removedIds.length} terminado(s).`,
    );

    broadcast('poll', { activeCount: current.length, lastPollAt: state.lastPollAt });

    if (diff.added.length > 0) {
      for (const warning of diff.added) {
        broadcast('alert:new', warning);
        const result = await sendPushToAll(
          'STORMWATCH · Aviso oficial IPMA',
          `${LEVEL_PT[warning.level]} · ${warning.area}: ${warning.phenomenLabel}`,
          `ipma-${warning.id}`,
        );
        console.log(
          `[STORMWATCH alerts-service] aviso novo difundido: ${warning.id} (push enviados: ${result.sent}, falhas: ${result.failures}).`,
        );
      }
    }
  } catch (err) {
    pollingError = err instanceof Error ? err.message : 'erro desconhecido';
    console.error(`[STORMWATCH alerts-service] falha no polling do IPMA: ${pollingError}`);
  }
}

async function pollMaybeForced(): Promise<boolean> {
  const now = Date.now();
  if (now - lastForcedPoll < FORCED_POLL_COOLDOWN_MS) return false;
  lastForcedPoll = now;
  await pollOnce();
  return true;
}

// ——— HTTP ———

function cors(res: ServerResponse): void {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function json(res: ServerResponse, status: number, payload: unknown): void {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function readBody(req: IncomingMessage, limitBytes = 256 * 1024): Promise<string> {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk: Buffer) => {
      body += chunk.toString('utf8');
      if (body.length > limitBytes) {
        req.destroy();
        reject(new Error('payload demasiado grande'));
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function handleStream(_req: IncomingMessage, res: ServerResponse): void {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });
  res.write(`retry: 4000\n\n`);
  res.write(`event: poll\ndata: ${JSON.stringify({ activeCount: state.seenWarnings.length, lastPollAt: state.lastPollAt })}\n\n`);
  const client: StreamClient = { res, connectedAt: Date.now() };
  streamClients.add(client);
  console.log(`[STORMWATCH alerts-service] cliente SSE ligado (total: ${streamClients.size}).`);
  reqOnClose(res, () => {
    streamClients.delete(client);
    console.log(`[STORMWATCH alerts-service] cliente SSE desligado (total: ${streamClients.size}).`);
  });
}

function reqOnClose(res: ServerResponse, fn: () => void): void {
  res.on('close', fn);
}

async function handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
  cors(res);
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url ?? '/', 'http://localhost');

  if (req.method === 'GET' && (url.pathname === '/api/stream' || url.pathname === '/stream')) {
    handleStream(req, res);
    return;
  }

  if (req.method === 'GET' && (url.pathname === '/api/status' || url.pathname === '/status')) {
    json(res, 200, {
      ok: true,
      service: 'alerts-service',
      pushConfigured,
      vapidPublicKey: pushConfigured ? VAPID_PUBLIC_KEY : null,
      subscriptions: subscriptions.length,
      streamClients: streamClients.size,
      activeCount: state.seenWarnings.length,
      lastPollAt: state.lastPollAt,
      pollingError,
      pollIntervalMs: POLL_INTERVAL_MS,
    });
    return;
  }

  if (req.method === 'GET' && (url.pathname === '/api/alerts' || url.pathname === '/alerts')) {
    json(res, 200, {
      ok: true,
      alerts: state.seenWarnings,
      fetchedAt: state.lastPollAt,
      pollingError,
    });
    return;
  }

  if (req.method === 'GET' && url.pathname === '/api/poll') {
    const done = await pollMaybeForced();
    json(res, 200, { ok: done, activeCount: state.seenWarnings.length, lastPollAt: state.lastPollAt });
    return;
  }

  if (req.method === 'POST' && (url.pathname === '/api/subscribe' || url.pathname === '/subscribe')) {
    if (!pushConfigured) {
      json(res, 503, { ok: false, error: 'Web Push não configurado: faltam as chaves VAPID no .env do alerts-service.' });
      return;
    }
    try {
      const body = JSON.parse(await readBody(req)) as { subscription?: unknown };
      if (!isValidSubscription(body.subscription)) {
        json(res, 400, { ok: false, error: 'Subscrição inválida — faltam endpoint ou chaves p256dh/auth.' });
        return;
      }
      const sub = body.subscription as StoredSubscription;
      const existing = subscriptions.findIndex((s) => s.endpoint === sub.endpoint);
      const stored: StoredSubscription = {
        endpoint: sub.endpoint,
        keys: { p256dh: sub.keys.p256dh, auth: sub.keys.auth },
        expirationTime: typeof sub.expirationTime === 'number' ? sub.expirationTime : null,
        createdAt: new Date().toISOString(),
      };
      if (existing >= 0) subscriptions[existing] = stored;
      else subscriptions.push(stored);
      saveSubscriptions();
      console.log(`[STORMWATCH alerts-service] subscrição guardada (total: ${subscriptions.length}).`);
      json(res, 200, { ok: true, subscriptions: subscriptions.length });
    } catch {
      json(res, 400, { ok: false, error: 'JSON inválido.' });
    }
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/unsubscribe') {
    try {
      const body = JSON.parse(await readBody(req)) as { endpoint?: unknown };
      if (typeof body.endpoint !== 'string') {
        json(res, 400, { ok: false, error: 'Falta o endpoint da subscrição.' });
        return;
      }
      const before = subscriptions.length;
      subscriptions = subscriptions.filter((s) => s.endpoint !== body.endpoint);
      saveSubscriptions();
      json(res, 200, { ok: true, removed: before - subscriptions.length, subscriptions: subscriptions.length });
    } catch {
      json(res, 400, { ok: false, error: 'JSON inválido.' });
    }
    return;
  }

  if (req.method === 'POST' && (url.pathname === '/api/test' || url.pathname === '/test')) {
    if (!pushConfigured) {
      json(res, 503, { ok: false, error: 'Web Push não configurado: faltam as chaves VAPID no .env do alerts-service.' });
      return;
    }
    try {
      const body = JSON.parse(await readBody(req)) as { subscription?: unknown };
      const title = 'STORMWATCH — Notificações ativadas';
      const bodyText = 'O serviço de alertas está ligado. Receberás avisos oficiais do IPMA e alterações significativas.';
      if (isValidSubscription(body.subscription)) {
        const sub = body.subscription as StoredSubscription;
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: sub.keys, expirationTime: sub.expirationTime },
            JSON.stringify({ title, body: bodyText, url: '/', tag: 'stormwatch-test' }),
          );
          json(res, 200, { ok: true, sent: 1, failures: 0 });
        } catch (err) {
          const status = typeof err === 'object' && err !== null && 'statusCode' in err ? Number((err as { statusCode: unknown }).statusCode) : 0;
          if (status === 404 || status === 410) {
            subscriptions = subscriptions.filter((s) => s.endpoint !== sub.endpoint);
            saveSubscriptions();
          }
          json(res, 502, { ok: false, error: `O serviço de push recusou a notificação (${status || 'erro de rede'}).` });
        }
        return;
      }
      const result = await sendPushToAll(title, bodyText, 'stormwatch-test');
      json(res, 200, { ok: result.sent > 0 || subscriptions.length === 0, sent: result.sent, failures: result.failures });
    } catch {
      json(res, 400, { ok: false, error: 'JSON inválido.' });
    }
    return;
  }

  json(res, 404, { ok: false, error: 'endpoint não encontrado' });
}

// ——— Arranque ———

loadPersistence();

const server = createServer((req, res) => {
  void handleRequest(req, res).catch(() => {
    if (!res.headersSent) json(res, 500, { ok: false, error: 'erro interno' });
    res.end();
  });
});

server.listen(PORT, () => {
  console.log(`[STORMWATCH alerts-service] listening on port ${PORT}`);
  console.log(`[STORMWATCH alerts-service] polling do IPMA a cada ${POLL_INTERVAL_MS / 60000} min · SSE em /api/stream`);
});

const pollTimer = setInterval(() => void pollOnce(), POLL_INTERVAL_MS);
pollTimer.unref();
setTimeout(() => void pollOnce(), FIRST_POLL_DELAY_MS).unref();

process.on('SIGTERM', () => {
  console.log('[STORMWATCH alerts-service] SIGTERM — a encerrar…');
  server.close(() => process.exit(0));
});

process.on('SIGINT', () => {
  console.log('[STORMWATCH alerts-service] SIGINT — a encerrar…');
  server.close(() => process.exit(0));
});
