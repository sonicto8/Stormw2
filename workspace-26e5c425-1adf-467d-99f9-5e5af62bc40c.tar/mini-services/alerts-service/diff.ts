/**
 * STORMWATCH alerts-service — lógica pura de normalização e difusão de avisos.
 *
 * Espelha a normalização do adaptador IPMA da aplicação principal
 * (src/lib/adapters/ipma.ts) para que o payload difundido por SSE e por
 * Web Push seja idêntico ao modelo interno `IpmaWarning`. Ficheiro
 * intencionalmente sem dependências de servidor para poder ser testado
 * com vitest a partir da aplicação principal.
 */
import { z } from 'zod';

// ——— Schemas Zod (formato real de warnings_www.json) ———

export const ipmaLevelSchema = z.enum(['yellow', 'orange', 'red']);

export const ipmaRawWarningSchema = z
  .object({
    areaId: z.string().optional(),
    areaID: z.string().optional(),
    area: z.string().optional(),
    awarenessTypeId: z.number().optional(),
    awarenessTypeDescription: z.string().optional(),
    awarenessTypeDescriptionPT: z.string().optional(),
    awarenessLevelId: z.string().optional(),
    text: z.string().optional(),
    textPT: z.string().optional(),
    textEN: z.string().optional(),
    startTime: z.string().optional(),
    endTime: z.string().optional(),
    start: z.string().optional(),
    end: z.string().optional(),
    id: z.union([z.string(), z.number()]).optional(),
    level: ipmaLevelSchema.optional(),
    description: z.string().optional(),
    phenomen: z.string().optional(),
  })
  .refine(
    (w) => w.awarenessLevelId !== undefined || w.level !== undefined,
    { message: 'Entrada de aviso sem nível reconhecível' },
  );

export const ipmaWarningsSchema = z.object({
  forecast: z.array(z.unknown()).optional(),
});

// ——— Modelo normalizado (igual ao IpmaWarning da app principal) ———

export interface NormalizedWarning {
  id: string;
  level: 'yellow' | 'orange' | 'red';
  area: string;
  phenomen: string;
  phenomenLabel: string;
  description: string;
  start: string;
  end: string;
}

const PHENOMEN_LABELS: Record<string, string> = {
  rain: 'Chuva',
  thunderstorm: 'Trovoada',
  wind: 'Vento',
  snow: 'Neve',
  ice: 'Gelo',
  fog: 'Nevoeiro',
  heat: 'Calor',
  cold: 'Frio',
  coastal: 'Ondas de mar',
  fire: 'Risco de incêndio',
  air: 'Qualidade do ar',
  uv: 'Radiação UV',
};

/** awarenessTypeId (código oficial IPMA) → fenómeno interno. */
const AWARENESS_TYPE_TO_PHENOMEN: Record<number, string> = {
  1: 'wind',
  2: 'snow',
  3: 'thunderstorm',
  4: 'fog',
  5: 'heat',
  6: 'cold',
  7: 'coastal',
  8: 'fire',
  10: 'rain',
  11: 'rain',
};

/** awarenessLevelId do IPMA → nível interno (cor oficial preservada). */
const LEVEL_MAP: Record<string, 'yellow' | 'orange' | 'red'> = {
  y: 'yellow',
  o: 'orange',
  r: 'red',
  yellow: 'yellow',
  orange: 'orange',
  red: 'red',
};

const DESCRIPTION_TO_PHENOMEN: Record<string, string> = {
  precipitacao: 'rain',
  chuva: 'rain',
  trovoada: 'thunderstorm',
  vento: 'wind',
  ventos: 'wind',
  neve: 'snow',
  gelo: 'ice',
  nevoeiro: 'fog',
  calor: 'heat',
  'temperaturas extremas': 'heat',
  frio: 'cold',
  'ondas de mar': 'coastal',
  'ondas de mar agitadas': 'coastal',
  'risco de incendio': 'fire',
};

function normalizeText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

/**
 * Normaliza o corpo cru do IPMA. Entradas sem nível, área ou janela temporal
 * são descartadas — nunca se inventa dados.
 */
export function normalizeWarnings(raw: unknown): NormalizedWarning[] {
  const data = ipmaWarningsSchema.parse(raw);
  const entries = data.forecast ?? [];
  const warnings: NormalizedWarning[] = [];

  for (const entry of entries) {
    // Validação por entrada: uma entrada malformada é descartada sem perder
    // o resto do corpo (o feed do IPMA nunca deve derrubar o ciclo inteiro).
    const parsedEntry = ipmaRawWarningSchema.safeParse(entry);
    if (!parsedEntry.success) continue;
    const rawEntry = parsedEntry.data;

    const levelId = rawEntry.awarenessLevelId ?? rawEntry.level;
    if (!levelId) continue;
    const level = LEVEL_MAP[normalizeText(levelId)];
    if (!level) continue;

    const area = (rawEntry.area ?? rawEntry.areaID ?? rawEntry.areaId ?? '').trim();
    if (area.length === 0) continue;

    const start = rawEntry.startTime ?? rawEntry.start ?? '';
    const end = rawEntry.endTime ?? rawEntry.end ?? '';
    if (start.length === 0 || end.length === 0) continue;

    let phenomen: string | null = rawEntry.phenomen ?? null;
    if (!phenomen && rawEntry.awarenessTypeId !== undefined) {
      phenomen = AWARENESS_TYPE_TO_PHENOMEN[rawEntry.awarenessTypeId] ?? null;
    }
    if (!phenomen) {
      const description = rawEntry.awarenessTypeDescriptionPT ?? rawEntry.awarenessTypeDescription;
      if (description) phenomen = DESCRIPTION_TO_PHENOMEN[normalizeText(description)] ?? null;
    }

    warnings.push({
      id: rawEntry.id !== undefined ? String(rawEntry.id) : `${area}-${start}-${level}`,
      level,
      area,
      phenomen: phenomen ?? 'desconhecido',
      phenomenLabel: (phenomen && PHENOMEN_LABELS[phenomen]) || rawEntry.awarenessTypeDescriptionPT || 'Condição adversa',
      description: rawEntry.textPT ?? rawEntry.text ?? rawEntry.description ?? '',
      start,
      end,
    });
  }

  return warnings;
}

// ——— Difusão (diff entre polling sucessivos) ———

export interface WarningDiff {
  /** Avisos presentes agora e ausentes no polling anterior. */
  added: NormalizedWarning[];
  /** IDs presentes antes e já não publicados pelo IPMA. */
  removedIds: string[];
}

/**
 * Compara dois estados de avisos por ID determinístico.
 *  · `baseline: false` → primeira polling concluída: NÃO produz difusão
 *    (evita spam de push após reinício/primeira instalação).
 *  · `baseline: true` → difusão normal, mesmo que `previous` seja vazio
 *    (caso «não havia avisos nenhumas e agora surgiu um»).
 */
export function diffWarnings(
  previous: NormalizedWarning[],
  current: NormalizedWarning[],
  options: { baseline?: boolean } = {},
): WarningDiff {
  const { baseline = true } = options;
  if (!baseline) return { added: [], removedIds: [] };
  const previousIds = new Set(previous.map((w) => w.id));
  const currentIds = new Set(current.map((w) => w.id));
  return {
    added: current.filter((w) => !previousIds.has(w.id)),
    removedIds: [...previousIds].filter((id) => !currentIds.has(id)),
  };
}
