/**
 * Service Worker da STORMWATCH (PWA / offline).
 * Estratégias:
 *  — App shell e estáticos: cache-first com revalidação em segundo plano.
 *  — Dados internos (/api/…): network-first com fallback para a última resposta
 *    boa guardada, garantindo dashboard offline com a última previsão válida.
 *  — Tiles externos (radar/basemap): stale-while-revalidate com limite.
 */
const VERSION = 'stormwatch-v2';
const SHELL_CACHE = `${VERSION}-shell`;
const DATA_CACHE = `${VERSION}-data`;
const TILE_CACHE = `${VERSION}-tiles`;
const TILE_MAX = 240;

const SHELL_ASSETS = [
  '/',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-180.png',
  '/icons/icon-maskable-192.png',
  '/icons/icon-maskable-512.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) => cache.addAll(SHELL_ASSETS))
      .catch(() => undefined)
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => !k.startsWith(VERSION))
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});

function isTileRequest(url) {
  return (
    url.hostname.endsWith('rainviewer.com') ||
    url.hostname.endsWith('cartocdn.com') ||
    url.hostname.endsWith('tile.openstreetmap.org')
  );
}

function isDataRequest(url) {
  return url.origin === self.location.origin && url.pathname.startsWith('/api/');
}

async function cachePutLimited(cacheName, request, response) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length >= TILE_MAX) {
    await cache.delete(keys[0]);
  }
  await cache.put(request, response);
}

async function handleTile(request) {
  const cache = await caches.open(TILE_CACHE);
  const cached = await cache.match(request);
  const network = fetch(request)
    .then((res) => {
      if (res.ok) void cachePutLimited(TILE_CACHE, request, res.clone());
      return res;
    })
    .catch(() => null);
  return cached ?? (await network) ?? new Response('', { status: 504 });
}

async function handleData(request) {
  const cache = await caches.open(DATA_CACHE);
  try {
    const res = await fetch(request);
    if (res.ok) {
      // Não cachear respostas em streaming (SSE) — cache.put falharia.
      const contentType = res.headers.get('content-type') ?? '';
      if (contentType.includes('json') || contentType.includes('text/plain')) {
        await cache.put(request, res.clone());
      }
    } else if (request.method === 'GET') {
      const cached = await cache.match(request);
      if (cached) return cached;
    }
    return res;
  } catch (err) {
    const cached = await cache.match(request);
    if (cached) return cached;
    throw err;
  }
}

async function handleShell(request) {
  const cache = await caches.open(SHELL_CACHE);
  const cached = await cache.match(request, { ignoreSearch: true });
  const network = fetch(request)
    .then((res) => {
      if (res.ok) void cache.put(request, res.clone());
      return res;
    })
    .catch(() => null);
  return cached ?? (await network) ?? (await cache.match('/')) ?? new Response('Offline', { status: 503 });
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }
  if (isTileRequest(url)) {
    event.respondWith(handleTile(request));
    return;
  }
  if (isDataRequest(url)) {
    event.respondWith(handleData(request));
    return;
  }
  if (url.origin === self.location.origin) {
    event.respondWith(handleShell(request));
  }
});

/* ——— Web Push (VAPID) ———
 * Payload JSON enviado pelo alerts-service (porta 3003):
 *   { title, body, url, tag }
 * userVisibleOnly exige que cada push mostre uma notificação.
 */
self.addEventListener('push', (event) => {
  let payload = null;
  try {
    payload = event.data ? event.data.json() : null;
  } catch {
    payload = null;
  }
  const title = payload && typeof payload.title === 'string' ? payload.title : 'STORMWATCH';
  const body = payload && typeof payload.body === 'string' ? payload.body : 'Aviso meteorológico recebido.';
  const url = payload && typeof payload.url === 'string' ? payload.url : '/';
  const options = {
    body,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    tag: payload && typeof payload.tag === 'string' ? payload.tag : 'stormwatch',
    data: { url },
    vibrate: [100, 50, 100],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    self.clients
      .matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          if ('focus' in client) return client.focus();
        }
        return self.clients.openWindow(target);
      }),
  );
});
