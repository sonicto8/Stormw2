/**
 * Testes de integração — endpoints internos contra o servidor de
 * desenvolvimento (http://localhost:3000). Os testes são ignorados quando o
 * servidor não está acessível (ex.: CI sem servidor).
 */
import { describe, expect, it } from 'vitest';

const BASE = process.env.STORMWATCH_BASE_URL ?? 'http://localhost:3000';

/**
 * Verificação do servidor no momento da carga do módulo: describe.skipIf é
 * avaliado durante a coleção, antes de qualquer beforeAll.
 */
let serverUp = false;
try {
  const res = await fetch(`${BASE}/`, { signal: AbortSignal.timeout(8000) });
  serverUp = res.ok;
} catch {
  serverUp = false;
}

describe.skipIf(!serverUp)('GET /api/geocoding', () => {
  it('encontra Lisboa com coordenadas reais ou degrada com aviso claro', async () => {
    const res = await fetch(`${BASE}/api/geocoding?q=Lisboa`);
    const json = (await res.json()) as { data?: Array<{ name: string; latitude: number; longitude: number }>; error?: string };
    if (res.status === 200) {
      expect(json.data!.length).toBeGreaterThan(0);
      expect(json.data![0].name.toLowerCase()).toContain('lisboa');
      expect(json.data![0].latitude).toBeGreaterThan(38);
      expect(json.data![0].latitude).toBeLessThan(39);
    } else {
      // A montante pode estar no limite diário (IP partilhado) — o contrato
      // garante degradação com mensagem em vez de quebra.
      expect([502, 504]).toContain(res.status);
      expect(typeof json.error).toBe('string');
    }
  });

  it('responde sempre com contrato válido (lista ou erro tipado)', async () => {
    const res = await fetch(`${BASE}/api/geocoding?q=xxqqlxxx`);
    const json = (await res.json()) as { data?: unknown[]; error?: string };
    if (res.status === 200) {
      expect(json.data).toEqual([]);
    } else {
      expect([502, 504]).toContain(res.status);
      expect(typeof json.error).toBe('string');
    }
  });
});

describe.skipIf(!serverUp)('GET /api/weather/forecast', () => {
  it('devolve um ForecastBundle válido ou degrada com aviso claro', async () => {
    const res = await fetch(`${BASE}/api/weather/forecast?lat=38.7223&lon=-9.1393`);
    const json = (await res.json()) as Record<string, unknown>;
    if (res.status === 200) {
      const bundle = json.data as { current: { temperature: number }; hourly: unknown[]; daily: unknown[]; minutely15: unknown[]; source: string };
      expect(bundle.current.temperature).toBeTypeOf('number');
      expect(bundle.hourly.length).toBeGreaterThan(0);
      expect(bundle.daily.length).toBeGreaterThan(0);
      expect(['network', 'cache-server', 'cache-offline']).toContain(bundle.source);
    } else {
      // Contrato de degradação: erro com mensagem (ex.: limite diário a montante).
      expect([502, 504]).toContain(res.status);
      expect(typeof json.error).toBe('string');
    }
  });

  it('rejeita coordenadas inválidas', async () => {
    const res = await fetch(`${BASE}/api/weather/forecast?lat=999&lon=-9`);
    expect(res.status).toBe(400);
  });
});

describe.skipIf(!serverUp)('GET /api/weather/air-quality', () => {
  it('devolve AQI europeu ou degrada graciosamente', async () => {
    const res = await fetch(`${BASE}/api/weather/air-quality?lat=38.7223&lon=-9.1393`);
    const json = (await res.json()) as { data?: { europeanAqi: number | null; source: string }; error?: string };
    if (res.status === 200) {
      expect(json.data).toBeDefined();
      expect(json.data!.source).toBeTypeOf('string');
    } else {
      expect(typeof json.error).toBe('string');
    }
  });
});

describe.skipIf(!serverUp)('GET /api/ipma/warnings', () => {
  it('devolve a lista de avisos (posso estar vazia) com metadados', async () => {
    const res = await fetch(`${BASE}/api/ipma/warnings`);
    expect(res.status).toBe(200);
    const json = (await res.json()) as { data: unknown[]; notice: string | null; fetchedAt: number };
    expect(Array.isArray(json.data)).toBe(true);
    expect(json.fetchedAt).toBeGreaterThan(0);
    for (const w of json.data) {
      expect(['yellow', 'orange', 'red']).toContain((w as { level: string }).level);
    }
  });
});

describe.skipIf(!serverUp)('GET /api/radar', () => {
  it('devolve frames de radar do RainViewer', async () => {
    const res = await fetch(`${BASE}/api/radar`);
    expect(res.status).toBe(200);
    const json = (await res.json()) as { data: { host: string; frames: Array<{ time: number; path: string; kind: string }> } };
    expect(json.data.host).toContain('https://');
    expect(json.data.frames.length).toBeGreaterThan(0);
    expect(json.data.frames.every((f) => ['past', 'nowcast'].includes(f.kind))).toBe(true);
  });
});

describe.skipIf(!serverUp)('POST /api/reports — reportes colaborativos', () => {
  const deviceId = `vitest-${Date.now().toString(36)}`;

  it('rejeita corpo inválido com 400', async () => {
    const res = await fetch(`${BASE}/api/reports`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId, type: 'tipo-inexistente', lat: 10, lon: 10 }),
    });
    expect(res.status).toBe(400);
  });

  it('cria um reporte válido com 201 e expiração de 2 h', async () => {
    const res = await fetch(`${BASE}/api/reports`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deviceId,
        type: 'thunderstorm',
        note: 'Teste automatizado',
        lat: 38.7223,
        lon: -9.1393,
        placeName: 'Lisboa',
      }),
    });
    expect(res.status).toBe(201);
    const json = (await res.json()) as { data: { id: string; type: string; confirmations: number } };
    expect(json.data.type).toBe('thunderstorm');
    expect(json.data.confirmations).toBe(0);
  });

  it('aplica a limitação de taxa: 1 reporte por 10 min por dispositivo', async () => {
    const res = await fetch(`${BASE}/api/reports`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId, type: 'fog', lat: 38.7223, lon: -9.1393 }),
    });
    expect(res.status).toBe(429);
    const json = (await res.json()) as { error: string };
    expect(json.error).toContain('Limite');
  });

  it('lista reportes ativos incluindo o criado', async () => {
    const res = await fetch(`${BASE}/api/reports`);
    expect(res.status).toBe(200);
    const json = (await res.json()) as { data: Array<{ type: string; createdAt: string }> };
    expect(Array.isArray(json.data)).toBe(true);
    expect(json.data.some((r) => r.type === 'thunderstorm')).toBe(true);
  });
});

describe.skipIf(!serverUp)('POST /api/reports/confirm', () => {
  it('rejeita confirmação sem id', async () => {
    const res = await fetch(`${BASE}/api/reports/confirm`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deviceId: 'vitest-12345678' }),
    });
    expect([400, 404, 500]).toContain(res.status);
  });
});

describe.skipIf(!serverUp)('POST /api/storm-ai', () => {
  it('rejeita pedidos sem resposta para reformular', async () => {
    const res = await fetch(`${BASE}/api/storm-ai`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: 'teste' }),
    });
    expect(res.status).toBe(400);
  });
});
