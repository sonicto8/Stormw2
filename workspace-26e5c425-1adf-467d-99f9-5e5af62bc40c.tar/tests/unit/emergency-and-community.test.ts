import { describe, expect, it } from 'vitest';
import {
  buildEmergencyMessage,
  isDisasterSituation,
  waNumber,
  whatsappLink,
} from '@/lib/engines/emergency';
import { createCommentSchema } from '@/lib/schemas/comment.schema';
import { emergencyContactSchema } from '@/lib/schemas/report.schema';
import { adaptGrid } from '@/lib/adapters/open-meteo';
import { QUICK_LOCATIONS } from '@/lib/locations';
import type { ForecastBundle, WeatherAlert } from '@/lib/types';

/** Bundle mínimo para os testes de emergência (valores reais de estrutura). */
function fakeBundle(overrides: Partial<ForecastBundle['current']> = {}): ForecastBundle {
  const current = {
    time: '2026-11-26T12:00',
    temperature: 18.4,
    apparentTemperature: 17.1,
    humidity: 65,
    isDay: true,
    precipitation: 0,
    weatherCode: 1,
    weatherLabel: 'Geralmente limpo',
    meteocon: 'clear-day' as const,
    cloudCover: 20,
    pressureMsl: 1018,
    visibility: 24000,
    windSpeed: 14.2,
    windDirection: 225,
    windGusts: 28.6,
    uvIndex: 3.1,
    ...overrides,
  };
  return {
    latitude: 38.7223,
    longitude: -9.1393,
    elevation: 10,
    timezone: 'Europe/Lisbon',
    current,
    hourly: [],
    minutely15: [],
    daily: [],
    historyDaily: [],
    fetchedAt: Date.parse('2026-11-26T12:00:00Z'),
    source: 'network',
  };
}

const now = Date.parse('2026-11-26T12:30:00Z');

const alert = (level: WeatherAlert['officialLevel'], severity: WeatherAlert['severity']): WeatherAlert => ({
  id: 'ipma-test',
  origin: 'ipma',
  severity,
  officialLevel: level,
  title: 'Aviso de vento — Lisboa',
  description: 'Rajadas até 90 km/h.',
  start: '2026-11-26T09:00',
  end: '2026-11-26T18:00',
  area: 'Lisboa',
  createdAt: now,
});

describe('contactos de emergência — validação do perfil', () => {
  it('aceita número português de 9 dígitos e formato internacional', () => {
    expect(emergencyContactSchema.safeParse({ id: 'c-001', name: 'Maria', phone: '912 345 678' }).success).toBe(true);
    expect(emergencyContactSchema.safeParse({ id: 'c-002', name: 'João', phone: '+351 912 345 678' }).success).toBe(true);
  });

  it('rejeita números demasiado curtos ou com letras', () => {
    expect(emergencyContactSchema.safeParse({ id: 'c-003', name: 'Ana', phone: '123' }).success).toBe(false);
    expect(emergencyContactSchema.safeParse({ id: 'c-004', name: 'Ana', phone: '91ab345678' }).success).toBe(false);
  });
});

describe('motor de emergência — número WhatsApp', () => {
  it('prefixa 351 em números móveis portugueses de 9 dígitos', () => {
    expect(waNumber('912 345 678')).toBe('351912345678');
    expect(waNumber('+351 912 345 678')).toBe('351912345678');
  });

  it('mantém números internacionais com indicativo', () => {
    expect(waNumber('+44 7911 123456')).toBe('447911123456');
  });
});

describe('motor de emergência — mensagem e link', () => {
  const bundle = fakeBundle();
  const message = buildEmergencyMessage({
    placeName: 'Lisboa',
    latitude: 38.7223,
    longitude: -9.1393,
    gps: { latitude: 38.71, longitude: -9.14 },
    alerts: [],
    conditionLabel: bundle.current.weatherLabel,
    temperatureC: bundle.current.temperature,
    windKmh: bundle.current.windSpeed,
    now,
  });

  it('inclui localização precisa (GPS), coordenadas e link de mapa', () => {
    expect(message).toContain('38.71000');
    expect(message).toContain('https://maps.google.com/?q=38.71000,-9.14000');
    expect(message).toContain('Local: Lisboa');
  });

  it('inclui condição atual e hora', () => {
    expect(message).toContain('Geralmente limpo');
    expect(message).toContain('18,4'); // formatação pt-PT com vírgula
  });

  it('lista avisos ativos quando existem', () => {
    const withAlerts = buildEmergencyMessage({
      placeName: 'Lisboa',
      latitude: 38.72,
      longitude: -9.13,
      gps: null,
      alerts: [alert('orange', 'warning')],
      conditionLabel: null,
      temperatureC: null,
      windKmh: null,
      now,
    });
    expect(withAlerts).toContain('Avisos meteorológicos ativos');
    expect(withAlerts).toContain('Aviso de vento — Lisboa');
  });

  it('constrói link wa.me com mensagem codificada', () => {
    const link = whatsappLink('912345678', 'teste com espaços');
    expect(link.startsWith('https://wa.me/351912345678?text=')).toBe(true);
    expect(link).toContain(encodeURIComponent('teste com espaços'));
  });
});

describe('motor de emergência — estado de desastre', () => {
  it('deteta crítico interno e IPMA laranja/vermelho', () => {
    expect(isDisasterSituation([alert('red', 'critical')])).toBe(true);
    expect(isDisasterSituation([alert('orange', 'warning')])).toBe(true);
    expect(isDisasterSituation([alert('yellow', 'info')])).toBe(false);
  });

  it('sem avisos não é estado de desastre', () => {
    expect(isDisasterSituation([])).toBe(false);
  });
});

describe('comentários da comunidade — validação', () => {
  it('aceita comentário válido com contexto opcional', () => {
    const parsed = createCommentSchema.safeParse({
      deviceId: 'device-12345678',
      nickname: 'Rui',
      message: 'Chuva forte no centro',
      lat: 38.72,
      lon: -9.14,
      placeName: 'Lisboa',
      weatherLabel: 'Chuva moderada',
      temperature: 15.2,
    });
    expect(parsed.success).toBe(true);
  });

  it('rejeita mensagem vazia, mais de 280 caracteres e coordenadas fora de Portugal', () => {
    expect(createCommentSchema.safeParse({ deviceId: 'device-12345678', message: '   ' }).success).toBe(false);
    expect(createCommentSchema.safeParse({ deviceId: 'device-12345678', message: 'x'.repeat(301) }).success).toBe(false);
    expect(createCommentSchema.safeParse({ deviceId: 'device-12345678', message: 'x'.repeat(280) }).success).toBe(true);
    expect(createCommentSchema.safeParse({ deviceId: 'device-12345678', message: 'ok', lat: 50, lon: 5 }).success).toBe(false);
  });
});

describe('adaptador da grelha — mapas de variáveis', () => {
  const points = QUICK_LOCATIONS.slice(0, 3);
  const raw = points.map((p) => ({
    latitude: p.latitude,
    longitude: p.longitude,
    elevation: 0,
    timezone: 'Europe/Lisbon',
    current: {
      time: '2026-11-26T12:00',
      temperature_2m: 21.5,
      is_day: 1,
      weather_code: 2,
      cloud_cover: 55,
      wind_speed_10m: 24.1,
      wind_direction_10m: 180,
      wind_gusts_10m: 41.3,
    },
  }));

  it('cruza respostas e pontos pela ordem do pedido', () => {
    const grid = adaptGrid(raw, points, now);
    expect(grid).toHaveLength(3);
    expect(grid[0].id).toBe(points[0].id);
    expect(grid[0].name).toBe(points[0].name);
    expect(grid[0].temperature).toBe(21.5);
    expect(grid[0].cloudCover).toBe(55);
    expect(grid[0].windGusts).toBe(41.3);
  });

  it('rejeita resposta com comprimento diferente do pedido', () => {
    expect(() => adaptGrid(raw.slice(0, 2), points, now)).toThrow(/incompleta/);
  });
});
