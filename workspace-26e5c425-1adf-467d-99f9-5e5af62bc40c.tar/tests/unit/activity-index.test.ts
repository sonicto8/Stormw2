import { describe, expect, it } from 'vitest';
import { computeActivityIndex, activityLabel, ACTIVITY_KEYS } from '@/lib/engines/activity-index';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';
import type { ForecastBundle } from '@/lib/types';

const NOW = Date.parse('2026-01-15T10:00:00Z');

interface HourSpec {
  temp?: number;
  wind?: number;
  prob?: number | null;
  precip?: number;
  humidity?: number | null;
  uv?: number | null;
  cloud?: number | null;
  code?: number;
}

/** Constrói um bundle com N horas a partir de agora segundo as especificações. */
function bundleWithHours(specs: HourSpec[], dailySunrise?: string, dailySunset?: string): ForecastBundle {
  const hours: string[] = [];
  const cols: Record<string, Array<number | null>> = {
    temperature_2m: [],
    apparent_temperature: [],
    precipitation_probability: [],
    precipitation: [],
    weather_code: [],
    relative_humidity_2m: [],
    wind_speed_10m: [],
    wind_gusts_10m: [],
    cloud_cover: [],
    uv_index: [],
    is_day: [],
  };
  specs.forEach((s, i) => {
    const t = new Date(NOW + i * 3600000);
    hours.push(t.toISOString().slice(0, 13) + ':00');
    cols.temperature_2m.push(s.temp ?? 18);
    cols.apparent_temperature.push(s.temp ?? 18);
    cols.precipitation_probability.push(s.prob === undefined ? 0 : s.prob);
    cols.precipitation.push(s.precip ?? 0);
    cols.weather_code.push(s.code ?? 0);
    cols.relative_humidity_2m.push(s.humidity === undefined ? 50 : s.humidity);
    cols.wind_speed_10m.push(s.wind ?? 8);
    cols.wind_gusts_10m.push((s.wind ?? 8) + 5);
    cols.cloud_cover.push(s.cloud === undefined ? 10 : s.cloud);
    cols.uv_index.push(s.uv === undefined ? 3 : s.uv);
    cols.is_day.push(1);
  });

  const raw = {
    latitude: 38.7223,
    longitude: -9.1393,
    timezone: 'Europe/Lisbon',
    current: {
      time: hours[0],
      temperature_2m: specs[0]?.temp ?? 18,
      apparent_temperature: specs[0]?.temp ?? 18,
      is_day: 1,
      precipitation: 0,
      weather_code: 0,
      wind_speed_10m: 8,
      wind_gusts_10m: 13,
    },
    hourly: { time: hours, ...cols },
    daily: {
      time: ['2026-01-15'],
      weather_code: [0],
      temperature_2m_max: [18],
      temperature_2m_min: [10],
      precipitation_sum: [0],
      wind_speed_10m_max: [15],
      uv_index_max: [3],
      sunrise: [dailySunrise ?? '2026-01-15T06:30'],
      sunset: [dailySunset ?? '2026-01-15T17:30'],
    },
  };
  return adaptForecast(openMeteoForecastSchema.parse(raw), NOW, 'network');
}

describe('computeActivityIndex', () => {
  it('devolve null sem horas futuras', () => {
    expect(computeActivityIndex('running', [], [], NOW)).toBeNull();
  });

  it('avalia condições ideais com pontuação alta', () => {
    const idx = computeActivityIndex('running', bundleWithHours([
      { temp: 14, wind: 8, prob: 0, humidity: 50, uv: 2 },
      { temp: 14, wind: 8, prob: 0, humidity: 50, uv: 2 },
      { temp: 14, wind: 8, prob: 0, humidity: 50, uv: 2 },
      { temp: 14, wind: 8, prob: 0, humidity: 50, uv: 2 },
    ]).hourly, [], NOW);
    expect(idx).not.toBeNull();
    expect(idx!.score).toBeGreaterThanOrEqual(65);
    expect(idx!.classification).toMatch(/Excelente|Bom/);
    expect(idx!.bestHour).not.toBeNull();
  });

  it('avalia condições severas com pontuação baixa', () => {
    const idx = computeActivityIndex('running', bundleWithHours([
      { temp: 38, wind: 55, prob: 100, precip: 8, humidity: 95, uv: 10, code: 65 },
      { temp: 38, wind: 55, prob: 100, precip: 8, humidity: 95, uv: 10, code: 65 },
    ]).hourly, [], NOW);
    expect(idx!.score).toBeLessThanOrEqual(45);
  });

  it('fotografia beneficia do bónus golden hour', () => {
    // Condições não-ideais (índice base ~78) para o +12 do golden hour ser visível.
    const specs: HourSpec[] = [
      { temp: 32, wind: 28, prob: 0, humidity: 80, uv: 7, cloud: 5 }, // 10:00
      { temp: 32, wind: 28, prob: 0, humidity: 80, uv: 7, cloud: 5 }, // 11:00
      { temp: 32, wind: 28, prob: 0, humidity: 80, uv: 7, cloud: 5 }, // 12:00
    ];
    // Nascer do sol às 11:30 — a janela golden (11:30–12:30) cobre a hora 12:00.
    const golden = computeActivityIndex(
      'photography',
      bundleWithHours(specs).hourly,
      adaptForecast(openMeteoForecastSchema.parse({
        latitude: 0,
        longitude: 0,
        timezone: 'UTC',
        current: { time: '2026-01-15T10:00', temperature_2m: 18, apparent_temperature: 18, is_day: 1, precipitation: 0, weather_code: 0, wind_speed_10m: 8, wind_gusts_10m: 13 },
        daily: { time: ['2026-01-15'], weather_code: [0], temperature_2m_max: [18], temperature_2m_min: [10], precipitation_sum: [0], wind_speed_10m_max: [15], uv_index_max: [3], sunrise: ['2026-01-15T11:30'], sunset: ['2026-01-15T20:30'] },
      }), NOW, 'network').daily,
      NOW,
    );
    const normal = computeActivityIndex('photography', bundleWithHours(specs).hourly, [], NOW);
    expect(golden).not.toBeNull();
    expect(normal).not.toBeNull();
    // A hora 12:00 cai dentro da janela golden da manhã (11:30–12:30).
    expect(golden!.bestHour).toBe('2026-01-15T12:00');
    expect(golden!.score).toBeGreaterThan(normal!.score);
    expect(golden!.justification).toContain('golden hour');
  });

  it('suficientData é false quando humidade, UV e probabilidade estão nulos', () => {
    const raw = {
      latitude: 0,
      longitude: 0,
      timezone: 'UTC',
      current: { time: '2026-01-15T10:00', temperature_2m: 18, apparent_temperature: 18, is_day: 1, precipitation: 0, weather_code: 0, wind_speed_10m: 8, wind_gusts_10m: 13 },
      hourly: {
        time: ['2026-01-15T10:00'],
        temperature_2m: [18],
        apparent_temperature: [18],
        precipitation_probability: [null],
        precipitation: [0],
        weather_code: [0],
        wind_speed_10m: [8],
        wind_gusts_10m: [13],
      },
    };
    const bundle = adaptForecast(openMeteoForecastSchema.parse(raw), NOW, 'network');
    const idx = computeActivityIndex('running', bundle.hourly, bundle.daily, NOW);
    expect(idx!.sufficientData).toBe(false);
  });

  it('inclui as seis atividades registadas com labels pt-PT', () => {
    expect(ACTIVITY_KEYS).toHaveLength(6);
    expect(activityLabel('running')).toBe('Corrida');
    expect(activityLabel('beach')).toBe('Praia');
    expect(activityLabel('photography')).toBe('Fotografia');
  });
});
