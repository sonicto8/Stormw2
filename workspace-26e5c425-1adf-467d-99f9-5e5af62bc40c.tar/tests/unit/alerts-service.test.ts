/**
 * Testes unitários do alerts-service (mini-services/alerts-service/diff.ts):
 * normalização dos avisos IPMA e deteção de avisos novos entre polling.
 */
import { describe, expect, it } from 'vitest';
import { diffWarnings, normalizeWarnings } from '../../mini-services/alerts-service/diff';

const rawBody = {
  forecast: [
    {
      id: '42',
      areaID: 'LIS',
      area: 'Lisboa',
      awarenessTypeId: 11,
      awarenessTypeDescriptionPT: 'Precipitação',
      awarenessLevelId: 'y',
      textPT: 'Chuva forte prevista.',
      startTime: '2026-11-26T06h00',
      endTime: '2026-11-26T12h00',
    },
    {
      id: '43',
      areaID: 'POR',
      awarenessTypeId: 1,
      awarenessLevelId: 'o',
      textPT: 'Rajadas até 90 km/h.',
      startTime: '2026-11-26T03h00',
      endTime: '2026-11-26T15h00',
    },
    {
      // Sem nível reconhecível → descartado.
      areaID: 'FAF',
      textPT: 'Entrada incompleta.',
      startTime: '2026-11-26T00h00',
      endTime: '2026-11-26T06h00',
    },
  ],
};

describe('normalizeWarnings', () => {
  it('normaliza o formato cru do IPMA preservando a cor oficial', () => {
    const warnings = normalizeWarnings(rawBody);
    expect(warnings).toHaveLength(2);
    expect(warnings[0]).toMatchObject({
      id: '42',
      level: 'yellow',
      area: 'Lisboa',
      phenomen: 'rain',
      phenomenLabel: 'Chuva',
    });
    expect(warnings[1]).toMatchObject({ id: '43', level: 'orange', phenomen: 'wind' });
  });

  it('descarta entradas sem nível, área ou janela temporal — nunca inventa dados', () => {
    const warnings = normalizeWarnings({
      forecast: [
        { areaID: 'X', awarenessLevelId: 'y' }, // sem janela temporal
        { awarenessLevelId: 'y', startTime: 'a', endTime: 'b' }, // sem área
      ],
    });
    expect(warnings).toHaveLength(0);
  });

  it('determina o ID determinístico quando o IPMA não envia id', () => {
    const warnings = normalizeWarnings({
      forecast: [{ areaID: 'BRG', awarenessLevelId: 'r', startTime: 'S', endTime: 'E' }],
    });
    expect(warnings[0].id).toBe('BRG-S-red');
  });

  it('ignora um corpo sem a chave forecast (devolve lista vazia)', () => {
    expect(normalizeWarnings({ unexpected: true })).toEqual([]);
  });
});

describe('diffWarnings', () => {
  const base = normalizeWarnings(rawBody);

  it('não difunde nada quando o estado é idêntico', () => {
    const diff = diffWarnings(base, base);
    expect(diff.added).toHaveLength(0);
    expect(diff.removedIds).toHaveLength(0);
  });

  it('deteta avisos novos e terminados', () => {
    const current = [
      base[0],
      { ...base[1], id: '44', area: 'CTA' },
    ];
    const diff = diffWarnings(base, current);
    expect(diff.added).toHaveLength(1);
    expect(diff.added[0].id).toBe('44');
    expect(diff.removedIds).toEqual(['43']);
  });

  it('a primeira polling (sem baseline) não produz difusão (sem spam após arranque)', () => {
    const diff = diffWarnings([], base, { baseline: false });
    expect(diff.added).toHaveLength(0);
    expect(diff.removedIds).toHaveLength(0);
  });

  it('com baseline concluída, um aviso novo surge mesmo que antes não houvesse nenhum', () => {
    const diff = diffWarnings([], base, { baseline: true });
    expect(diff.added).toHaveLength(2);
  });
});
