import { describe, expect, it } from 'vitest';
import { createReportSchema, profileSchema, defaultProfile } from '@/lib/schemas/report.schema';
import { filterActiveReports, isReportExpired, REPORT_EXPIRY_MS } from '@/lib/engines/report-expiry';
import { adaptIpmaWarnings } from '@/lib/adapters/ipma';
import { adaptRainViewer } from '@/lib/adapters/rainviewer';
import type { ActivityReport } from '@/lib/types';

describe('reportes — schema e limites', () => {
  it('aceita um reporte válido dentro de Portugal continental', () => {
    const parsed = createReportSchema.safeParse({
      deviceId: 'device-12345678',
      type: 'thunderstorm',
      note: 'Trovões fortes perto do rio',
      lat: 38.72,
      lon: -9.14,
      placeName: 'Lisboa',
    });
    expect(parsed.success).toBe(true);
  });

  it('rejeita tipos e coordenadas fora dos limites', () => {
    const invalidType = createReportSchema.safeParse({ deviceId: 'device-12345678', type: 'neve', lat: 38.7, lon: -9.1 });
    expect(invalidType.success).toBe(false);
    const outsidePortugal = createReportSchema.safeParse({ deviceId: 'device-12345678', type: 'fog', lat: 10, lon: 5 });
    expect(outsidePortugal.success).toBe(false);
    const longNote = createReportSchema.safeParse({
      deviceId: 'device-12345678',
      type: 'fog',
      lat: 38.7,
      lon: -9.1,
      note: 'x'.repeat(241),
    });
    expect(longNote.success).toBe(false);
  });
});

describe('expiração de reportes — 2 horas', () => {
  const report = (createdAt: string): ActivityReport => ({
    id: 'r1',
    type: 'fog',
    note: null,
    lat: 38.7,
    lon: -9.1,
    placeName: null,
    createdAt,
    confirmations: 0,
    confirmedBy: [],
  });

  it('não expira dentro das 2 horas', () => {
    const created = Date.parse('2026-01-15T10:00:00Z');
    expect(isReportExpired(report('2026-01-15T10:00:00Z'), created + REPORT_EXPIRY_MS - 1)).toBe(false);
  });

  it('expira exatamente às 2 horas', () => {
    const created = Date.parse('2026-01-15T10:00:00Z');
    expect(isReportExpired(report('2026-01-15T10:00:00Z'), created + REPORT_EXPIRY_MS)).toBe(true);
  });

  it('marca createdAt inválido como expirado (defesa contra dados corrompidos)', () => {
    expect(isReportExpired(report('data-invalida'), Date.now())).toBe(true);
  });

  it('filterActiveReports ordena por mais recente e remove expirados', () => {
    const now = Date.parse('2026-01-15T12:00:00Z');
    const active = filterActiveReports(
      [
        report('2026-01-15T09:00:00Z'), // 3 h → expirado
        report('2026-01-15T11:30:00Z'), // ativo, mais recente
        report('2026-01-15T10:30:00Z'), // ativo, mais antigo
      ],
      now,
    );
    expect(active.map((r) => r.createdAt)).toEqual(['2026-01-15T11:30:00Z', '2026-01-15T10:30:00Z']);
  });
});

describe('perfil — schema com valores por omissão', () => {
  it('perfil predefinido é válido', () => {
    expect(profileSchema.safeParse(defaultProfile).success).toBe(true);
  });

  it('rejeita sensibilidades fora de 1–5', () => {
    const invalid = profileSchema.safeParse({ ...defaultProfile, coldSensitivity: 6 });
    expect(invalid.success).toBe(false);
  });

  it('rejeita unidades desconhecidas', () => {
    const invalid = profileSchema.safeParse({ ...defaultProfile, temperatureUnit: 'kelvin' });
    expect(invalid.success).toBe(false);
  });
});

describe('adaptador IPMA — formato real de warnings_www.json', () => {
  it('normaliza níveis y/o/r, tipos e texto oficial', () => {
    const warnings = adaptIpmaWarnings({
      forecast: [
        {
          areaId: '1110300',
          areaID: ' Lisboa ',
          awarenessTypeId: 3,
          awarenessTypeDescriptionPT: 'Trovoada',
          awarenessLevelId: 'o',
          awarenessLevelDescriptionPT: 'Laranja',
          textPT: 'Trovoada forte prevista',
          startTime: '2026-01-15T10:00:00',
          endTime: '2026-01-15T18:00:00',
        },
        {
          areaId: '1210000',
          areaID: ' Porto ',
          awarenessTypeId: 10,
          awarenessTypeDescriptionPT: 'Precipitação',
          awarenessLevelId: 'y',
          textPT: 'Chuva intensa prevista',
          startTime: '2026-01-15T12:00:00',
          endTime: '2026-01-16T00:00:00',
        },
      ],
    });
    expect(warnings).toHaveLength(2);
    expect(warnings[0]).toMatchObject({
      level: 'orange',
      area: 'Lisboa',
      phenomen: 'thunderstorm',
      phenomenLabel: 'Trovoada',
      description: 'Trovoada forte prevista',
      start: '2026-01-15T10:00:00',
    });
    expect(warnings[0].id).toBe('1110300-2026-01-15T10:00:00-orange');
    expect(warnings[1]).toMatchObject({
      level: 'yellow',
      area: 'Porto',
      phenomen: 'rain',
      phenomenLabel: 'Chuva',
    });
  });

  it('ignora entradas sem nível ou sem janela temporal (não inventa dados)', () => {
    const warnings = adaptIpmaWarnings({
      forecast: [
        { areaID: 'Lisboa', awarenessLevelId: 'z', textPT: 'Nível desconhecido', startTime: '2026-01-15T10:00:00', endTime: '2026-01-15T12:00:00' },
        { areaID: 'Porto', awarenessLevelId: 'y', textPT: 'Sem janela' },
      ],
    });
    expect(warnings).toEqual([]);
  });
});

describe('adaptador RainViewer — frames de radar', () => {
  it('concatena passado e nowcast com host do CDN', () => {
    const bundle = adaptRainViewer(
      {
        version: '2.0',
        generated: 1700000000,
        host: 'https://tilecache.rainviewer.com',
        radar: {
          past: [
            { time: 1700000000, path: '/v2/radar/aaa' },
            { time: 1700000600, path: '/v2/radar/bbb' },
          ],
          nowcast: [{ time: 1700001200, path: '/v2/radar/ccc' }],
        },
      },
      Date.now(),
    );
    expect(bundle.frames).toHaveLength(3);
    expect(bundle.frames[0].kind).toBe('past');
    expect(bundle.frames[2].kind).toBe('nowcast');
    expect(bundle.host).toBe('https://tilecache.rainviewer.com');
    expect(bundle.frames[0].path).toBe('/v2/radar/aaa');
  });

  it('devolve frames vazios quando o radar não tem cobertura', () => {
    const bundle = adaptRainViewer({ version: '2.0', host: 'https://tilecache.rainviewer.com' }, Date.now());
    expect(bundle.frames).toEqual([]);
  });
});
