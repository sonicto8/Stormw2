import { describe, expect, it } from 'vitest';
import { computePlanner } from '@/lib/engines/planner';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';

const NOW = Date.parse('2026-01-15T10:00:00Z');

interface DaySpec {
  code: number;
  max: number;
  min: number;
  precipSum: number;
  probMax: number | null;
  windMax: number | null;
  windMean: number | null;
  humidityMean: number | null;
  uvMax: number | null;
}

/** Constrói o bundle diário para 7 dias conforme especificações. */
function bundleWithDays(specs: DaySpec[]) {
  const dates: string[] = [];
  for (let i = 0; i < specs.length; i++) {
    dates.push(new Date(NOW + i * 86400000).toISOString().slice(0, 10));
  }
  return adaptForecast(
    openMeteoForecastSchema.parse({
      latitude: 0,
      longitude: 0,
      timezone: 'UTC',
      current: {
        time: '2026-01-15T10:00',
        temperature_2m: 15,
        apparent_temperature: 14,
        is_day: 1,
        precipitation: 0,
        weather_code: 0,
        wind_speed_10m: 10,
        wind_gusts_10m: 15,
      },
      daily: {
        time: dates,
        weather_code: specs.map((s) => s.code),
        temperature_2m_max: specs.map((s) => s.max),
        temperature_2m_min: specs.map((s) => s.min),
        temperature_2m_mean: specs.map((s) => (s.max + s.min) / 2),
        precipitation_sum: specs.map((s) => s.precipSum),
        precipitation_probability_max: specs.map((s) => s.probMax),
        wind_speed_10m_max: specs.map((s) => s.windMax),
        wind_speed_10m_mean: specs.map((s) => s.windMean),
        wind_gusts_10m_max: specs.map((s) => (s.windMax ?? 0) + 10),
        relative_humidity_2m_mean: specs.map((s) => s.humidityMean),
        uv_index_max: specs.map((s) => s.uvMax),
      },
    }),
    NOW,
    'network',
  );
}

describe('computePlanner — regras da especificação', () => {
  it('lavar o carro: escolhe o dia seco com probabilidade < 20%', () => {
    const bundle = bundleWithDays([
      { code: 61, max: 15, min: 8, precipSum: 4, probMax: 90, windMax: 15, windMean: 10, humidityMean: 80, uvMax: 2 },
      { code: 0, max: 16, min: 7, precipSum: 0, probMax: 5, windMax: 12, windMean: 8, humidityMean: 55, uvMax: 2 },
      { code: 0, max: 14, min: 6, precipSum: 0.5, probMax: 30, windMax: 18, windMean: 12, humidityMean: 65, uvMax: 2 },
    ]);
    const [carWash] = computePlanner(bundle.daily);
    expect(carWash.key).toBe('car-wash');
    expect(carWash.winnerDate).toBe(bundle.daily[1].date);
    expect(carWash.justification).toContain('sem precipitação prevista');
  });

  it('estender roupa: exige vento 5–25, humidade < 60% e céu pouco nublado', () => {
    const bundle = bundleWithDays([
      { code: 3, max: 15, min: 8, precipSum: 0, probMax: 10, windMax: 30, windMean: 28, humidityMean: 55, uvMax: 2 }, // vento 28 > 25
      { code: 1, max: 15, min: 8, precipSum: 0, probMax: 10, windMax: 18, windMean: 12, humidityMean: 50, uvMax: 2 }, // perfeito
    ]);
    const laundry = computePlanner(bundle.daily).find((c) => c.key === 'laundry')!;
    expect(laundry.winnerDate).toBe(bundle.daily[1].date);
    expect(laundry.alternatives[0]?.label).toBeTruthy();
  });

  it('nenhum dia cumpre as regras quando há chuva todos os dias', () => {
    const bundle = bundleWithDays(
      Array.from({ length: 5 }, () => ({
        code: 65, max: 12, min: 6, precipSum: 10, probMax: 95, windMax: 30, windMean: 25, humidityMean: 90, uvMax: 1,
      })),
    );
    const [carWash] = computePlanner(bundle.daily);
    expect(carWash.sufficientData).toBe(true);
    expect(carWash.winnerDate).toBeNull();
    expect(carWash.winnerLabel).toBe('Nenhum dia cumpre as regras');
  });

  it('marca os piores dias como dias a evitar', () => {
    const bundle = bundleWithDays([
      { code: 0, max: 20, min: 12, precipSum: 0, probMax: 5, windMax: 10, windMean: 8, humidityMean: 50, uvMax: 4 },
      { code: 82, max: 10, min: 4, precipSum: 25, probMax: 100, windMax: 60, windMean: 45, humidityMean: 95, uvMax: 1 },
      { code: 61, max: 11, min: 5, precipSum: 12, probMax: 90, windMax: 45, windMean: 30, humidityMean: 90, uvMax: 1 },
    ]);
    const outdoor = computePlanner(bundle.daily).find((c) => c.key === 'outdoor')!;
    expect(outdoor.winnerDate).toBe(bundle.daily[0].date);
    // Os dois dias chuvosos ficam marcados como a evitar.
    const avoidDates = outdoor.daysToAvoid.map((d) => d.date);
    expect(avoidDates).toContain(bundle.daily[1].date);
    expect(avoidDates).toContain(bundle.daily[2].date);
  });

  it('devolve sufficientData=false sem dados diários', () => {
    const bundle = bundleWithDays([]);
    const [carWash] = computePlanner(bundle.daily);
    expect(carWash.sufficientData).toBe(false);
    expect(carWash.winnerLabel).toBe('Indisponível');
  });

  it('inclui os quatro critérios obrigatórios com labels pt-PT', () => {
    const bundle = bundleWithDays([
      { code: 0, max: 22, min: 14, precipSum: 0, probMax: 5, windMax: 12, windMean: 8, humidityMean: 50, uvMax: 5 },
    ]);
    const criteria = computePlanner(bundle.daily);
    expect(criteria.map((c) => c.key)).toEqual(['car-wash', 'laundry', 'outdoor', 'picnic']);
    expect(criteria[0].label).toBe('Lavar o carro');
    expect(criteria[1].label).toBe('Estender roupa');
    expect(criteria[2].label).toBe('Atividades ao ar livre');
    expect(criteria[3].label).toBe('Passeio / Picnic');
  });
});
