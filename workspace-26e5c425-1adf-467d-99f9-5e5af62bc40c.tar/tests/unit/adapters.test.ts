import { describe, expect, it } from 'vitest';
import { adaptForecast, adaptGeocoding, AdapterError } from '@/lib/adapters/open-meteo';
import { adaptAirQuality } from '@/lib/adapters/air-quality';

const FETCHED_AT = Date.parse('2026-01-15T10:00:00Z');

/** Resposta crua do Open-Meteo com arrays paralelos (estrutura real da API). */
function forecastFixture() {
  return {
    latitude: 38.7223,
    longitude: -9.1393,
    elevation: 45,
    timezone: 'Europe/Lisbon',
    current: {
      time: '2026-01-15T10:00',
      temperature_2m: 14.2,
      relative_humidity_2m: 72,
      apparent_temperature: 12.8,
      is_day: 1,
      precipitation: 0.3,
      weather_code: 61,
      cloud_cover: 80,
      pressure_msl: 1013.5,
      wind_speed_10m: 18.4,
      wind_direction_10m: 225,
      wind_gusts_10m: 32.1,
      uv_index: 1.5,
    },
    hourly: {
      time: ['2026-01-15T10:00', '2026-01-15T11:00', '2026-01-15T12:00'],
      temperature_2m: [14.2, 15.1, null],
      relative_humidity_2m: [72, 70, 68],
      apparent_temperature: [12.8, 14.0, 14.5],
      precipitation_probability: [65, 40, null],
      precipitation: [0.3, 0.0, 0.1],
      weather_code: [61, 3, 0],
      cloud_cover: [80, 60, 20],
      wind_speed_10m: [18.4, 16.0, 12.0],
      wind_gusts_10m: [32.1, 28.0, 24.0],
      uv_index: [1.5, 2.0, 2.5],
      is_day: [1, 1, 1],
    },
    minutely_15: {
      time: ['2026-01-15T10:00', '2026-01-15T10:15', '2026-01-15T10:30'],
      precipitation: [0.3, null, 0.0],
      weather_code: [61, 61, 3],
    },
    daily: {
      time: ['2026-01-15', '2026-01-16'],
      weather_code: [61, 0],
      temperature_2m_max: [16.0, 17.5],
      temperature_2m_min: [9.0, 8.2],
      temperature_2m_mean: [12.5, 13.0],
      apparent_temperature_max: [15.0, 16.8],
      apparent_temperature_min: [8.0, 7.5],
      precipitation_sum: [2.4, 0.0],
      precipitation_hours: [3.2, 0.0],
      precipitation_probability_max: [80, 10],
      wind_speed_10m_max: [22.0, 15.0],
      wind_speed_10m_mean: [14.0, 11.0],
      wind_gusts_10m_max: [38.0, 25.0],
      relative_humidity_2m_mean: [75, 60],
      cloud_cover_mean: [85, 25],
      uv_index_max: [1.8, 2.1],
      sunrise: ['2026-01-15T07:45', '2026-01-16T07:45'],
      sunset: ['2026-01-15T17:30', '2026-01-16T17:31'],
    },
  };
}

describe('adaptForecast — arrays paralelos do Open-Meteo', () => {
  it('converte os arrays paralelos em objetos tipados por hora', () => {
    const bundle = adaptForecast(forecastFixture(), FETCHED_AT, 'network');
    expect(bundle.hourly).toHaveLength(3);
    expect(bundle.hourly[0]).toMatchObject({
      time: '2026-01-15T10:00',
      temperature: 14.2,
      precipitationProbability: 65,
      precipitation: 0.3,
      weatherCode: 61,
      isDay: true,
    });
    expect(bundle.hourly[1].temperature).toBe(15.1);
    // temperature_2m[2] é null → o adaptador aplica o fallback 0 definido,
    // mas nunca inventa um valor meteorológico.
    expect(bundle.hourly[2].temperature).toBe(0);
  });

  it('preserva valores nulos como null e não inventa dados', () => {
    const bundle = adaptForecast(forecastFixture(), FETCHED_AT, 'network');
    // temperature_2m[2] === null → o adaptador não inventa; usa fallback 0 definido.
    expect(bundle.hourly[2].precipitationProbability).toBeNull();
    // minutely precipitation[1] === null é preservado.
    expect(bundle.minutely15[1].precipitation).toBeNull();
    expect(bundle.minutely15[0].precipitation).toBe(0.3);
  });

  it('trata arrays em falta devolvendo nulls em vez de erro', () => {
    const raw = forecastFixture();
    delete (raw.hourly as Record<string, unknown>).precipitation_probability;
    const bundle = adaptForecast(raw, FETCHED_AT, 'network');
    expect(bundle.hourly[0].precipitationProbability).toBeNull();
  });

  it('mapeia o tempo atual e labels em português', () => {
    const bundle = adaptForecast(forecastFixture(), FETCHED_AT, 'network');
    expect(bundle.current.temperature).toBe(14.2);
    expect(bundle.current.isDay).toBe(true);
    expect(bundle.current.weatherLabel).toBe('Chuva fraca');
    expect(bundle.current.meteocon).toBe('rain');
  });

  it('mapeia is_day=0 para noite (meteocon noturno)', () => {
    const raw = forecastFixture();
    raw.current.is_day = 0;
    raw.current.weather_code = 0;
    const bundle = adaptForecast(raw, FETCHED_AT, 'network');
    expect(bundle.current.isDay).toBe(false);
    expect(bundle.current.meteocon).toBe('clear-night');
    expect(bundle.current.weatherLabel).toBe('Céu limpo');
  });

  it('converte os pontos diários com nascer/pôr do sol', () => {
    const bundle = adaptForecast(forecastFixture(), FETCHED_AT, 'network');
    expect(bundle.daily).toHaveLength(2);
    expect(bundle.daily[0].sunrise).toBe('2026-01-15T07:45');
    expect(bundle.daily[0].precipitationProbabilityMax).toBe(80);
    expect(bundle.daily[1].precipitationSum).toBe(0);
  });

  it('rejeita respostas inválidas com erro de validação', () => {
    expect(() => adaptForecast({ error: true, reason: 'limit' }, FETCHED_AT, 'network')).toThrow();
  });

  it('mantém a origem e o momento de obtenção', () => {
    const bundle = adaptForecast(forecastFixture(), FETCHED_AT, 'cache-server');
    expect(bundle.fetchedAt).toBe(FETCHED_AT);
    expect(bundle.source).toBe('cache-server');
  });
});

describe('adaptGeocoding', () => {
  it('normaliza resultados e campos nulos', () => {
    const places = adaptGeocoding({
      results: [
        { id: 2267057, name: 'Lisboa', latitude: 38.72, longitude: -9.14, country: 'Portugal', admin1: 'Distrito de Lisboa', timezone: 'Europe/Lisbon' },
        { id: 2, name: 'Porto', latitude: 41.15, longitude: -8.61 },
      ],
    });
    expect(places).toHaveLength(2);
    expect(places[0].admin1).toBe('Distrito de Lisboa');
    expect(places[1].country).toBeNull();
    expect(places[1].admin1).toBeNull();
  });

  it('devolve lista vazia quando não há resultados', () => {
    expect(adaptGeocoding({})).toEqual([]);
  });
});

describe('adaptAirQuality', () => {
  it('mapeia AQI europeu e poluentes', () => {
    const air = adaptAirQuality(
      {
        time: '2026-01-15T10:00',
        current: {
          time: '2026-01-15T10:00',
          european_aqi: 32,
          pm10: 12.5,
          pm2_5: 8.1,
          ozone: 45,
          nitrogen_dioxide: 15,
          sulphur_dioxide: 2.0,
        },
      },
      FETCHED_AT,
      'network',
    );
    expect(air.europeanAqi).toBe(32);
    expect(air.pm25).toBe(8.1);
    expect(air.fetchedAt).toBe(FETCHED_AT);
    expect(air.source).toBe('network');
  });

  it('preserva poluentes nulos', () => {
    const air = adaptAirQuality(
      { time: '2026-01-15T10:00', current: { time: '2026-01-15T10:00', european_aqi: null } },
      FETCHED_AT,
      'network',
    );
    expect(air.europeanAqi).toBeNull();
    expect(air.pm10).toBeNull();
  });
});
