import { describe, expect, it } from 'vitest';
import { computeRecommendations } from '@/lib/engines/recommendations';
import { buildSmartSummary } from '@/lib/engines/summary';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';
import { defaultProfile } from '@/lib/schemas/report.schema';
import type { AirQualityBundle, ForecastBundle, RainCountdownResult, WeatherAlert } from '@/lib/types';

const NOW = Date.parse('2026-01-15T10:00:00Z');

function bundle(): ForecastBundle {
  const hours: string[] = [];
  for (let i = 0; i < 24; i++) {
    hours.push(new Date(NOW + i * 3600000).toISOString().slice(0, 13) + ':00');
  }
  return adaptForecast(
    openMeteoForecastSchema.parse({
      latitude: 38.7223,
      longitude: -9.1393,
      timezone: 'Europe/Lisbon',
      current: {
        time: '2026-01-15T10:00',
        temperature_2m: 13.5,
        relative_humidity_2m: 78,
        apparent_temperature: 11.2,
        is_day: 1,
        precipitation: 0,
        weather_code: 3,
        cloud_cover: 90,
        wind_speed_10m: 22,
        wind_direction_10m: 210,
        wind_gusts_10m: 45,
        uv_index: 2.1,
      },
      hourly: {
        time: hours,
        temperature_2m: hours.map((_, i) => 12 + (i % 5)),
        relative_humidity_2m: hours.map((_, i) => (i % 3 === 0 ? 45 : 75)),
        apparent_temperature: hours.map((_, i) => 10.5 + (i % 4)),
        precipitation_probability: hours.map((_, i) => (i === 6 ? 85 : 10)),
        precipitation: hours.map((_, i) => (i === 6 ? 1.2 : 0)),
        weather_code: hours.map((_, i) => (i === 6 ? 61 : 2)),
        wind_speed_10m: hours.map((_, i) => (i % 2 === 0 ? 12 : 20)),
        wind_gusts_10m: hours.map((_, i) => (i % 2 === 0 ? 24 : 34)),
        uv_index: hours.map(() => 2.0),
        is_day: hours.map(() => 1),
      },
      daily: {
        time: ['2026-01-15'],
        weather_code: [3],
        temperature_2m_max: [16.2],
        temperature_2m_min: [9.1],
        precipitation_sum: [2.5],
        precipitation_probability_max: [75],
        wind_speed_10m_max: [25],
        wind_gusts_10m_max: [45],
        relative_humidity_2m_mean: [78],
        uv_index_max: [2.2],
        sunrise: ['2026-01-15T07:45'],
        sunset: ['2026-01-15T17:30'],
      },
    }),
    NOW,
    'network',
  );
}

describe('computeRecommendations — "INTELIGÊNCIA PARA TI"', () => {
  it('devolve até 4 recomendações com índice e confiança válidos', () => {
    const items = computeRecommendations(bundle(), NOW, defaultProfile);
    expect(items.length).toBeGreaterThan(0);
    expect(items.length).toBeLessThanOrEqual(4);
    for (const item of items) {
      expect(item.score).toBeGreaterThanOrEqual(0);
      expect(item.score).toBeLessThanOrEqual(100);
      expect(item.confidence).toBeGreaterThanOrEqual(60);
      expect(item.confidence).toBeLessThanOrEqual(100);
      expect(item.justification.length).toBeGreaterThan(10);
      expect(item.hour).not.toBe('');
    }
  });

  it('inclui as categorias esperadas (sair, correr, passear, roupa)', () => {
    const items = computeRecommendations(bundle(), NOW, defaultProfile);
    const keys = items.map((i) => i.key);
    expect(keys).toContain('sair');
    expect(keys).toContain('correr');
    expect(keys).toContain('passear');
    expect(keys).toContain('roupa');
  });

  it('sem horas futuras devolve recomendação indisponível', () => {
    const b = bundle();
    const pastOnly = computeRecommendations({ ...b, hourly: [] }, NOW, defaultProfile);
    expect(pastOnly).toHaveLength(1);
    expect(pastOnly[0].sufficientData).toBe(false);
    expect(pastOnly[0].title).toContain('indisponíveis');
  });

  it('utilizador sensível ao frio recebe indicador pessoal', () => {
    const b = bundle();
    const coldProfile = { ...defaultProfile, coldSensitivity: 5 };
    const items = computeRecommendations(
      { ...b, current: { ...b.current, apparentTemperature: 8 } },
      NOW,
      coldProfile,
    );
    expect(items[0].key).toBe('frio-personalizado');
    expect(items[0].justification).toContain('5/5');
  });
});

describe('buildSmartSummary — resumo de 1 a 3 frases', () => {
  const air: AirQualityBundle = {
    time: '',
    europeanAqi: 34,
    pm10: null,
    pm25: null,
    ozone: null,
    no2: null,
    so2: null,
    fetchedAt: NOW,
    source: 'network',
  };
  const clearCountdown: RainCountdownResult = {
    status: 'clear',
    minutesUntilStart: null,
    durationMinutes: null,
    expectedIntensity: null,
    headline: 'Sem chuva nas próximas 2 horas',
    detail: '',
  };

  it('produz frase com condição, temperatura e extremos do dia', () => {
    const summary = buildSmartSummary(bundle(), air, clearCountdown, []);
    expect(summary).toContain('Encoberto');
    expect(summary).toContain('a 14°');
    expect(summary).toContain('entre 9° e 16° hoje');
  });

  it('inclui a contagem de chuva quando é iminente', () => {
    const imminent: RainCountdownResult = {
      status: 'imminent',
      minutesUntilStart: 30,
      durationMinutes: 60,
      expectedIntensity: 0.6,
      headline: 'Chuva moderada em 30 min',
      detail: '',
    };
    const summary = buildSmartSummary(bundle(), air, imminent, []);
    expect(summary).toContain('Chuva moderada em 30 min');
  });

  it('menciona rajadas fortes e qualidade do ar quando relevantes', () => {
    const summary = buildSmartSummary(bundle(), air, clearCountdown, []);
    // Rajadas de 45 km/h ≥ 40 → incluídas.
    expect(summary).toContain('rajadas');
    expect(summary).toContain('AQI 34');
  });

  it('cita o aviso oficial IPMA com a cor', () => {
    const alerts: WeatherAlert[] = [
      {
        id: 'ipma-1',
        origin: 'ipma',
        severity: 'warning',
        officialLevel: 'orange',
        title: 'Precipitação — Faro',
        description: '',
        start: null,
        end: null,
        area: 'Faro',
        createdAt: NOW,
      },
    ];
    const summary = buildSmartSummary(bundle(), null, clearCountdown, alerts);
    expect(summary).toContain('laranja');
    expect(summary).toContain('Faro');
  });
});
