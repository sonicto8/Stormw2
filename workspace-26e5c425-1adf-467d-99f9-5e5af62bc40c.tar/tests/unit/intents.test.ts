import { describe, expect, it } from 'vitest';
import { buildIntentAnswer, detectIntent, extractNumbers, MANDATORY_QUESTIONS } from '@/lib/engines/intents';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';
import { defaultProfile } from '@/lib/schemas/report.schema';
import type { AirQualityBundle, ForecastBundle } from '@/lib/types';

const NOW = Date.parse('2026-01-15T10:00:00Z');

function bundleFixture(): ForecastBundle {
  const hours: string[] = [];
  for (let i = 0; i < 24; i++) {
    hours.push(new Date(NOW + i * 3600000).toISOString().slice(0, 13) + ':00');
  }
  const n15: string[] = [];
  for (let i = 0; i < 8; i++) {
    n15.push(new Date(NOW + i * 15 * 60000).toISOString().slice(0, 16));
  }
  return adaptForecast(
    openMeteoForecastSchema.parse({
      latitude: 38.7223,
      longitude: -9.1393,
      timezone: 'Europe/Lisbon',
      current: {
        time: '2026-01-15T10:00',
        temperature_2m: 13.5,
        relative_humidity_2m: 78,
        apparent_temperature: 11.2,
        is_day: 1,
        precipitation: 0,
        weather_code: 3,
        cloud_cover: 90,
        wind_speed_10m: 22,
        wind_direction_10m: 210,
        wind_gusts_10m: 45,
        uv_index: 2.1,
      },
      hourly: {
        time: hours,
        temperature_2m: hours.map((_, i) => 12 + (i % 5)),
        relative_humidity_2m: hours.map(() => 75),
        apparent_temperature: hours.map((_, i) => 10.5 + (i % 4)),
        precipitation_probability: hours.map((_, i) => (i === 6 ? 85 : 10)),
        precipitation: hours.map((_, i) => (i === 6 ? 1.2 : 0)),
        weather_code: hours.map((_, i) => (i === 6 ? 61 : 2)),
        wind_speed_10m: hours.map(() => 18),
        wind_gusts_10m: hours.map(() => 34),
        uv_index: hours.map(() => 2.0),
        is_day: hours.map(() => 1),
      },
      minutely_15: {
        time: n15,
        precipitation: n15.map(() => 0),
        weather_code: n15.map(() => 2),
      },
      daily: {
        time: ['2026-01-15', '2026-01-16', '2026-01-17', '2026-01-18', '2026-01-19'],
        weather_code: [3, 0, 0, 2, 61],
        temperature_2m_max: [16.2, 18.0, 19.1, 17.4, 15.0],
        temperature_2m_min: [9.1, 8.4, 9.8, 10.2, 8.0],
        precipitation_sum: [2.5, 0.0, 0.0, 0.0, 6.0],
        precipitation_probability_max: [75, 10, 5, 15, 85],
        wind_speed_10m_max: [25, 15, 14, 16, 30],
        wind_gusts_10m_max: [45, 25, 22, 26, 55],
        relative_humidity_2m_mean: [78, 60, 55, 62, 88],
        uv_index_max: [2.2, 2.5, 2.6, 2.4, 1.8],
        sunrise: ['2026-01-15T07:45', '2026-01-16T07:45', '2026-01-17T07:44', '2026-01-18T07:44', '2026-01-19T07:43'],
        sunset: ['2026-01-15T17:30', '2026-01-16T17:31', '2026-01-17T17:32', '2026-01-18T17:33', '2026-01-19T17:34'],
      },
    }),
    NOW,
    'network',
  );
}

const AIR: AirQualityBundle = {
  time: '2026-01-15T10:00',
  europeanAqi: 34,
  pm10: 14,
  pm25: 9,
  ozone: 40,
  no2: 12,
  so2: 1.5,
  fetchedAt: NOW,
  source: 'network',
};

describe('detectIntent — perguntas obrigatórias da especificação', () => {
  it('identifica as cinco perguntas obrigatórias', () => {
    expect(MANDATORY_QUESTIONS).toHaveLength(5);
    expect(detectIntent('Preciso de guarda-chuva hoje?')).toBe('chuva');
    expect(detectIntent('O que devo vestir?')).toBe('vestuario');
    expect(detectIntent('Qual a melhor hora para correr?')).toBe('corrida');
    expect(detectIntent('É bom dia para a praia?')).toBe('praia');
    expect(detectIntent('Posso lavar o carro amanhã?')).toBe('lavagem_carro');
  });

  it('é robusto a acentos, maiúsculas e pontuação', () => {
    expect(detectIntent('PRECISO DE GUARDA-CHUVA?!')).toBe('chuva');
    expect(detectIntent('posso lavar o carro')).toBe('lavagem_carro');
    expect(detectIntent('Vai ventar muito?')).toBe('vento');
    expect(detectIntent('Está frio lá fora?')).toBe('frio');
    expect(detectIntent('Faz calor amanhã?')).toBe('calor');
    expect(detectIntent('quando há sol?')).toBe('sol');
    expect(detectIntent('o índice UV está alto?')).toBe('uv');
  });

  it('devolve null para texto sem correspondência de intenção', () => {
    expect(detectIntent('qual é a capital da União Europeia?')).toBeNull();
  });
});

describe('buildIntentAnswer — respostas só com números da API', () => {
  const ctx = { bundle: bundleFixture(), air: AIR, nowMs: NOW };

  it('responde à pergunta da chuva com valores calculados', () => {
    const answer = buildIntentAnswer('Preciso de guarda-chuva hoje?', ctx, defaultProfile);
    expect(answer.intent).toBe('chuva');
    // minutely seco → clear; a próxima chuva está às 16h (índice 6) com 85%.
    expect(answer.text).toContain('85%');
    expect(answer.text).toContain('16h');
    // Os detalhes incluem o estado do countdown.
    expect(answer.details.join(' ')).toContain('Sem chuva');
  });

  it('responde ao vestuário com base na sensação térmica e rajadas', () => {
    const answer = buildIntentAnswer('O que devo vestir?', ctx, defaultProfile);
    expect(answer.intent).toBe('vestuario');
    expect(answer.text).toContain('11°');
    expect(answer.text).toContain('corta-vento');
    expect(answer.details[0]).toContain('78%');
  });

  it('responde à corrida com a melhor hora e o índice', () => {
    const answer = buildIntentAnswer('Qual a melhor hora para correr?', ctx, defaultProfile);
    expect(answer.intent).toBe('corrida');
    expect(answer.text).toMatch(/índice de corrida \d+\/100/);
    expect(answer.details[0]).toMatch(/Índice geral: \d+\/100/);
  });

  it('responde à praia com veredicto e UV máximo', () => {
    const answer = buildIntentAnswer('É bom dia para a praia?', ctx, defaultProfile);
    expect(answer.intent).toBe('praia');
    expect(answer.text).toContain('16°');
  });

  it('responde à lavagem do carro com base nos próximos 5 dias', () => {
    const answer = buildIntentAnswer('Posso lavar o carro amanhã?', ctx, defaultProfile);
    expect(answer.intent).toBe('lavagem_carro');
    // Dias 2, 3 e 4 são secos (0 mm, prob ≤ 15%) → sim.
    expect(answer.text).toMatch(/Sim —/);
    expect(answer.text).toContain('10%');
  });

  it('resposta fallback resume o estado sem inventar valores', () => {
    const answer = buildIntentAnswer('Diz-me algo sobre o tempo', ctx, defaultProfile);
    expect(answer.intent).toBe('fallback');
    expect(answer.text).toContain('14°'); // 13.5 arredondado na apresentação
    expect(answer.text).toContain('AQI 34');
  });

  it('nunca introduz números fora dos dados de origem', () => {
    const bundleJson = JSON.stringify(ctx.bundle) + JSON.stringify(AIR) + JSON.stringify(defaultProfile);
    const sourceNumbers = extractNumbers(bundleJson).map((n) => Number(n.replace(',', '.')));
    const questions = ['Vai chover?', 'O que devo vestir?', 'melhor hora para correr?', 'praia?', 'lavar o carro?', 'Faz calor?', 'Está frio?', 'vento forte?', 'índice uv?', 'há sol?'];
    for (const q of questions) {
      const answer = buildIntentAnswer(q, ctx, defaultProfile);
      for (const raw of extractNumbers(answer.text + ' ' + answer.details.join(' '))) {
        const value = Number(raw.replace(',', '.'));
        if (Number.isNaN(value)) continue;
        // Invariante anti-alucinação: cada número é (a) proveniente dos dados
        // (com tolerância de arredondamento) ou (b) um índice derivado 0–100.
        const fromSource = sourceNumbers.some((s) => Math.abs(s - value) < 1);
        const derivedIndex = value >= 0 && value <= 100;
        expect(fromSource || derivedIndex).toBe(true);
      }
    }
  });
});

describe('extractNumbers', () => {
  it('extrai inteiros e decimais com vírgula ou ponto', () => {
    expect(extractNumbers('Sensação de 11.2 °C e 45% de prob.')).toEqual(['11.2', '45']);
    expect(extractNumbers('Chuva em 30 min, 1,5 mm')).toEqual(['30', '1,5']);
  });
});
