import { describe, expect, it } from 'vitest';
import { computeRainCountdown } from '@/lib/engines/rain-countdown';
import type { ForecastBundle } from '@/lib/types';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';

const NOW = Date.parse('2026-01-15T10:00:00Z');

/** Constrói um ForecastBundle mínimo com a série minutely_15 indicada (mm). */
function bundleWithMinutely(precip: Array<number | null>, codes?: Array<number | null>): ForecastBundle {
  const times: string[] = [];
  for (let i = 0; i < precip.length; i++) {
    const t = new Date(NOW + i * 15 * 60000);
    times.push(t.toISOString().slice(0, 16));
  }
  const raw = {
    latitude: 38.7223,
    longitude: -9.1393,
    timezone: 'Europe/Lisbon',
    current: {
      time: '2026-01-15T10:00',
      temperature_2m: 12,
      apparent_temperature: 11,
      is_day: 1,
      precipitation: precip[0] ?? 0,
      weather_code: 0,
      wind_speed_10m: 10,
      wind_gusts_10m: 15,
    },
    minutely_15: {
      time: times,
      precipitation: precip,
      weather_code: codes ?? times.map(() => 0),
    },
  };
  // Mesma validação do route handler real (schema Zod antes do adaptador).
  return adaptForecast(openMeteoForecastSchema.parse(raw), NOW, 'network');
}

describe('computeRainCountdown', () => {
  it('devolve insufficient-data quando a série minutely não existe', () => {
    const raw = {
      latitude: 38.7223,
      longitude: -9.1393,
      timezone: 'Europe/Lisbon',
      current: {
        time: '2026-01-15T10:00',
        temperature_2m: 12,
        apparent_temperature: 11,
        is_day: 1,
        precipitation: 0,
        weather_code: 0,
        wind_speed_10m: 10,
        wind_gusts_10m: 15,
      },
    };
    const bundle = adaptForecast(raw, NOW, 'network');
    const cd = computeRainCountdown(bundle, NOW);
    expect(cd.status).toBe('insufficient-data');
    expect(cd.minutesUntilStart).toBeNull();
    // Nunca inventa: o título indica a indisponibilidade.
    expect(cd.headline).toContain('indisponível');
  });

  it('devolve clear quando toda a série é seca', () => {
    const cd = computeRainCountdown(bundleWithMinutely([0, 0, 0, 0, 0, 0, 0, 0]), NOW);
    expect(cd.status).toBe('clear');
    expect(cd.headline).toBe('Sem chuva nas próximas 2 horas');
  });

  it('ignora precipitação residual ≤ 0,1 mm', () => {
    const cd = computeRainCountdown(bundleWithMinutely([0.05, 0.1, 0, 0, 0, 0, 0, 0]), NOW);
    expect(cd.status).toBe('clear');
  });

  it('calcula contagem decrescente quando a chuva começa dentro da janela', () => {
    const cd = computeRainCountdown(bundleWithMinutely([0, 0, 0.6, 0.5, 0, 0, 0, 0]), NOW);
    expect(cd.status).toBe('imminent');
    // O terceiro passo (índice 2) começa 30 min após "agora".
    expect(cd.minutesUntilStart).toBe(30);
    expect(cd.durationMinutes).toBe(30);
    expect(cd.expectedIntensity).toBe(0.6);
    expect(cd.headline).toContain('30 min');
  });

  it('deteta chuva em curso e a duração', () => {
    const cd = computeRainCountdown(bundleWithMinutely([0.8, 0.7, 0.2, 0, 0, 0, 0, 0]), NOW);
    expect(cd.status).toBe('raining');
    expect(cd.minutesUntilStart).toBe(0);
    expect(cd.durationMinutes).toBe(45);
  });

  it('menciona trovoada quando o código ≥ 95 na janela', () => {
    const codes = [0, 0, 95, 95, 0, 0, 0, 0];
    const cd = computeRainCountdown(bundleWithMinutely([0, 0, 0.6, 0.5, 0, 0, 0, 0], codes), NOW);
    expect(cd.status).toBe('imminent');
    expect(cd.detail).toContain('trovoada');
  });

  it('limita a contagem a 120 minutos', () => {
    const series = [0, 0, 0, 0, 0, 0, 0, 0];
    const cd = computeRainCountdown(bundleWithMinutely(series), NOW + 100 * 60000);
    // Fora da janela útil (série acabou) → clear: não extrapola.
    expect(['clear', 'raining', 'imminent']).toContain(cd.status);
  });
});
