import { describe, expect, it } from 'vitest';
import { computeAlerts, ipmaToAlerts, filterIpmaForArea } from '@/lib/engines/alerts';
import { adaptForecast } from '@/lib/adapters/open-meteo';
import { openMeteoForecastSchema } from '@/lib/schemas/open-meteo.schema';
import { defaultProfile } from '@/lib/schemas/report.schema';
import type { ForecastBundle, IpmaWarning } from '@/lib/types';

const NOW = Date.parse('2026-01-15T10:00:00Z');

/** Bundle base com condições neutras e afinações pontuais. */
function bundle(overrides: Partial<{
  temp: number;
  feels: number;
  gusts: number;
  wind: number;
  code: number;
  minutely: Array<number | null>;
  minutelyCodes: Array<number | null>;
}>, now = NOW): ForecastBundle {
  const minutelyTimes: string[] = [];
  const n = overrides.minutely?.length ?? 0;
  for (let i = 0; i < n; i++) {
    minutelyTimes.push(new Date(now + i * 15 * 60000).toISOString().slice(0, 16));
  }
  return adaptForecast(
    openMeteoForecastSchema.parse({
      latitude: 38.7223,
      longitude: -9.1393,
      timezone: 'Europe/Lisbon',
      current: {
        time: '2026-01-15T10:00',
        temperature_2m: overrides.temp ?? 18,
        apparent_temperature: overrides.feels ?? 18,
        is_day: 1,
        precipitation: 0,
        weather_code: overrides.code ?? 0,
        wind_speed_10m: overrides.wind ?? 10,
        wind_gusts_10m: overrides.gusts ?? 20,
      },
      minutely_15: overrides.minutely
        ? {
            time: minutelyTimes,
            precipitation: overrides.minutely,
            weather_code: overrides.minutelyCodes ?? minutelyTimes.map(() => 0),
          }
        : undefined,
    }),
    NOW,
    'network',
  );
}

const ipmaWarning = (level: IpmaWarning['level'], area: string): IpmaWarning => ({
  id: `${area}-${level}`,
  level,
  area,
  phenomen: 'precipitation',
  phenomenLabel: 'Precipitação',
  description: `Aviso ${level} de teste`,
  start: '2026-01-15T10:00',
  end: '2026-01-15T18:00',
});

describe('ipmaToAlerts — cores oficiais preservadas', () => {
  it('mapeia níveis para severidade mantendo officialLevel', () => {
    const alerts = ipmaToAlerts([ipmaWarning('yellow', 'Lisboa'), ipmaWarning('orange', 'Faro'), ipmaWarning('red', 'Porto')], NOW);
    expect(alerts).toHaveLength(3);
    expect(alerts[0]).toMatchObject({ severity: 'info', officialLevel: 'yellow', area: 'Lisboa' });
    expect(alerts[1]).toMatchObject({ severity: 'warning', officialLevel: 'orange', area: 'Faro' });
    expect(alerts[2]).toMatchObject({ severity: 'critical', officialLevel: 'red', area: 'Porto' });
    // Origem oficial em todos — o UI usa a cor oficial do IPMA.
    expect(alerts.every((a) => a.origin === 'ipma' && a.officialLevel !== null)).toBe(true);
  });
});

describe('filterIpmaForArea', () => {
  it('filtra por área com acentos normalizados', () => {
    const warnings = [ipmaWarning('yellow', 'Évora'), ipmaWarning('orange', 'Porto')];
    const filtered = filterIpmaForArea(warnings, 'Évora');
    expect(filtered).toHaveLength(1);
    expect(filtered[0].area).toBe('Évora');
  });

  it('devolve todos quando a área não corresponde a nada', () => {
    const warnings = [ipmaWarning('yellow', 'Lisboa'), ipmaWarning('orange', 'Porto')];
    expect(filterIpmaForArea(warnings, 'Funchal')).toHaveLength(2);
  });
});

describe('computeAlerts — regras internas', () => {
  it('não gera alertas com condições neutras', () => {
    const alerts = computeAlerts(bundle({}), null, [], 'Lisboa', NOW, defaultProfile);
    expect(alerts).toHaveLength(0);
  });

  it('alerta precipitação iminente (> 0,1 mm/15min) com severidade info a 30 min', () => {
    const alerts = computeAlerts(bundle({ minutely: [0, 0, 0.5, 0] }), null, [], 'Lisboa', NOW, defaultProfile);
    const rain = alerts.find((a) => a.id === 'rain-imminent');
    expect(rain).toBeDefined();
    expect(rain!.description).toContain('0.5 mm/15 min');
    // A 30 min de distância → severidade info.
    expect(rain!.severity).toBe('info');
  });

  it('escala para warning quando a chuva é imediata (≤ 15 min)', () => {
    const alerts = computeAlerts(bundle({ minutely: [0.5, 0, 0] }), null, [], 'Lisboa', NOW + 10 * 60000, defaultProfile);
    const rain = alerts.find((a) => a.id === 'rain-imminent');
    expect(rain!.severity).toBe('warning');
  });

  it('alerta trovoada com código 95–99', () => {
    const alerts = computeAlerts(bundle({ code: 95 }), null, [], 'Lisboa', NOW, defaultProfile);
    expect(alerts.some((a) => a.id === 'thunder')).toBe(true);
  });

  it('rajadas ≥ 60 → warning; ≥ 90 → critical', () => {
    const warnings = computeAlerts(bundle({ gusts: 65 }), null, [], 'Lisboa', NOW, defaultProfile);
    expect(warnings.some((a) => a.id === 'gust-warning' && a.severity === 'warning')).toBe(true);
    const critical = computeAlerts(bundle({ gusts: 95 }), null, [], 'Lisboa', NOW, defaultProfile);
    expect(critical.some((a) => a.id === 'gust-critical' && a.severity === 'critical')).toBe(true);
  });

  it('calor ≥ 35°C → critical; frio sensação ≤ 0°C → warning', () => {
    const heat = computeAlerts(bundle({ temp: 36 }), null, [], 'Lisboa', NOW, defaultProfile);
    expect(heat.some((a) => a.id === 'heat' && a.severity === 'critical')).toBe(true);
    const cold = computeAlerts(bundle({ temp: 2, feels: -3 }), null, [], 'Lisboa', NOW, defaultProfile);
    expect(cold.some((a) => a.id === 'cold' && a.severity === 'warning')).toBe(true);
  });

  it('AQI > 60 → warning para sensíveis; > 100 → critical', () => {
    const moderate = computeAlerts(bundle({}), { time: '', europeanAqi: 70, pm10: null, pm25: null, ozone: null, no2: null, so2: null, fetchedAt: NOW, source: 'network' }, [], 'Lisboa', NOW, defaultProfile);
    expect(moderate.some((a) => a.id === 'aqi-sensitive' && a.severity === 'warning')).toBe(true);
    const bad = computeAlerts(bundle({}), { time: '', europeanAqi: 110, pm10: null, pm25: null, ozone: null, no2: null, so2: null, fetchedAt: NOW, source: 'network' }, [], 'Lisboa', NOW, defaultProfile);
    expect(bad.some((a) => a.id === 'aqi-all' && a.severity === 'critical')).toBe(true);
  });

  it('respeita os tipos de alerta escolhidos no perfil', () => {
    const profile = { ...defaultProfile, alertTypes: ['rain'] };
    const alerts = computeAlerts(bundle({ code: 95, gusts: 95 }), null, [], 'Lisboa', NOW, profile);
    expect(alerts.some((a) => a.id === 'thunder')).toBe(false);
    expect(alerts.some((a) => a.id === 'gust-critical')).toBe(false);
  });

  it('ordena críticos primeiro e oficiais antes dos internos', () => {
    const alerts = computeAlerts(
      bundle({ gusts: 95, code: 95 }),
      null,
      [ipmaWarning('yellow', 'Lisboa')],
      'Lisboa',
      NOW,
      defaultProfile,
    );
    expect(alerts[0].severity).toBe('critical');
    const firstInfo = alerts.findIndex((a) => a.severity === 'info');
    // O aviso IPMA (info) precede quaisquer internos do mesmo nível.
    if (firstInfo !== -1) {
      expect(alerts[firstInfo].origin).toBe('ipma');
    }
  });
});
