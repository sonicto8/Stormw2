# STORMWATCH — Guia simples

> Guia curto: o que é, como funciona, como se usa, em que telemóveis funciona e como instalar no **iPhone** e no **Android**. Para os detalhes técnicos de publicação, vê o [DEPLOY.md](./DEPLOY.md).

---

## 1. O que é e como funciona

A STORMWATCH é uma aplicação web meteorológica para Portugal que corre no navegador (PC, iPhone e Android) — **sem loja de aplicações**.

**De onde vêm os dados?**

| Dados | Fonte oficial |
| --- | --- |
| Previsão, temperatura, vento, humidade, UV, ar | Open-Meteo |
| Avisos e alertas oficiais (amarelo / laranja / vermelho) | IPMA |
| Radares de chuva e mapas | RainViewer |
| Pesquisa de cidades | Open-Meteo Geocoding |

Tudo passa pelo servidor da aplicação (com cache de 10 minutos e validação de dados) — o teu telemóvel nunca fala diretamente com as fontes externas. Se a internet falhar, a app mostra os últimos dados guardados e avisa «Offline».

---

## 2. Como se usa (os 7 separadores)

- **Início** — tempo atual, próxima hora de chuva (contagem decrescente), 24 h/48 h hora a hora, 7 dias, gráficos, nascer/pôr do sol, qualidade do ar e sugestões (levar guarda-chuva? o que vestir?).
- **Alertas** — avisos oficiais do IPMA por distrito, com as cores oficiais, e alertas internos gerados automaticamente (chuva forte, vento forte, temperaturas extremas).
- **Assistente (STORM AI)** — escreve em linguagem normal: «Vai chover amanhã em Braga?» e recebe respostas com os dados reais.
- **Radar** — mapa de chuva em tempo real com camadas **Escuro / Claro / Satélite** e animação da precipitação.
- **Comunidade** — comentários em tempo real de quem está a ver o tempo em qualquer ponto do país. Todos podem publicar.
- **Planeador** — resumo de hoje e de amanhã, histórico dos últimos 7 dias e índices de atividade.
- **Definições** — localização, **Aparência (claro / escuro / automático)**, notificações e **2 contactos de emergência**.

**Emergência:** em Definições guardas 2 contactos. Se ocorrer um desastre, um botão partilha a tua localização por **WhatsApp** com esses contactos (abre o WhatsApp com a mensagem já pronta — só tens de carregar em enviar).

---

## 3. Em que telemóveis funciona

Funciona em **qualquer telemóvel moderno com navegador**, mas o melhor resultado (app instalada com ícone próprio) é:

| Telemóvel | Navegador | Instalar como app | Notificações push |
| --- | --- | --- | --- |
| **iPhone** (iOS 16.4 ou superior) | Só Safari | Sim | Sim (com condições, ver abaixo) |
| **Android** (8 ou superior) | Chrome, Edge, Samsung Internet | Sim | Sim |
| PC Windows / Mac / Linux | Chrome, Edge, Firefox, Safari | Sim (ícone na barra) | Chrome/Edge: sim |

> iPhone: instalar e receber notificações **só no Safari** — o Chrome do iPhone não permite.

---

## 4. Instalar no IPHONE (Safari)

1. Abre o endereço da app (tem de ser **https**) no **Safari**.
2. No ecrã de boas-vindas, toca em **«Ativar localização»** e aceita a permissão (se recusares, podes pesquisar a cidade).
3. Toca no ícone **Partilhar** (quadrado com seta, em baixo ao meio).
4. Escolhe **«Adicionar ao Ecrã Principal»** → **Adicionar**.
5. Abre a app pelo novo ícone (aberta assim, já é fullscreen e pode ter notificações).

**Notificações no iPhone** (iOS 16.4+): a app tem de estar instalada no ecrã principal, abres a app pelo ícone e em **Definições → Notificações → Ativar** autorizas a permissão do sistema.

## 5. Instalar no ANDROID (Chrome)

1. Abre o endereço da app (https) no **Chrome**.
2. Toca em **«Ativar localização»** e aceita (ou pesquisa a cidade).
3. Menu **⋮** (canto superior direito) → **«Instalar aplicação»** (ou «Adicionar ao ecrã principal»).
4. Confirma → o ícone fica no ecrã principal, como qualquer app.
5. Notificações: Definições → Notificações → Ativar → aceita a permissão do Android.

> Em ambos os telemóveis: sem localização autorizada, usa sempre **«Pesquisar cidade»** — a app funciona na mesma, com todas as funcionalidades.

---

## 6. Perguntas rápidas

- **É paga?** Não. A app e as fontes de dados usam serviços gratuitos.
- **Preciso de conta?** Não. As preferências ficam guardadas no teu aparelho.
- **As notificações aparecem «Não configurado»?** O servidor de avisos push ainda não tem credenciais (VAPID). Tudo o resto funciona na mesma — quem publica a app configura isto uma única vez (ver DEPLOY.md).
- **Funciona sem internet?** Mostra os últimos dados guardados e os comentários recentes; volta a atualizar quando a ligação regressa.
- **Os meus contactos de emergência ficam guardados onde?** No teu aparelho — não são enviados para lado nenhum até tu carregares no botão de partilha do WhatsApp.
