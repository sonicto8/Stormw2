/**
 * Codemod (ronda 7): reintroduz cantos arredondados onde fazem sentido.
 * Política de geometria:
 *  - Primitivas shadcn/ui → raio por tipo de elemento
 *    (botões/inputs/menus md, cartão xl, diálogos 2xl, chips/pills full).
 *  - Componentes da app (feature) → predefinido xl (18px).
 *  - Superfícies de identidade (hero, boas-vindas) → pares específicos primeiro.
 *  - navigation.tsx e app-shell.tsx ficam fora do codemod (edição manual fina).
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const ROOT = '/home/z/my-project';

const perFile = {
  // ——— primitivas shadcn/ui ———
  'src/components/ui/button.tsx': 'rounded-md',
  'src/components/ui/input.tsx': 'rounded-md',
  'src/components/ui/textarea.tsx': 'rounded-md',
  'src/components/ui/checkbox.tsx': 'rounded-sm',
  'src/components/ui/radio-group.tsx': 'rounded-full',
  'src/components/ui/switch.tsx': 'rounded-full',
  'src/components/ui/slider.tsx': 'rounded-full',
  'src/components/ui/progress.tsx': 'rounded-full',
  'src/components/ui/avatar.tsx': 'rounded-full',
  'src/components/ui/badge.tsx': 'rounded-full',
  'src/components/ui/skeleton.tsx': 'rounded-md',
  'src/components/ui/card.tsx': 'rounded-xl',
  'src/components/ui/dialog.tsx': 'rounded-2xl',
  'src/components/ui/alert-dialog.tsx': 'rounded-2xl',
  'src/components/ui/sheet.tsx': 'rounded-2xl',
  'src/components/ui/drawer.tsx': 'rounded-2xl',
  'src/components/ui/command.tsx': 'rounded-lg',
  'src/components/ui/dropdown-menu.tsx': 'rounded-md',
  'src/components/ui/context-menu.tsx': 'rounded-md',
  'src/components/ui/menubar.tsx': 'rounded-md',
  'src/components/ui/navigation-menu.tsx': 'rounded-md',
  'src/components/ui/popover.tsx': 'rounded-lg',
  'src/components/ui/select.tsx': 'rounded-md',
  'src/components/ui/hover-card.tsx': 'rounded-lg',
  'src/components/ui/tooltip.tsx': 'rounded-md',
  'src/components/ui/tabs.tsx': 'rounded-md',
  'src/components/ui/accordion.tsx': 'rounded-md',
  'src/components/ui/toast.tsx': 'rounded-lg',
  'src/components/ui/calendar.tsx': 'rounded-md',
  'src/components/ui/alert.tsx': 'rounded-lg',
  'src/components/ui/toggle.tsx': 'rounded-md',
  'src/components/ui/toggle-group.tsx': 'rounded-md',
  'src/components/ui/input-otp.tsx': 'rounded-md',
  'src/components/ui/carousel.tsx': 'rounded-md',
  'src/components/ui/scroll-area.tsx': 'rounded-md',
  'src/components/ui/chart.tsx': 'rounded-lg',
  'src/components/ui/resizable.tsx': 'rounded-md',
  'src/components/ui/sidebar.tsx': 'rounded-lg',
  'src/components/ui/table.tsx': 'rounded-lg',
  'src/components/ui/pagination.tsx': 'rounded-md',
  // ——— partilhados ———
  'src/components/shared/ui.tsx': 'rounded-full',
  // ——— identidade (pares específicos primeiro, fallback menor) ———
  'src/components/dashboard/hero.tsx': {
    pairs: [['glass rounded-none', 'glass rounded-2xl']],
    fallback: 'rounded-lg',
  },
  'src/components/layout/welcome-screen.tsx': {
    pairs: [['glass-strong rounded-none', 'glass-strong rounded-3xl']],
    fallback: 'rounded-lg',
  },
};

// Editados à mão depois (geometria fina da navegação).
const EXCLUDED = new Set([
  'src/components/layout/navigation.tsx',
  'src/components/layout/app-shell.tsx',
]);

const files = execSync(`rg -l 'rounded-none' src --glob '*.tsx'`, {
  cwd: ROOT,
  encoding: 'utf8',
})
  .trim()
  .split('\n')
  .filter(Boolean);

let changed = 0;
for (const rel of files) {
  if (EXCLUDED.has(rel)) continue;
  const path = `${ROOT}/${rel}`;
  let src = readFileSync(path, 'utf8');
  const rule = perFile[rel];
  let fallback = 'rounded-xl';

  if (typeof rule === 'string') {
    fallback = rule;
  } else if (rule) {
    fallback = rule.fallback;
    for (const [find, replace] of rule.pairs) src = src.split(find).join(replace);
  }
  if (rel.startsWith('src/components/ui/') && typeof rule !== 'string') {
    fallback = 'rounded-md';
  }

  const count = (src.match(/rounded-none/g) ?? []).length;
  if (!count) continue;

  src = src.split('rounded-none').join(fallback);
  // Limpar espaços duplos/triplos deixados por codemods anteriores (só após classes).
  src = src.replace(/rounded-(sm|md|lg|xl|2xl|3xl|full)[ \t]{2,}/g, 'rounded-$1 ');

  writeFileSync(path, src);
  changed++;
  console.log(`${rel}: ${count}× ${fallback}`);
}
console.log('Ficheiros alterados:', changed);
