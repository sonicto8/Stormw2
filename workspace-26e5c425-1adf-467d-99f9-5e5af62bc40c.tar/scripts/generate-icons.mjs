/** Gera os ícones PWA da STORMWATCH a partir do SVG mestre. */
import sharp from 'sharp';
import { readFile } from 'node:fs/promises';

const SRC = '/home/z/my-project/public/icons/icon.svg';
const OUT = '/home/z/my-project/public/icons';

const targets = [
  { file: 'icon-192.png', size: 192 },
  { file: 'icon-512.png', size: 512 },
  { file: 'icon-180.png', size: 180 },
  { file: 'icon-maskable-192.png', size: 192, padding: 0.14 },
  { file: 'icon-maskable-512.png', size: 512, padding: 0.14 },
];

async function main() {
  const svg = await readFile(SRC, 'utf8');
  for (const t of targets) {
    if (t.padding) {
      // Máscaras "maskable": ícone reduzido com fundo cheio para zonas seguras.
      const inner = Math.round(t.size * (1 - t.padding * 2));
      const buffer = await sharp(Buffer.from(svg)).resize(inner, inner).png().toBuffer();
      const background = Buffer.from(
        `<svg width="${t.size}" height="${t.size}"><defs><linearGradient id="bgm" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#3498DB"/><stop offset="100%" stop-color="#1E3A5F"/></linearGradient></defs><rect width="${t.size}" height="${t.size}" fill="url(#bgm)"/></svg>`,
      );
      await sharp(background)
        .composite([{ input: buffer, left: Math.round(t.size * t.padding), top: Math.round(t.size * t.padding) }])
        .png()
        .toFile(`${OUT}/${t.file}`);
    } else {
      await sharp(Buffer.from(svg)).resize(t.size, t.size).png().toFile(`${OUT}/${t.file}`);
    }
    console.log(`OK ${t.file}`);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
