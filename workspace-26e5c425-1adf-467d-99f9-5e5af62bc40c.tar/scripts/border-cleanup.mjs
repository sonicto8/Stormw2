/** Limpeza final: campos border vazios, border-transparent residuais, espaços duplos em classes. */
import { readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const files = execSync(
  `rg -l "border: ''|border-transparent" src/components --glob '!src/components/ui/**' --glob '!src/components/layout/navigation.tsx' --glob '*.tsx'`,
  { cwd: '/home/z/my-project', encoding: 'utf8' },
)
  .trim()
  .split('\n')
  .filter(Boolean);

for (const rel of files) {
  const path = `/home/z/my-project/${rel}`;
  let src = readFileSync(path, 'utf8');
  const before = src;

  // border-transparent residual em ternários (separadores de botões segmentados).
  src = src.replace(/ border-transparent/g, '');

  // Campos de objeto `border: ''` → barra lateral de severidade quando faz sentido.
  // (script genérico: apenas remove campos vazios e a sua interpolação)
  src = src.replace(/\s*border: '',/g, '');
  src = src.replace(/\{\s*\}/g, '{}');
  src = src.replace(/\(\{\s*\}\s*,/g, '({},');
  src = src.replace(/\(\{\},/g, '({},');
  // Interpolações de tone.border / alertTone(...).border sobram vazias → remover token vazio.
  src = src.replace(/\$\{tone\.border\}\s*/g, '');
  src = src.replace(/\s*\}\s*\$\{tone\.bg\}/g, ' } ${tone.bg}');

  if (src !== before) {
    writeFileSync(path, src);
    console.log('limpo:', rel);
  }
}

// Espaços duplos dentro de strings de className (resíduos do sweep).
const files2 = execSync(`rg -l 'className' src/components --glob '!src/components/ui/**' --glob '*.tsx'`, {
  cwd: '/home/z/my-project',
  encoding: 'utf8',
})
  .trim()
  .split('\n')
  .filter(Boolean);

for (const rel of files2) {
  const path = `/home/z/my-project/${rel}`;
  const src = readFileSync(path, 'utf8');
  // Colapsa 2+ espaços APENAS dentro de literais '...' após "className" ou dentro de template de classe.
  const next = src.replace(/(className=\{?`[^`]*?|'[^'\n]*?) {2,}([^`\n]*?`)/g, '$1 $2');
  const next2 = next.replace(/'([^'\n]*?) {2,}([^'\n]*?)'/g, "'$1 $2'");
  if (next2 !== src) {
    writeFileSync(path, next2);
    console.log('espaços colapsados:', rel);
  }
}
console.log('done');
