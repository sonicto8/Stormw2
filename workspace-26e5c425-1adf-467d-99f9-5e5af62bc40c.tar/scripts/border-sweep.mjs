/**
 * Codemod: remove contornos decorativos dos componentes de conteúdo.
 * O contorno completo fica reservado à navegação (menu/abas).
 * Severidade mantém uma barra lateral esquerda (border-l) + fundo tintado.
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const files = execSync(
  `rg -l 'border' src/components --glob '!src/components/ui/**' --glob '!src/components/layout/navigation.tsx' --glob '*.tsx'`,
  { cwd: '/home/z/my-project', encoding: 'utf8' },
)
  .trim()
  .split('\n')
  .filter(Boolean);

// 1) Pares «border border-X» com substituição específica (severidade → barra lateral).
const pairs = [
  [' border border-amber/40', ' border-l-[3px] border-l-amber'],
  [' border border-amber/30', ' border-l-[3px] border-l-amber'],
  [' border border-critical/45', ' border-l-[3px] border-l-critical'],
  [' border border-critical/40', ' border-l-[3px] border-l-critical'],
  [' border border-critical/30', ' border-l-[3px] border-l-critical'],
];

let totalTokens = 0;
const changedFiles = [];
for (const rel of files) {
  const path = `/home/z/my-project/${rel}`;
  const before = readFileSync(path, 'utf8');
  let after = before;

  for (const [find, replace] of pairs) after = after.split(find).join(replace);

  // 2) Tokens decorativos condicionais (estado ativo/hover/disabled).
  const tokenRe = /([\s'`])(?:(?:disabled|hover|focus|focus-visible):)+border-(?:blue|cyan|critical|signal|amber|violet)\/\d+/g;
  const plainRe = /([\s'`])border-(?:blue|cyan|critical|signal|amber|violet)\/\d+/g;
  after = after.replace(tokenRe, '$1').replace(plainRe, '$1');

  // 3) «border» isolados que ficaram órfãos (contorno completo decorativo).
  const orphanRe = /([\s'"`])border(?=[\s'"`])/g;
  after = after.replace(orphanRe, '$1');

  const removed = (before.match(/border/g) ?? []).length - (after.match(/border/g) ?? []).length;
  if (after !== before) {
    writeFileSync(path, after);
    totalTokens += removed;
    changedFiles.push(`${rel} (-${removed} tokens border)`);
  }
}
console.log('Ficheiros alterados:', changedFiles.length, '| tokens border removidos:', totalTokens);
for (const f of changedFiles) console.log(' -', f);
