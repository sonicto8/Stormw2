'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { useAppStore } from '@/store/app-store';
import { useOnline } from '@/hooks/use-online';
import { useProfileContext } from '@/hooks/profile-context';
import { useAirQuality, useIpmaWarnings, useWeather } from '@/hooks/use-weather';
import { useClimateNotifications } from '@/hooks/use-climate-notifications';
import { useAlertsStream } from '@/hooks/use-alerts-stream';
import { AtmosphereBackground, type AtmosphereState } from '@/components/atmosphere/atmosphere-background';
import { BottomNav, DesktopNav, OfflineBanner, TopBar } from '@/components/layout/navigation';
import { WelcomeScreen } from '@/components/layout/welcome-screen';
import { ErrorState } from '@/components/shared/states';
import { computeAlerts } from '@/lib/engines/alerts';
import { weatherGroup } from '@/lib/weather-codes';
import { parseLocalIso } from '@/lib/format';
import { InicioTab } from '@/components/dashboard/inicio-tab';
import { AssistenteTab } from '@/components/assistant/assistente-tab';
import { RadarTab } from '@/components/radar/radar-tab';
import { ComunidadeTab } from '@/components/community/comunidade-tab';
import { PlaneadorTab } from '@/components/planeador/planeador-tab';
import { PerfilTab } from '@/components/profile/perfil-tab';
import { AlertasTab } from '@/components/alerts/alertas-tab';

function Splash() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-5" aria-busy="true" aria-live="polite">
      <div className="relative">
        <div className="size-16 rounded-2xl brand-gradient" style={{ boxShadow: '0 0 60px rgba(52,152,219,0.30), inset 0 0 30px rgba(52,152,219,0.14)' }} />
        <div className="absolute inset-0 rounded-2xl border-t-2 border-cyan animate-spin-slow" />
      </div>
      <div className="text-center">
        <p className="font-display text-xl font-bold tracking-[0.22em] text-glow-cyan">STORMWATCH</p>
        <p className="mt-1 text-[10px] uppercase tracking-[0.32em] text-atmos">Meteorologia em tempo real</p>
      </div>
    </div>
  );
}

export function AppShell() {
  const { location, activeTab } = useAppStore();
  const online = useOnline();
  const { profile } = useProfileContext();

  const [nowMs, setNowMs] = useState(() => Date.now());

  // true apenas após a hidratação (evita mismatch de dados persistidos).
  const mounted = useSyncExternalStore(
    () => () => undefined,
    () => true,
    () => false,
  );

  useEffect(() => {
    const t = setInterval(() => setNowMs(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);

  const weather = useWeather(location.latitude, location.longitude);
  const air = useAirQuality(location.latitude, location.longitude);
  const ipma = useIpmaWarnings();
  // Stream em tempo real do alerts-service (porta 3003): toasts + feed.
  const stream = useAlertsStream();

  const bundle = weather.data?.bundle ?? null;
  const airBundle = air.data?.bundle ?? null;
  const ipmaWarnings = ipma.data?.warnings ?? [];

  const alerts = useMemo(
    () => computeAlerts(bundle, airBundle, ipmaWarnings, location.name, nowMs, profile),
    [bundle, airBundle, ipmaWarnings, location.name, nowMs, profile],
  );

  // Notificações automáticas sobre alterações climáticas (toast + navegador).
  useClimateNotifications(bundle, alerts, nowMs);

  const atmosphereState: AtmosphereState | null = bundle
    ? (() => {
        const today = bundle.daily[0] ?? null;
        const rise = today?.sunrise ? parseLocalIso(today.sunrise).getTime() : null;
        const set = today?.sunset ? parseLocalIso(today.sunset).getTime() : null;
        let dayProgress = 0.5;
        if (rise !== null && set !== null && set > rise) {
          dayProgress = Math.min(1, Math.max(0, (nowMs - rise) / (set - rise)));
        }
        const group = weatherGroup(bundle.current.weatherCode);
        const alertLevel = alerts.some((a) => a.severity === 'critical')
          ? 'critical'
          : alerts.some((a) => a.severity === 'warning')
            ? 'warning'
            : alerts.length > 0
              ? 'info'
              : null;
        return {
          meteocon: bundle.current.meteocon,
          weatherGroup: group,
          isDay: bundle.current.isDay,
          precipitation: bundle.current.precipitation,
          thunder: group === 'thunder' || bundle.minutely15.some((m) => (m.weatherCode ?? 0) >= 95),
          alertLevel,
          dayProgress,
        } satisfies AtmosphereState;
      })()
    : null;

  const refreshing = weather.isFetching || air.isFetching || ipma.isFetching;
  const onRefresh = () => {
    void weather.refetch();
    void air.refetch();
    void ipma.refetch();
  };

  if (!mounted) return <Splash />;

  return (
    <div className="relative min-h-dvh flex flex-col">
      <WelcomeScreen />
      <AtmosphereBackground state={atmosphereState} />

      <div className="relative z-10 mx-auto w-full max-w-[1440px] lg:flex lg:items-start lg:gap-6 lg:px-6 lg:pt-0">
        <DesktopNav />

        <div className="flex min-w-0 flex-1 flex-col min-h-dvh">
          <TopBar
            fetchedAt={bundle?.fetchedAt ?? null}
            online={online}
            refreshing={refreshing}
            onRefresh={onRefresh}
          />
          <OfflineBanner fetchedAt={bundle?.fetchedAt ?? null} />

          {weather.data?.notice && (
            <div className="mx-3 lg:mx-0 mt-2 rounded-md border-l-[3px] border-l-amber bg-amber/8 px-4 py-2 text-[11px] text-amber">
              {weather.data.notice}
            </div>
          )}

          <AnimatePresence mode="wait" initial={false}>
            <motion.main
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
              className="mt-3 flex-1 px-3 lg:px-0 pb-32 lg:pb-12"
            >
              {activeTab === 'inicio' && (
                <InicioTab
                  bundle={bundle}
                  air={airBundle}
                  alerts={alerts}
                  nowMs={nowMs}
                  loading={weather.isLoading}
                  error={weather.isError ? weather.error.message : null}
                  onRetry={() => void weather.refetch()}
                />
              )}
              {activeTab === 'alertas' && (
                <AlertasTab
                  alerts={alerts}
                  ipmaWarnings={ipmaWarnings}
                  streamStatus={stream.status}
                  streamFeed={stream.feed}
                  locationName={location.name}
                  nowMs={nowMs}
                />
              )}
              {activeTab === 'assistente' && (
                <AssistenteTab bundle={bundle} air={airBundle} nowMs={nowMs} />
              )}
              {activeTab === 'radar' && <RadarTab />}
              {activeTab === 'comunidade' && (
                <ComunidadeTab bundle={bundle} air={airBundle} alerts={alerts} nowMs={nowMs} />
              )}
              {activeTab === 'planeador' && (
                <PlaneadorTab bundle={bundle} loading={weather.isLoading} error={weather.isError ? weather.error.message : null} />
              )}
              {activeTab === 'perfil' && <PerfilTab />}
            </motion.main>
          </AnimatePresence>

          <footer className="mt-auto hidden lg:block px-1 pb-6 pt-2">
            <p className="text-[11px] text-atmos">
              STORMWATCH · Dados em tempo real de Open-Meteo, IPMA e RainViewer · Cache de 10 minutos ·{' '}
              <span className={online ? 'text-signal' : 'text-amber'}>{online ? 'Ligado' : 'Offline'}</span>
            </p>
          </footer>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
