'use client';

import { Command, MapPin, Navigation, Star } from 'lucide-react';
import { useEffect, useState } from 'react';
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { toast } from 'sonner';
import { useAppStore, type SelectedLocation } from '@/store/app-store';
import { useGeocodingSearch } from '@/hooks/use-weather';
import { useGeolocation } from '@/hooks/use-geolocation';
import { useProfileContext } from '@/hooks/profile-context';
import { QUICK_LOCATIONS } from '@/lib/locations';

export function LocationDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const { setLocation } = useAppStore();
  const { profile } = useProfileContext();
  const [query, setQuery] = useState('');
  const [debounced, setDebounced] = useState('');
  const { data: results, isFetching, isError } = useGeocodingSearch(debounced);
  const { request } = useGeolocation();

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 350);
    return () => clearTimeout(t);
  }, [query]);

  const select = (loc: SelectedLocation) => {
    setLocation(loc);
    onOpenChange(false);
    setQuery('');
    toast.success(`Localização definida: ${loc.name}`);
  };

  const useGps = () => {
    request(
      (coords) => {
        select({ name: 'A minha localização', admin: 'GPS do dispositivo', ...coords, fromGeolocation: true });
      },
      (message) => {
        toast.error(message);
      },
    );
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange} className="glass-strong rounded-xl">
      <CommandInput placeholder="Pesquisar cidade ou localidade portuguesa…" value={query} onValueChange={setQuery} />
      <CommandList className="scroll-thin">
        <CommandEmpty>
          {isFetching ? 'A pesquisar…' : isError ? 'Pesquisa indisponível de momento.' : 'Nenhuma localidade encontrada.'}
        </CommandEmpty>
        <CommandGroup heading="Localização">
          <CommandItem onSelect={useGps} className="gap-2">
            <Navigation className="size-4 text-cyan" />
            Ativar localização — GPS do dispositivo
          </CommandItem>
        </CommandGroup>
        {profile.favoriteLocations.length > 0 && (
          <CommandGroup heading="Favoritas — troca rápida">
            {profile.favoriteLocations.map((f) => (
              <CommandItem
                key={`fav-${f.id}`}
                value={`fav-${f.id}-${f.name}`}
                onSelect={() =>
                  select({ name: f.name, admin: null, latitude: f.latitude, longitude: f.longitude, fromGeolocation: false })
                }
              >
                <Star className="size-4 text-amber" />
                <span className="font-medium">{f.name}</span>
              </CommandItem>
            ))}
          </CommandGroup>
        )}
        <CommandGroup heading="Localidades">
          {(results ?? []).map((r) => (
            <CommandItem
              key={r.id}
              value={`${r.name}-${r.id}`}
              onSelect={() =>
                select({
                  name: r.name,
                  admin: r.admin1,
                  latitude: r.latitude,
                  longitude: r.longitude,
                  fromGeolocation: false,
                })
              }
            >
              <MapPin className="size-4 text-atmos" />
              <span className="font-medium">{r.name}</span>
              {r.admin1 && <span className="text-xs text-atmos">— {r.admin1}</span>}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="Rápido">
          {QUICK_LOCATIONS.slice(0, 12).map((q) => (
            <CommandItem
              key={q.id}
              value={`quick-${q.id}`}
              onSelect={() =>
                select({ name: q.name, admin: q.admin, latitude: q.latitude, longitude: q.longitude, fromGeolocation: false })
              }
            >
              <Command className="size-4 text-atmos" />
              {q.name}
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
