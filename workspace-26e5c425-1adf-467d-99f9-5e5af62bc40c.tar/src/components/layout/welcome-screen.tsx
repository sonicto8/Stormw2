'use client';

/**
 * Ecrã de boas-vindas da primeira visita (guia PWA): propõe «Ativar
 * localização» (GPS do dispositivo); se o utilizador recusar ou preferir
 * escolher, segue para «Pesquisar cidade». Aparece uma única vez — o estado
 * vive em localStorage — e nunca bloqueia: é sempre possível continuar com a
 * localização predefinida (Lisboa).
 */
import { MapPin, Navigation, Search, Zap } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { useAppStore } from '@/store/app-store';
import { useGeolocation } from '@/hooks/use-geolocation';

const WELCOME_KEY = 'stormwatch:welcome-seen';

function hasSeenWelcome(): boolean {
  try {
    return window.localStorage.getItem(WELCOME_KEY) === '1';
  } catch {
    return false;
  }
}

function markWelcomeSeen(): void {
  try {
    window.localStorage.setItem(WELCOME_KEY, '1');
  } catch {
    // Sem localStorage (modo privado) — a app funciona na mesma.
  }
}

export function WelcomeScreen() {
  // O AppShell só monta filhos no cliente (gate `mounted`), pelo que é seguro
  // ler localStorage no inicializador — sem efeitos nem hydration mismatch.
  const [visible, setVisible] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return !hasSeenWelcome();
  });
  const [busy, setBusy] = useState(false);
  const { setLocation, setLocationDialogOpen } = useAppStore();
  const { request } = useGeolocation();

  const close = () => {
    markWelcomeSeen();
    setVisible(false);
  };

  const activate = () => {
    setBusy(true);
    request(
      (coords) => {
        setLocation({ name: 'A minha localização', admin: 'GPS do dispositivo', ...coords, fromGeolocation: true });
        setBusy(false);
        close();
        toast.success('Localização ativada — dados ajustados à tua posição.');
      },
      (message) => {
        setBusy(false);
        toast.error(`${message} Usa «Pesquisar cidade» em alternativa.`);
      },
    );
  };

  const searchCity = () => {
    close();
    setLocationDialogOpen(true);
  };

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-center justify-center brand-gradient px-4"
      role="dialog"
      aria-modal="true"
      aria-label="Boas-vindas ao STORMWATCH"
    >
      <div className="glass-strong rounded-3xl w-full max-w-md p-6 sm:p-8 flex flex-col items-center text-center gap-5">
        <span className="flex size-14 items-center justify-center rounded-2xl bg-cyan/10">
          <Zap className="size-7 text-cyan" aria-hidden="true" />
        </span>
        <div className="flex flex-col gap-2">
          <h1 className="font-display text-2xl font-bold tracking-[0.18em] text-foreground">STORMWATCH</h1>
          <p className="text-sm text-atmos leading-relaxed">
            Meteorologia em tempo real para Portugal — previsão, avisos oficiais do IPMA, radar de precipitação e
            alertas inteligentes, tudo em português.
          </p>
        </div>
        <div className="w-full flex flex-col gap-2.5">
          <button
            type="button"
            onClick={activate}
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-lg border-cyan bg-cyan px-4 py-3 text-sm font-semibold text-white transition hover:bg-cyan/90 disabled:opacity-60 min-h-[44px]"
          >
            <Navigation className="size-4" aria-hidden="true" />
            {busy ? 'A obter localização…' : 'Ativar localização'}
          </button>
          <button
            type="button"
            onClick={searchCity}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue/5 px-4 py-3 text-sm font-semibold text-foreground transition  hover:text-cyan min-h-[44px]"
          >
            <Search className="size-4" aria-hidden="true" />
            Pesquisar cidade
          </button>
          <button
            type="button"
            onClick={close}
            className="flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-xs font-medium text-atmos transition hover:text-cyan min-h-[44px]"
          >
            <MapPin className="size-3.5" aria-hidden="true" />
            Continuar com Lisboa (predefinida)
          </button>
        </div>
        <p className="text-[11px] leading-relaxed text-atmos">
          A localização só é usada para ajustar a previsão — nunca é partilhada sem confirmação. Sem GPS, procura
          qualquer localidade portuguesa.
        </p>
      </div>
    </div>
  );
}
