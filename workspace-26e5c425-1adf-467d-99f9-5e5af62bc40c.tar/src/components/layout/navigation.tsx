'use client';

import { CloudRain, Home, MessageSquareText, User, CalendarDays, MessagesSquare, RefreshCw, WifiOff, MapPin, ShieldAlert, Moon, Sun } from 'lucide-react';
import { useTheme } from 'next-themes';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import { useAppStore, type TabKey } from '@/store/app-store';
import { useOnline } from '@/hooks/use-online';
import { LocationDialog } from '@/components/layout/location-dialog';
import { formatClockTime, formatRelative } from '@/lib/format';

const TABS: Array<{ key: TabKey; label: string; icon: typeof Home }> = [
  { key: 'inicio', label: 'Início', icon: Home },
  { key: 'alertas', label: 'Alertas', icon: ShieldAlert },
  { key: 'assistente', label: 'Assistente', icon: MessageSquareText },
  { key: 'radar', label: 'Radar', icon: CloudRain },
  { key: 'comunidade', label: 'Comunidade', icon: MessagesSquare },
  { key: 'planeador', label: 'Planeador', icon: CalendarDays },
  { key: 'perfil', label: 'Definições', icon: User },
];

export function BottomNav() {
  const { activeTab, setActiveTab } = useAppStore();
  return (
    <nav
      aria-label="Navegação principal"
      className="fixed inset-x-0 bottom-0 z-40 lg:hidden pb-safe"
    >
      <div className="mx-3 mb-3 glass-strong nav-outline rounded-3xl px-2 py-2">
        <ul className="grid grid-cols-7 gap-1">
          {TABS.map((tab) => {
            const active = activeTab === tab.key;
            const Icon = tab.icon;
            return (
              <li key={tab.key}>
                <button
                  onClick={() => setActiveTab(tab.key)}
                  aria-current={active ? 'page' : undefined}
                  className="relative flex w-full flex-col items-center gap-1 rounded-xl px-0.5 py-2 min-h-[44px] transition-colors"
                >
                  {active && (
                    <motion.span
                      layoutId="nav-pill"
                      className="absolute inset-0 rounded-full bg-cyan/15 border border-cyan/30"
                      transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                    />
                  )}
                  <Icon className={`relative z-10 size-5 ${active ? 'text-cyan' : 'text-atmos'}`} />
                  <span className={`relative z-10 text-[9px] font-medium ${active ? 'text-cyan' : 'text-atmos'}`}>
                    {tab.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}

export function DesktopNav() {
  const { activeTab, setActiveTab } = useAppStore();
  return (
    <aside className="hidden lg:flex sticky top-6 h-[calc(100dvh-3rem)] w-[220px] shrink-0 flex-col glass-strong nav-outline rounded-2xl p-4 gap-2 z-30">
      <div className="px-2 pt-2 pb-4">
        <p className="font-display text-lg font-bold tracking-[0.18em] text-glow-cyan">STORMWATCH</p>
        <p className="text-[10px] uppercase tracking-[0.3em] text-atmos mt-1">Meteorologia em tempo real</p>
      </div>
      <ul className="flex flex-col gap-1.5">
        {TABS.map((tab) => {
          const active = activeTab === tab.key;
          const Icon = tab.icon;
          return (
            <li key={tab.key}>
              <button
                onClick={() => setActiveTab(tab.key)}
                aria-current={active ? 'page' : undefined}
                className={`relative flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all min-h-[44px] ${
                  active ? 'bg-cyan/15 border border-cyan/30 text-cyan' : 'text-atmos hover:bg-blue/5 border'
 }`}
              >
                <Icon className="size-5" />
                {tab.label}
              </button>
            </li>
          );
        })}
      </ul>
      <div className="mt-auto px-3 pb-1">
        <p className="text-[10px] text-atmos leading-relaxed">
          Dados: Open-Meteo, IPMA, RainViewer
        </p>
      </div>
    </aside>
  );
}

export function TopBar({ fetchedAt, online, refreshing, onRefresh }: { fetchedAt: number | null; online: boolean; refreshing: boolean; onRefresh: () => void }) {
  const { location, locationDialogOpen, setLocationDialogOpen } = useAppStore();
  const { resolvedTheme, setTheme } = useTheme();
  const [, forceTick] = useState(0);

  // Atualizar "há X min" a cada 30s.
  useEffect(() => {
    const t = setInterval(() => forceTick((v) => v + 1), 30000);
    return () => clearInterval(t);
  }, []);

  const isDark = resolvedTheme === 'dark';

  return (
    <header className="sticky top-0 z-30 pt-safe">
      <div className="mx-3 lg:mx-0 mt-3 glass-strong rounded-2xl px-3 sm:px-4 py-3 flex items-center gap-2.5">
        <div className="lg:hidden shrink-0">
          <p className="font-display text-sm font-bold tracking-[0.18em] text-glow-cyan leading-none">STORMWATCH</p>
          <p className="hidden sm:block text-[8px] uppercase tracking-[0.2em] text-atmos mt-1 leading-none whitespace-nowrap">Meteorologia em tempo real</p>
        </div>
        <button
          onClick={() => setLocationDialogOpen(true)}
          className="ml-auto lg:ml-0 flex items-center gap-2 rounded-lg bg-blue/6 px-3 py-1.5 text-sm transition hover:bg-blue/10 hover:text-cyan min-h-[36px] min-w-0"
          aria-label={`Localização atual: ${location.name}. Alterar`}
        >
          <MapPin className="size-4 shrink-0 text-cyan" />
          <span className="font-medium max-w-[120px] sm:max-w-[180px] truncate">{location.name}</span>
          {!location.fromGeolocation && location.admin && <span className="hidden sm:inline text-xs text-atmos">{location.admin}</span>}
        </button>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            className="flex size-9 items-center justify-center rounded-lg bg-blue/6 transition hover:bg-blue/10 hover:text-cyan"
            aria-label={isDark ? 'Mudar para modo claro' : 'Mudar para modo escuro'}
            title={isDark ? 'Modo claro' : 'Modo escuro'}
          >
            {isDark ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </button>
          {!online && (
            <span className="flex items-center gap-1.5 rounded-md border-l-2 border-l-amber bg-amber/10 px-2.5 py-1 text-[11px] text-amber">
              <WifiOff className="size-3.5" /> Offline
            </span>
          )}
          {fetchedAt !== null && online && (
            <span className="hidden sm:flex items-center gap-1.5 text-[11px] text-atmos" title="Hora da última atualização dos dados">
              <RefreshCw className={`size-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'A atualizar…' : `Atualizado ${formatClockTime(fetchedAt)}`}
            </span>
          )}
          <button
            onClick={onRefresh}
            className="flex size-9 items-center justify-center rounded-lg bg-blue/6 transition hover:bg-blue/10 hover:text-cyan"
            aria-label="Atualizar dados"
          >
            <RefreshCw className={`size-4 ${refreshing ? 'animate-spin text-cyan' : ''}`} />
          </button>
        </div>
      </div>
      <LocationDialog open={locationDialogOpen} onOpenChange={setLocationDialogOpen} />
    </header>
  );
}

export function OfflineBanner({ fetchedAt }: { fetchedAt: number | null }) {
  const online = useOnline();
  if (online) return null;
  return (
    <div className="mx-3 lg:mx-0 mt-2 rounded-md border-l-[3px] border-l-amber bg-amber/10 px-4 py-2.5 text-xs text-amber flex items-center gap-2">
      <WifiOff className="size-4 shrink-0" />
      <span>
        Sem ligação — a apresentar dados em cache.
        {fetchedAt && ` Última atualização: ${formatRelative(fetchedAt, Date.now())}.`}
      </span>
    </div>
  );
}
