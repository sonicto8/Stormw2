'use client';

import { useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import {
  CloudSun,
  Eye,
  Loader2,
  MapPin,
  MessagesSquare,
  RadioTower,
  Send,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { toast } from 'sonner';
import type { AirQualityBundle, ForecastBundle, WeatherAlert } from '@/lib/types';
import { useAppStore } from '@/store/app-store';
import { useCreateComment, useComments, useCommentSocket } from '@/hooks/use-comments';
import { EmergencyPanel } from '@/components/dashboard/emergency-panel';
import { TileSkeleton, EmptyState } from '@/components/shared/states';
import { formatRelative, formatTemp } from '@/lib/format';
import type { CommentResponse } from '@/lib/schemas/comment.schema';

const MAX_LENGTH = 280;
const NICKNAME_KEY = 'stormwatch-nickname';

const nicknameStore = {
  subscribe(cb: () => void) {
    window.addEventListener('storage', cb);
    return () => window.removeEventListener('storage', cb);
  },
  get(): string {
    try {
      return localStorage.getItem(NICKNAME_KEY) ?? '';
    } catch {
      return '';
    }
  },
  server(): string {
    return '';
  },
};

function Avatar({ nickname, mine }: { nickname: string; mine: boolean }) {
  const initial = (nickname.trim()[0] ?? '?').toUpperCase();
  return (
    <span
      className={`flex size-9 shrink-0 items-center justify-center rounded-xl font-display text-sm font-bold ${
        mine ? ' bg-cyan/15 text-cyan' : ' bg-blue/6 text-foreground/80'
 }`}
      aria-hidden="true"
    >
      {initial}
    </span>
  );
}

function CommentCard({ comment, nowMs }: { comment: CommentResponse; nowMs: number }) {
  const mine = comment.mine === true;

  return (
    <article
      className={`rounded-xl px-3.5 py-3 ${mine ? ' bg-cyan/6' : ' bg-blue/4'}`}
      aria-label={`Comentário de ${comment.nickname}`}
    >
      <div className="flex items-start gap-2.5">
        <Avatar nickname={comment.nickname} mine={mine} />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
            <span className={`text-xs font-semibold ${mine ? 'text-cyan' : ''}`}>
              {comment.nickname}
              {mine && <span className="ml-1 text-[10px] text-atmos font-normal">(tu)</span>}
            </span>
            <span className="text-[10px] text-atmos">{formatRelative(Date.parse(comment.createdAt), nowMs)}</span>
          </div>
          <p className="mt-1 text-sm leading-relaxed break-words text-foreground/90">{comment.message}</p>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-atmos">
            {comment.placeName && (
              <span className="flex items-center gap-1">
                <MapPin className="size-3" /> {comment.placeName}
              </span>
            )}
            {comment.temperature !== null && comment.weatherLabel && (
              <span className="flex items-center gap-1">
                <CloudSun className="size-3" /> {comment.weatherLabel}, {formatTemp(comment.temperature)}
              </span>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}

interface ComunidadeTabProps {
  bundle: ForecastBundle | null;
  air: AirQualityBundle | null;
  alerts: WeatherAlert[];
  nowMs: number;
}

/** Separador Comunidade: comentários em tempo real + SOS de emergência. */
export function ComunidadeTab({ bundle, alerts, nowMs }: ComunidadeTabProps) {
  const { location } = useAppStore();
  const comments = useComments();
  const socketStatus = useCommentSocket(true);
  const createComment = useCreateComment();

  const [nicknameDraft, setNicknameDraft] = useState<string | null>(null);
  const storedNickname = useSyncExternalStore(nicknameStore.subscribe, nicknameStore.get, nicknameStore.server);
  const nickname = nicknameDraft ?? storedNickname;
  const [message, setMessage] = useState('');

  const changeNickname = (value: string) => {
    setNicknameDraft(value);
    try {
      localStorage.setItem(NICKNAME_KEY, value);
    } catch {
      // ignore
    }
  };

  const cur = bundle?.current ?? null;

  const submit = () => {
    const trimmed = message.trim();
    if (trimmed.length === 0 || createComment.isPending) return;
    createComment.mutate(
      {
        nickname: nickname.trim() || null,
        message: trimmed.slice(0, MAX_LENGTH),
        lat: location.latitude,
        lon: location.longitude,
        placeName: location.name,
        weatherLabel: cur?.weatherLabel ?? null,
        temperature: cur?.temperature ?? null,
      },
      {
        onSuccess: () => {
          setMessage('');
          toast.success('Comentário publicado — já chegou a todos os que estão a ver esta página.');
        },
        onError: (err) => {
          toast.error(err instanceof Error ? err.message : 'Não foi possível publicar o comentário.');
        },
      },
    );
  };

  const sorted = useMemo(() => {
    const list = comments.data ?? [];
    return [...list].sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
  }, [comments.data]);

  const livePill =
    socketStatus === 'live' ? (
      <span className="flex items-center gap-1.5 rounded-xl bg-signal/10 px-3 py-1 text-[11px] font-medium text-signal">
        <RadioTower className="size-3.5 animate-pulse" /> Tempo real ligado
      </span>
    ) : socketStatus === 'connecting' ? (
      <span className="flex items-center gap-1.5 rounded-xl bg-blue/6 px-3 py-1 text-[11px] text-atmos">
        <Loader2 className="size-3.5 animate-spin" /> A ligar…
      </span>
    ) : (
      <span className="flex items-center gap-1.5 rounded-xl bg-amber/10 px-3 py-1 text-[11px] font-medium text-amber">
        <WifiOff className="size-3.5" /> Atualização periódica
      </span>
    );

  return (
    <div className="animate-fade-up">
      {/* Cabeçalho */}
      <section className="glass rounded-xl p-4 mb-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex size-10 items-center justify-center rounded-xl bg-violet/12">
              <MessagesSquare className="size-5 text-violet" />
            </span>
            <div>
              <h1 className="font-display text-lg font-bold tracking-tight">Comunidade</h1>
              <p className="text-xs text-atmos mt-0.5">
                Comentários de quem está a ver a situação em tempo real — todos podem participar.
              </p>
            </div>
          </div>
          {livePill}
        </div>
      </section>

      {/* SOS — emergência e WhatsApp */}
      <EmergencyPanel bundle={bundle} alerts={alerts} nowMs={nowMs} compact />

      {/* Compositor */}
      <section className="glass rounded-xl p-4 mb-4" aria-label="Publicar comentário">
        <label className="flex flex-col gap-1 mb-3">
          <span className="text-[11px] text-atmos">A tua alcunha (visível a todos)</span>
          <input
            value={nickname}
            onChange={(e) => changeNickname(e.target.value)}
            maxLength={24}
            placeholder="Anónimo"
            className="rounded-xl bg-blue/6 px-3 py-2 text-sm outline-none transition  min-h-[44px]"
            aria-label="Alcunha pública"
          />
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-[11px] text-atmos">
            Como está o tempo aí agora? <span className="text-cyan">· a publicar como {location.name}</span>
          </span>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value.slice(0, MAX_LENGTH))}
            rows={3}
            maxLength={MAX_LENGTH}
            placeholder="Ex.: Chuva forte no centro, água a acumular na avenida…"
            className="rounded-xl bg-blue/6 px-3 py-2.5 text-sm outline-none transition  resize-none min-h-[72px]"
            aria-label="Mensagem para a comunidade"
          />
        </label>
        <div className="mt-2.5 flex items-center justify-between gap-3">
          <span className={`text-[11px] ${message.length >= MAX_LENGTH ? 'text-amber' : 'text-atmos'}`}>
            {message.length}/{MAX_LENGTH}
          </span>
          <button
            onClick={submit}
            disabled={message.trim().length === 0 || createComment.isPending || !bundle}
            className="flex min-h-[44px] items-center gap-2 rounded-xl bg-cyan/15 px-5 text-sm font-medium text-cyan transition hover:bg-cyan/25 disabled:opacity-40 disabled:hover:bg-cyan/15"
            aria-label="Publicar comentário"
          >
            {createComment.isPending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
            Publicar
          </button>
        </div>
        <p className="mt-2 text-[10px] leading-relaxed text-atmos">
          Comentários públicos, guardados durante 24 horas. Limite: 1 a cada 30 segundos por dispositivo. Não partilhes
          dados pessoais. O contexto meteorológico anexado vem da previsão ativa da aplicação.
        </p>
      </section>

      {/* Lista em tempo real */}
      <section aria-label="Comentários da comunidade" className="glass rounded-xl p-4">
        <div className="flex items-center justify-between mb-3 px-1">
          <h2 className="flex items-center gap-2 font-display text-sm font-semibold">
            <Eye className="size-4 text-cyan" /> Situação em tempo real
          </h2>
          <span className="text-[11px] text-atmos">
            {sorted.length} comentário{sorted.length === 1 ? '' : 's'} · 24 h
          </span>
        </div>

        {comments.isLoading ? (
          <div className="flex flex-col gap-2">
            <TileSkeleton className="h-20 w-full" />
            <TileSkeleton className="h-20 w-full" />
            <TileSkeleton className="h-20 w-full" />
          </div>
        ) : comments.isError ? (
          <EmptyState
            icon={<Wifi className="size-6 text-atmos" />}
            title="Comentários indisponíveis"
            message={`${comments.error.message} Os comentários voltam automaticamente quando o servidor responder.`}
          />
        ) : sorted.length === 0 ? (
          <EmptyState
            icon={<MessagesSquare className="size-6 text-atmos" />}
            title="Ainda sem comentários"
            message="Sê o primeiro a descrever o tempo aí — todos os que usam a aplicação veem o teu comentário em tempo real."
          />
        ) : (
          <div className="flex flex-col gap-2 max-h-[520px] overflow-y-auto scroll-thin pr-1">
            {sorted.map((c) => (
              <CommentCard key={c.id} comment={c} nowMs={nowMs} />
            ))}
          </div>
        )}

        {socketStatus === 'polling' && sorted.length > 0 && (
          <p className="mt-2 text-[10px] text-amber px-1">
            Serviço de tempo real momentaneamente indisponível — os comentários são atualizados a cada 45 segundos.
          </p>
        )}
      </section>
    </div>
  );
}
