'use client';

import { useMemo, useState } from 'react';
import { History } from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  CartesianGrid,
  ComposedChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { DailyPoint, ForecastBundle } from '@/lib/types';
import { Meteocon } from '@/components/meteocons/meteocon';
import { formatShortDayLabel, formatTemp } from '@/lib/format';
import { useProfileContext } from '@/hooks/profile-context';

interface HistoryPoint {
  day: string;
  max: number;
  min: number;
  mm: number;
  prob: number | null;
}

interface TooltipPayloadItem {
  dataKey?: string | number;
  value?: number | string;
}

function HistoryTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string | number;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const row = (key: string) => payload.find((p) => p.dataKey === key);
  const max = row('max');
  const min = row('min');
  const mm = row('mm');
  return (
    <div className="glass-strong rounded-xl px-4 py-3 text-xs shadow-xl">
      <p className="font-display font-semibold mb-1.5">{typeof label === 'string' ? label : ''}</p>
      {max && <p className="text-foreground">Máxima: <span className="font-semibold">{Number(max.value)}°C</span></p>}
      {min && <p className="text-foreground/85">Mínima: <span className="font-semibold">{Number(min.value)}°C</span></p>}
      {mm && <p className="text-cyan">Precipitação: <span className="font-semibold">{Number(mm.value).toFixed(1)} mm</span></p>}
    </div>
  );
}

/** Histórico meteorológico dos últimos 7 dias: gráficos + resumo diário de cada dia. */
export function HistoryCard({ bundle }: { bundle: ForecastBundle }) {
  const { profile } = useProfileContext();
  const [chart, setChart] = useState<'temp' | 'precip'>('temp');

  const history = bundle.historyDaily ?? [];

  const data: HistoryPoint[] = useMemo(
    () =>
      history.map((d) => ({
        day: formatShortDayLabel(d.date),
        max: Math.round(d.tempMax),
        min: Math.round(d.tempMin),
        mm: d.precipitationSum,
        prob: d.precipitationProbabilityMax,
      })),
    [history],
  );

  if (history.length === 0) {
    return null;
  }

  const totalMm = history.reduce((acc, d) => acc + d.precipitationSum, 0);
  const rainDays = history.filter((d) => d.precipitationSum >= 1).length;
  const hottest = history.reduce((a, b) => (b.tempMax > a.tempMax ? b : a), history[0]);
  const coldest = history.reduce((a, b) => (b.tempMin < a.tempMin ? b : a), history[0]);

  return (
    <section aria-label="Histórico meteorológico dos últimos 7 dias" className="glass rounded-xl p-4 mb-4">
      <div className="flex items-center justify-between mb-3 px-1 gap-3 flex-wrap">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold tracking-wide">
          <History className="size-4 text-cyan" /> Histórico — últimos {history.length} dias
        </h2>
        <div className="glass-strong rounded-xl p-0.5 grid grid-cols-2 gap-0.5" role="group" aria-label="Métrica do histórico">
          <button
            onClick={() => setChart('temp')}
            aria-pressed={chart === 'temp'}
            className={`rounded-xl px-3 py-1 text-[11px] font-medium transition min-h-[28px] ${
              chart === 'temp' ? 'bg-cyan/18 text-cyan ' : 'text-atmos hover:text-foreground '
 }`}
          >
            Temperatura
          </button>
          <button
            onClick={() => setChart('precip')}
            aria-pressed={chart === 'precip'}
            className={`rounded-xl px-3 py-1 text-[11px] font-medium transition min-h-[28px] ${
              chart === 'precip' ? 'bg-cyan/18 text-cyan ' : 'text-atmos hover:text-foreground '
 }`}
          >
            Precipitação
          </button>
        </div>
      </div>

      <div className="h-[200px] w-full" role="img" aria-label={`Gráfico de ${chart === 'temp' ? 'temperatura' : 'precipitação'} dos últimos ${history.length} dias`}>
        <ResponsiveContainer width="100%" height="100%">
          {chart === 'temp' ? (
            <AreaChart data={data} margin={{ top: 12, right: 8, bottom: 0, left: -14 }}>
              <defs>
                <linearGradient id="histFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--chart-feels)" stopOpacity={0.26} />
                  <stop offset="100%" stopColor="var(--chart-feels)" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: 'var(--chart-tick)', fontSize: 9 }} axisLine={false} tickLine={false} interval={1} tickMargin={8} />
              <YAxis tick={{ fill: 'var(--chart-tick)', fontSize: 10 }} axisLine={false} tickLine={false} width={34} domain={['auto', 'auto']} />
              <Tooltip content={<HistoryTooltip />} cursor={{ stroke: 'rgba(52,152,219,0.35)', strokeWidth: 1 }} />
              <Area type="monotone" dataKey="max" name="Máxima" stroke="var(--chart-feels)" strokeWidth={2.2} fill="url(#histFill)" dot={false} />
              <Area type="monotone" dataKey="min" name="Mínima" stroke="var(--chart-temp)" strokeWidth={2.2} fill="none" dot={false} />
            </AreaChart>
          ) : (
            <ComposedChart data={data} margin={{ top: 12, right: 8, bottom: 0, left: -14 }}>
              <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
              <XAxis dataKey="day" tick={{ fill: 'var(--chart-tick)', fontSize: 9 }} axisLine={false} tickLine={false} interval={1} tickMargin={8} />
              <YAxis tick={{ fill: 'var(--chart-tick)', fontSize: 10 }} axisLine={false} tickLine={false} width={34} domain={['auto', 'auto']} />
              <Tooltip content={<HistoryTooltip />} cursor={{ fill: 'rgba(52,152,219,0.10)' }} />
              <Bar dataKey="mm" name="Precipitação" fill="var(--chart-precip)" />
            </ComposedChart>
          )}
        </ResponsiveContainer>
      </div>

      {/* Resumo agregado */}
      <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="rounded-xl bg-blue/4 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.14em] text-atmos">Precipitação total</p>
          <p className="mt-1 font-display text-base font-semibold text-cyan">{totalMm.toFixed(1)} mm</p>
        </div>
        <div className="rounded-xl bg-blue/4 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.14em] text-atmos">Dias com chuva</p>
          <p className="mt-1 font-display text-base font-semibold">{rainDays}</p>
        </div>
        <div className="rounded-xl bg-blue/4 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.14em] text-atmos">Dia mais quente</p>
          <p className="mt-1 font-display text-base font-semibold text-amber">{formatTemp(hottest.tempMax, profile.temperatureUnit)}</p>
        </div>
        <div className="rounded-xl bg-blue/4 px-3 py-2.5">
          <p className="text-[10px] uppercase tracking-[0.14em] text-atmos">Dia mais frio</p>
          <p className="mt-1 font-display text-base font-semibold text-blue">{formatTemp(coldest.tempMin, profile.temperatureUnit)}</p>
        </div>
      </div>

      {/* Resumo diário (dias passados) */}
      <div className="mt-3 flex gap-2 overflow-x-auto scroll-thin pb-1.5 -mx-1 px-1">
        {history.map((d: DailyPoint) => (
          <div
            key={d.date}
            className="min-w-[110px] shrink-0 rounded-xl bg-blue/4 px-3 py-2.5"
            aria-label={`Resumo de ${formatShortDayLabel(d.date)}: ${d.weatherLabel}, máxima ${formatTemp(d.tempMax, profile.temperatureUnit)}, mínima ${formatTemp(d.tempMin, profile.temperatureUnit)}, ${d.precipitationSum.toFixed(1)} mm`}
          >
            <p className="text-[10px] text-atmos whitespace-nowrap">{formatShortDayLabel(d.date)}</p>
            <div className="mt-1.5 flex items-center justify-between gap-2">
              <Meteocon code={d.meteocon} size={24} animated={false} />
              <p className="text-xs leading-tight text-right">
                <span className="font-semibold">{formatTemp(d.tempMax, profile.temperatureUnit)}</span>
                <span className="text-atmos"> / {formatTemp(d.tempMin, profile.temperatureUnit)}</span>
              </p>
            </div>
            <p className="mt-1 text-[10px] text-atmos truncate">{d.weatherLabel}</p>
            <p className="text-[10px] text-cyan">{d.precipitationSum.toFixed(1)} mm</p>
          </div>
        ))}
      </div>
    </section>
  );
}
