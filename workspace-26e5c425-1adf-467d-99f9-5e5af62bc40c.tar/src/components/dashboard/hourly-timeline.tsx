'use client';

import { useMemo, useState } from 'react';
import type { ForecastBundle } from '@/lib/types';
import { Meteocon } from '@/components/meteocons/meteocon';
import { formatHour, formatTemp, parseLocalIso } from '@/lib/format';
import { useProfileContext } from '@/hooks/profile-context';

/** Linha temporal horizontal com as próximas 24 ou 48 horas. */
export function HourlyTimeline({ bundle, nowMs }: { bundle: ForecastBundle; nowMs: number }) {
  const { profile } = useProfileContext();
  const [range, setRange] = useState<24 | 48>(24);

  const hours = useMemo(
    () =>
      bundle.hourly
        .filter((h) => parseLocalIso(h.time).getTime() >= nowMs - 30 * 60000)
        .slice(0, range),
    [bundle, nowMs, range],
  );

  if (hours.length === 0) return null;

  return (
    <section aria-label="Previsão horária" className="glass rounded-xl p-4 mb-4">
      <div className="flex items-center justify-between mb-3 px-1 gap-3">
        <h2 className="font-display text-sm font-semibold tracking-wide whitespace-nowrap">
          Próximas {range} horas
        </h2>
        <div className="flex items-center gap-3">
          <div className="glass-strong rounded-xl p-0.5 grid grid-cols-2 gap-0.5" role="group" aria-label="Alcance da previsão horária">
            {([24, 48] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                aria-pressed={range === r}
                className={`rounded-xl px-3 py-1 text-[11px] font-medium transition min-h-[28px] ${
                  range === r ? 'bg-cyan/18 text-cyan ' : 'text-atmos hover:text-foreground '
 }`}
              >
                {r} h
              </button>
            ))}
          </div>
          <span className="hidden sm:inline text-[10px] uppercase tracking-[0.18em] text-atmos">Desliza</span>
        </div>
      </div>
      <div className="flex gap-1 overflow-x-auto scroll-thin pb-2 -mx-1 px-1">
        {hours.map((h, i) => {
          const isNow = i === 0;
          const prob = h.precipitationProbability;
          const dayBreak = i > 0 && h.time.slice(0, 10) !== hours[i - 1].time.slice(0, 10);
          return (
            <div
              key={h.time}
              className={`flex min-w-[64px] flex-1 shrink-0 flex-col items-center gap-1.5 rounded-xl px-2 py-3 ${
                isNow ? ' bg-cyan/8' : dayBreak ? ' bg-blue/6' : ' bg-blue/4'
 }`}
              aria-label={`${formatHour(h.time)}: ${h.weatherLabel}, ${formatTemp(h.temperature, profile.temperatureUnit)}`}
            >
              <span className={`text-[11px] font-medium whitespace-nowrap ${isNow ? 'text-cyan' : dayBreak ? 'text-foreground' : 'text-atmos'}`}>
                {isNow ? 'Agora' : dayBreak ? h.time.slice(8, 10) + '/' + h.time.slice(5, 7) + ' ' + formatHour(h.time) : formatHour(h.time)}
              </span>
              <Meteocon code={h.meteocon} size={30} animated={false} />
              <span className="font-display text-sm font-semibold">{formatTemp(h.temperature, profile.temperatureUnit)}</span>
              <span className={`text-[10px] ${prob !== null && prob >= 40 ? 'text-cyan' : 'text-atmos/70'}`}>
                {prob !== null ? `${prob}%` : '—'}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}
