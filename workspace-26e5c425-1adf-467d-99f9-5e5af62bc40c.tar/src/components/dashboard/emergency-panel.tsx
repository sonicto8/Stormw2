'use client';

import { useCallback, useState } from 'react';
import { LifeBuoy, MapPin, MessageCircle, Navigation, Phone, Plus, ShieldAlert, UserRound } from 'lucide-react';
import { toast } from 'sonner';
import type { ForecastBundle, WeatherAlert } from '@/lib/types';
import { useAppStore } from '@/store/app-store';
import { useProfileContext } from '@/hooks/profile-context';
import { useGeolocation } from '@/hooks/use-geolocation';
import { buildEmergencyMessage, isDisasterSituation, whatsappLink } from '@/lib/engines/emergency';

interface EmergencyPanelProps {
  bundle: ForecastBundle | null;
  alerts: WeatherAlert[];
  nowMs: number;
  /** Variante compacta para o separador Comunidade. */
  compact?: boolean;
}

/**
 * Painel de emergência: contactos configurados, estado de desastre e partilha
 * da localização por WhatsApp. A partilha é sempre iniciada manualmente — a
 * aplicação nunca envia mensagens sem ação do utilizador.
 */
export function EmergencyPanel({ bundle, alerts, nowMs, compact = false }: EmergencyPanelProps) {
  const { profile } = useProfileContext();
  const { location, setActiveTab } = useAppStore();
  const { request, status: geoStatus } = useGeolocation();
  const [sending, setSending] = useState<string | null>(null);

  const contacts = profile.emergencyContacts ?? [];
  const disaster = isDisasterSituation(alerts);
  const cur = bundle?.current ?? null;

  const shareWith = useCallback(
    (contactId: string, gps: { latitude: number; longitude: number } | null) => {
      const contact = contacts.find((c) => c.id === contactId);
      if (!contact) return;
      const message = buildEmergencyMessage({
        placeName: location.name,
        latitude: location.latitude,
        longitude: location.longitude,
        gps,
        alerts,
        conditionLabel: cur?.weatherLabel ?? null,
        temperatureC: cur?.temperature ?? null,
        windKmh: cur?.windSpeed ?? null,
        now: nowMs,
      });
      const url = whatsappLink(contact.phone, message);
      setSending(contactId);
      window.open(url, '_blank', 'noopener,noreferrer');
      toast.success(`A abrir o WhatsApp para ${contact.name}…`);
      setTimeout(() => setSending(null), 1200);
    },
    [contacts, location, alerts, cur, nowMs],
  );

  const share = (contactId: string) => {
    if (contacts.length === 0) return;
    // Localização precisa de GPS em segundo plano; a partilha usa a mais precisa disponível.
    request(
      (coords) => shareWith(contactId, coords),
      () => shareWith(contactId, null),
    );
  };

  const shareBoth = () => {
    request(
      (coords) => {
        contacts.forEach((c, i) => setTimeout(() => shareWith(c.id, coords), i * 350));
      },
      () => {
        contacts.forEach((c, i) => setTimeout(() => shareWith(c.id, null), i * 350));
      },
    );
  };

  return (
    <section
      aria-label="Emergência e partilha de localização"
      className={`rounded-xl p-4 mb-4  ${
        disaster ? ' bg-critical/8 storm-pulse' : 'glass'
 }`}
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2">
          {disaster ? (
            <ShieldAlert className="size-5 text-critical shrink-0" />
          ) : (
            <LifeBuoy className="size-5 text-cyan shrink-0" />
          )}
          <div>
            <h2 className={`font-display text-sm font-semibold ${disaster ? 'text-critical' : ''}`}>
              {disaster ? 'Possível situação grave detetada' : 'Emergência'}
            </h2>
            <p className="text-[11px] text-atmos mt-0.5">
              {disaster
                ? 'Avisos críticos ativos — partilha a tua localização com os teus contactos.'
                : 'Partilha a tua localização por WhatsApp em caso de desastre.'}
            </p>
          </div>
        </div>
        {disaster && (
          <span className="shrink-0 rounded-xl bg-critical/15 px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-critical">
            {alerts.filter((a) => a.origin === 'ipma').length > 0 ? 'IPMA' : 'STORM'} alerta crítico
          </span>
        )}
      </div>

      {contacts.length === 0 ? (
        <div className="rounded-xl bg-blue/4 px-4 py-3.5">
          <p className="text-xs text-foreground/80 leading-relaxed">
            Ainda não tens contactos de emergência. Adiciona até 2 contactos no Perfil — em caso de desastre, a
            localização e os avisos ativos são partilhados por WhatsApp com um toque.
          </p>
          <button
            onClick={() => setActiveTab('perfil')}
            className="mt-3 flex min-h-[40px] items-center gap-2 rounded-xl bg-cyan/15 px-4 text-xs font-medium text-cyan transition hover:bg-cyan/25"
          >
            <Plus className="size-4" /> Adicionar contactos no Perfil
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {contacts.map((c) => (
            <div
              key={c.id}
              className="flex items-center gap-3 rounded-xl bg-blue/4 px-3.5 py-2.5"
            >
              <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-cyan/10">
                <UserRound className="size-4 text-cyan" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{c.name}</p>
                <p className="flex items-center gap-1 text-[11px] text-atmos">
                  <Phone className="size-3" /> {c.phone}
                </p>
              </div>
              <button
                onClick={() => share(c.id)}
                disabled={sending === c.id || geoStatus === 'prompting'}
                className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-xl bg-signal/12 px-3.5 text-xs font-medium text-signal transition hover:bg-signal/25 disabled:opacity-50"
                aria-label={`Partilhar localização por WhatsApp com ${c.name}`}
              >
                <MessageCircle className="size-4" /> WhatsApp
              </button>
            </div>
          ))}
          {contacts.length >= 2 && (
            <button
              onClick={shareBoth}
              disabled={geoStatus === 'prompting'}
              className="flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-critical/15 px-4 text-sm font-semibold text-critical transition hover:bg-critical/25 disabled:opacity-50"
            >
              <ShieldAlert className="size-4" />
              SOS — Partilhar com os {contacts.length} contactos
            </button>
          )}
          <p className="flex items-start gap-1.5 text-[10px] leading-relaxed text-atmos px-1">
            {geoStatus === 'prompting' ? (
              <>
                <Navigation className="size-3 mt-0.5 shrink-0 animate-pulse text-cyan" />
                A obter a localização precisa do dispositivo…
              </>
            ) : (
              <>
                <MapPin className="size-3 mt-0.5 shrink-0" />
                A mensagem inclui o local ativo ({location.name}), coordenadas, link de mapa, condição atual e avisos
                oficiais. A abertura do WhatsApp é feita no teu dispositivo — nada é enviado sem confirmação.
              </>
            )}
          </p>
        </div>
      )}

      {!compact && bundle === null && (
        <p className="mt-2 text-[11px] text-amber px-1">
          A condição atual será incluída na mensagem assim que a previsão estiver disponível.
        </p>
      )}
    </section>
  );
}
