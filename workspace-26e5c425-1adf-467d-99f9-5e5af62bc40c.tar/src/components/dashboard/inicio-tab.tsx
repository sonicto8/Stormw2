'use client';

import type { AirQualityBundle, ForecastBundle, WeatherAlert } from '@/lib/types';
import { TileSkeleton, ErrorState } from '@/components/shared/states';
import { AlertsBanner } from '@/components/dashboard/alerts-banner';
import { WeatherHero } from '@/components/dashboard/hero';
import { EmergencyPanel } from '@/components/dashboard/emergency-panel';
import { HourlyTimeline } from '@/components/dashboard/hourly-timeline';
import { ForecastChart } from '@/components/dashboard/forecast-chart';
import { HistoryCard } from '@/components/dashboard/history-card';
import { DailyForecast } from '@/components/dashboard/daily-forecast';
import { Recommendations } from '@/components/dashboard/recommendations';
import { ActivityIndices } from '@/components/dashboard/activity-indices';

interface InicioTabProps {
  bundle: ForecastBundle | null;
  air: AirQualityBundle | null;
  alerts: WeatherAlert[];
  nowMs: number;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}

/** Separador Início: hero, alertas, linha horária, gráfico, 7 dias, recomendações e índices. */
export function InicioTab({ bundle, air, alerts, nowMs, loading, error, onRetry }: InicioTabProps) {
  if (loading || !bundle) {
    if (!loading && error) {
      return (
        <div className="animate-fade-up">
          <ErrorState
            title="Previsão indisponível neste momento"
            message={`${error} O radar e os reportes continuam disponíveis nos respetivos separadores; sem rede, o último snapshot do dispositivo é usado quando existir.`}
            onRetry={onRetry}
          />
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-4">
        <TileSkeleton className="h-72 w-full" />
        <TileSkeleton className="h-28 w-full" />
        <TileSkeleton className="h-64 w-full" />
        <TileSkeleton className="h-72 w-full" />
      </div>
    );
  }

  return (
    <div className="animate-fade-up">
      <AlertsBanner alerts={alerts} />
      <WeatherHero bundle={bundle} air={air} alerts={alerts} nowMs={nowMs} />
      <EmergencyPanel bundle={bundle} alerts={alerts} nowMs={nowMs} />
      <HourlyTimeline bundle={bundle} nowMs={nowMs} />
      <ForecastChart bundle={bundle} nowMs={nowMs} />
      <DailyForecast bundle={bundle} />
      <HistoryCard bundle={bundle} />
      <Recommendations bundle={bundle} air={air} nowMs={nowMs} />
      <ActivityIndices bundle={bundle} nowMs={nowMs} />
    </div>
  );
}
