'use client';

import { useMemo, useState } from 'react';
import { Info } from 'lucide-react';
import type { ActivityKey, ForecastBundle } from '@/lib/types';
import { ACTIVITY_KEYS, activityLabel, computeActivityIndex } from '@/lib/engines/activity-index';
import { formatHour } from '@/lib/format';
import { SectionTitle } from '@/components/shared/ui';

function scoreColor(score: number): string {
  // Vars CSS por tema (claro/escuro) — definidas em globals.css.
  if (score >= 80) return 'var(--score-good)';
  if (score >= 65) return 'var(--score-fair)';
  if (score >= 45) return 'var(--score-moderate)';
  return 'var(--score-bad)';
}

function ScoreRing({ score }: { score: number }) {
  const color = scoreColor(score);
  const circumference = 2 * Math.PI * 20;
  const offset = circumference * (1 - score / 100);
  return (
    <div className="relative size-12 shrink-0" role="img" aria-label={`Índice ${score} de 100`}>
      <svg viewBox="0 0 48 48" className="size-12 -rotate-90">
        <circle cx="24" cy="24" r="20" fill="none" stroke="var(--chart-grid)" strokeWidth="4" />
        <circle
          cx="24"
          cy="24"
          r="20"
          fill="none"
          stroke={color}
          strokeWidth="4"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="transition-[stroke-dashoffset] duration-700"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-display text-sm font-bold" style={{ color }}>
        {score}
      </span>
    </div>
  );
}

/** Índices de atividade (0–100) para as próximas 12 horas. */
export function ActivityIndices({ bundle, nowMs }: { bundle: ForecastBundle; nowMs: number }) {
  const [selected, setSelected] = useState<ActivityKey>('running');
  const indices = useMemo(
    () =>
      ACTIVITY_KEYS.map((key) => ({
        key,
        index: computeActivityIndex(key, bundle.hourly, bundle.daily, nowMs),
      })),
    [bundle, nowMs],
  );

  const active = indices.find((i) => i.key === selected)?.index ?? null;

  return (
    <section aria-label="Índices de atividade" className="mb-4">
      <SectionTitle kicker="Condições para atividades" title="Índices de atividade" />
      <div className="flex gap-2 overflow-x-auto scroll-thin pb-2 -mx-1 px-1">
        {indices.map(({ key, index }) => {
          const isActive = key === selected;
          return (
            <button
              key={key}
              onClick={() => setSelected(key)}
              aria-pressed={isActive}
              className={`flex shrink-0 items-center gap-2.5 rounded-xl px-3.5 py-2.5 transition-all min-h-[44px] ${
                isActive ? ' bg-cyan/10' : ' bg-blue/4 '
 }`}
            >
              {index ? (
                <ScoreRing score={index.score} />
              ) : (
                <div className="flex size-12 items-center justify-center rounded-xl text-[10px] text-atmos">N/D</div>
              )}
              <span className="text-xs font-medium">{activityLabel(key)}</span>
            </button>
          );
        })}
      </div>

      {active && (
        <div className="glass rounded-xl p-4 mt-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-display text-base font-semibold">{active.label}</h3>
            <span
              className="rounded-xl px-2.5 py-0.5 text-[11px] font-medium"
              style={{ borderColor: `color-mix(in srgb, ${scoreColor(active.score)} 45%, transparent)`, color: scoreColor(active.score), background: `color-mix(in srgb, ${scoreColor(active.score)} 10%, transparent)` }}
            >
              {active.classification}
            </span>
            {active.bestHour && (
              <span className="text-xs text-atmos">Melhor às {formatHour(active.bestHour)}</span>
            )}
          </div>
          <p className="mt-2 text-xs leading-relaxed text-foreground/80">{active.justification}</p>
          {!active.sufficientData && (
            <p className="mt-2 flex items-center gap-1.5 text-[11px] text-amber">
              <Info className="size-3.5" /> Alguns dados (humidade, UV ou probabilidade) estão indisponíveis — o índice foi calculado com os valores existentes.
            </p>
          )}
        </div>
      )}
    </section>
  );
}
