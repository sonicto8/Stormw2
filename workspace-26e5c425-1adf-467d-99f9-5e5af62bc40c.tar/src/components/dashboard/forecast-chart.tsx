'use client';

import { useMemo, useState } from 'react';
import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { ForecastBundle } from '@/lib/types';
import { formatHour, parseLocalIso } from '@/lib/format';

interface ChartPoint {
  hour: string;
  temp: number;
  feels: number;
  mm: number;
  prob: number | null;
}

interface TooltipPayloadItem {
  dataKey?: string | number;
  value?: number | string;
}

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string | number;
}) {
  if (!active || !payload || payload.length === 0) return null;
  const row = (key: string) => payload.find((p) => p.dataKey === key);
  const temp = row('temp');
  const feels = row('feels');
  const mm = row('mm');
  const prob = row('prob');
  return (
    <div className="glass-strong rounded-xl px-4 py-3 text-xs shadow-xl">
      <p className="font-display font-semibold mb-1.5">{typeof label === 'string' ? label : `${label}h`}</p>
      {temp && <p className="text-foreground">Temperatura: <span className="font-semibold">{Number(temp.value)}°C</span></p>}
      {feels && <p className="text-foreground/85">Sensação térmica: <span className="font-semibold">{Number(feels.value)}°C</span></p>}
      {mm && <p className="text-cyan">Precipitação: <span className="font-semibold">{Number(mm.value).toFixed(1)} mm</span></p>}
      {prob && prob.value !== null && (
        <p className="text-signal">Probabilidade de chuva: <span className="font-semibold">{Number(prob.value)}%</span></p>
      )}
    </div>
  );
}

/** Gráfico interativo: temperatura, sensação, precipitação e probabilidade a 24 ou 48 horas. */
export function ForecastChart({ bundle, nowMs }: { bundle: ForecastBundle; nowMs: number }) {
  const [range, setRange] = useState<24 | 48>(24);

  const data: ChartPoint[] = useMemo(
    () =>
      bundle.hourly
        .filter((h) => parseLocalIso(h.time).getTime() >= nowMs - 30 * 60000)
        .slice(0, range)
        .map((h) => ({
          hour: formatHour(h.time),
          temp: h.temperature,
          feels: h.apparentTemperature,
          mm: h.precipitation,
          prob: h.precipitationProbability,
        })),
    [bundle, nowMs, range],
  );

  if (data.length === 0) return null;

  return (
    <section aria-label="Gráfico de previsão" className="glass rounded-xl p-4 mb-4">
      <div className="flex items-center justify-between mb-1 px-1 gap-3 flex-wrap">
        <h2 className="font-display text-sm font-semibold tracking-wide">Evolução a {range} horas</h2>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="glass-strong rounded-xl p-0.5 grid grid-cols-2 gap-0.5" role="group" aria-label="Alcance do gráfico">
            {([24, 48] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                aria-pressed={range === r}
                className={`rounded-xl px-3 py-1 text-[11px] font-medium transition min-h-[28px] ${
                  range === r ? 'bg-cyan/18 text-cyan ' : 'text-atmos hover:text-foreground '
 }`}
              >
                {r} h
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3 text-[10px] text-atmos">
            <span className="flex items-center gap-1"><span className="size-2 rounded-xl bg-cyan" /> Temperatura</span>
            <span className="flex items-center gap-1"><span className="size-2 rounded-xl bg-signal" /> Probabilidade</span>
            <span className="flex items-center gap-1"><span className="size-2 rounded-xl bg-blue" /> Precipitação</span>
          </div>
        </div>
      </div>
      <div className="h-[240px] w-full" role="img" aria-label={`Gráfico de temperatura, precipitação e probabilidade de chuva das próximas ${range} horas`}>
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 12, right: 8, bottom: 0, left: -14 }}>
            <defs>
              <linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--chart-temp)" stopOpacity={0.30} />
                <stop offset="100%" stopColor="var(--chart-temp)" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
            <XAxis
              dataKey="hour"
              tick={{ fill: 'var(--chart-tick)', fontSize: 10 }}
              axisLine={false}
              tickLine={false}
              interval={range === 48 ? 5 : 2}
              tickMargin={8}
            />
            <YAxis yAxisId="temp" tick={{ fill: 'var(--chart-tick)', fontSize: 10 }} axisLine={false} tickLine={false} width={34} domain={['auto', 'auto']} />
            <YAxis yAxisId="prob" orientation="right" domain={[0, 100]} tick={{ fill: 'var(--chart-tick)', fontSize: 10 }} axisLine={false} tickLine={false} width={30} />
            <Tooltip content={<ChartTooltip />} cursor={{ stroke: 'rgba(52,152,219,0.35)', strokeWidth: 1 }} />
            <Area yAxisId="temp" type="monotone" dataKey="temp" name="Temperatura" stroke="var(--chart-temp)" strokeWidth={2.4} fill="url(#tempFill)" dot={false} activeDot={{ r: 4, fill: 'var(--chart-temp)' }} />
            <Line yAxisId="temp" type="monotone" dataKey="feels" name="Sensação" stroke="var(--chart-feels)" strokeOpacity={0.8} strokeWidth={1.6} strokeDasharray="4 4" dot={false} />
            <Bar yAxisId="prob" dataKey="mm" name="Precipitação" fill="var(--chart-precip)" barSize={7} />
            <Line yAxisId="prob" type="monotone" dataKey="prob" name="Probabilidade" stroke="var(--chart-prob)" strokeWidth={1.8} dot={false} connectNulls />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}
