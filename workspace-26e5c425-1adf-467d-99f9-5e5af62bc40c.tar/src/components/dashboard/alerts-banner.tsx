'use client';

import { useState } from 'react';
import { ChevronDown, ShieldAlert } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import type { WeatherAlert } from '@/lib/types';
import { formatTime } from '@/lib/format';

/** Cor visual do alerta: IPMA mantém a cor oficial (barra lateral); internos usam severidade. */
function alertTone(alert: WeatherAlert): { stripe: string; bg: string; text: string; label: string; labelClass: string } {
  if (alert.origin === 'ipma' && alert.officialLevel === 'red') {
    return {
      stripe: 'border-l-[3px] border-l-critical',
      bg: 'bg-critical/10',
      text: 'text-critical',
      label: 'Aviso vermelho · IPMA',
      labelClass: 'bg-critical/20 text-critical',
    };
  }
  if (alert.origin === 'ipma' && alert.officialLevel === 'orange') {
    return {
      stripe: 'border-l-[3px] border-l-amber',
      bg: 'bg-amber/10',
      text: 'text-amber',
      label: 'Aviso laranja · IPMA',
      labelClass: 'bg-amber/20 text-amber',
    };
  }
  if (alert.origin === 'ipma' && alert.officialLevel === 'yellow') {
    return {
      stripe: 'border-l-[3px] border-l-amber/60',
      bg: 'bg-amber/6',
      text: 'text-amber',
      label: 'Aviso amarelo · IPMA',
      labelClass: 'bg-amber/12 text-amber',
    };
  }
  if (alert.severity === 'critical') {
    return {
      stripe: 'border-l-[3px] border-l-critical',
      bg: 'bg-critical/10',
      text: 'text-critical',
      label: 'Alerta crítico',
      labelClass: 'bg-critical/15 text-critical',
    };
  }
  if (alert.severity === 'warning') {
    return {
      stripe: 'border-l-[3px] border-l-amber',
      bg: 'bg-amber/8',
      text: 'text-amber',
      label: 'Alerta de atenção',
      labelClass: 'bg-amber/12 text-amber',
    };
  }
  return {
    stripe: 'border-l-[3px] border-l-cyan/60',
    bg: 'bg-cyan/6',
    text: 'text-cyan',
    label: 'Informação',
    labelClass: 'bg-cyan/10 text-cyan',
  };
}

/** Cartão de alerta — também reutilizado pelo separador Alertas. */
export function AlertCard({ alert, index }: { alert: WeatherAlert; index: number }) {
  const tone = alertTone(alert);
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: index * 0.05 }}
      className={`rounded-xl px-4 py-3 ${tone.stripe} ${tone.bg} ${alert.severity === 'critical' ? 'alert-critical-pulse' : ''}`}
      role={alert.severity === 'critical' ? 'alert' : 'status'}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className={`inline-flex items-center rounded-xl px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] ${tone.labelClass}`}>
          {tone.label}
        </span>
        <h3 className={`text-sm font-semibold ${tone.text}`}>{alert.title}</h3>
      </div>
      <p className="mt-1.5 text-xs leading-relaxed text-foreground/85">{alert.description}</p>
      {(alert.start || alert.end) && (
        <p className="mt-1.5 text-[11px] text-atmos">
          {alert.start && `Início: ${formatTime(alert.start)}`}
          {alert.start && alert.end && ' · '}
          {alert.end && `Fim: ${formatTime(alert.end)}`}
        </p>
      )}
    </motion.div>
  );
}

export function AlertsBanner({ alerts }: { alerts: WeatherAlert[] }) {
  const [expanded, setExpanded] = useState(false);
  if (alerts.length === 0) return null;

  const visible = expanded ? alerts : alerts.slice(0, 2);
  const hidden = alerts.length - visible.length;

  return (
    <section aria-label="Alertas meteorológicos" className="mb-4">
      <AnimatePresence initial={false}>
        {visible.map((alert, i) => (
          <div key={alert.id} className="mb-2">
            <AlertCard alert={alert} index={i} />
          </div>
        ))}
      </AnimatePresence>
      {hidden > 0 && (
        <button
          onClick={() => setExpanded((v) => !v)}
          className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-blue/5 py-2 text-xs text-atmos transition  hover:text-cyan"
          aria-expanded={expanded}
        >
          <ShieldAlert className="size-3.5" />
          {expanded ? 'Mostrar menos' : `Ver mais ${hidden} alerta${hidden > 1 ? 's' : ''}`}
          <ChevronDown className={`size-3.5 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </button>
      )}
    </section>
  );
}
