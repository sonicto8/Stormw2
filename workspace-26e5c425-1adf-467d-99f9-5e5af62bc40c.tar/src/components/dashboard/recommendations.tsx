'use client';

import { Sparkles, Info } from 'lucide-react';
import { useMemo } from 'react';
import type { AirQualityBundle, ForecastBundle } from '@/lib/types';
import { computeRecommendations } from '@/lib/engines/recommendations';
import { useProfileContext } from '@/hooks/profile-context';
import { SectionTitle } from '@/components/shared/ui';

function ConfidenceBar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-16 overflow-hidden rounded-xl bg-blue/10" aria-hidden="true">
        <div
          className="h-full rounded-xl bg-gradient-to-r from-cyan to-violet transition-[width] duration-500"
          style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
        />
      </div>
      <span className="text-[10px] text-atmos">Confiança {value}%</span>
    </div>
  );
}

/** Secção "INTELIGÊNCIA PARA TI" — melhores horas com confiança e justificação. */
export function Recommendations({ bundle, air, nowMs }: { bundle: ForecastBundle; air: AirQualityBundle | null; nowMs: number }) {
  const { profile } = useProfileContext();
  const items = useMemo(() => computeRecommendations(bundle, nowMs, profile), [bundle, nowMs, profile]);

  return (
    <section aria-label="Recomendações personalizadas" className="mb-4">
      <SectionTitle kicker="Inteligência para ti" title="Recomendações das próximas horas" />
      <div className="grid gap-2.5 sm:grid-cols-2">
        {items.map((item) => (
          <article key={item.key} className="glass glass-hover rounded-xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-cyan">
                  <Sparkles className="size-3.5" />
                  {item.title}
                </p>
                <p className="mt-1.5 font-display text-xl font-bold leading-none">{item.hour}</p>
              </div>
              <div className="text-right shrink-0">
                <p className="font-display text-2xl font-bold text-glow-cyan">{item.score}</p>
                <p className="text-[10px] text-atmos">índice /100</p>
              </div>
            </div>
            <p className="mt-2.5 text-xs leading-relaxed text-foreground/80">{item.justification}</p>
            <div className="mt-3 flex items-center justify-between gap-2">
              <ConfidenceBar value={item.confidence} />
              {!item.sufficientData && (
                <span className="flex items-center gap-1 text-[10px] text-amber">
                  <Info className="size-3" /> Dados parciais
                </span>
              )}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
