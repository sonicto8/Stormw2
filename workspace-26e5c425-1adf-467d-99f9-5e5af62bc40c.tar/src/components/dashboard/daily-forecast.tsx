'use client';

import { useState } from 'react';
import { ChevronDown, Droplets, Sunrise, Sunset, Wind } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import type { ForecastBundle } from '@/lib/types';
import { Meteocon } from '@/components/meteocons/meteocon';
import { formatShortDayLabel, formatTemp, uvLabel } from '@/lib/format';
import { useProfileContext } from '@/hooks/profile-context';

/** Cartões dos próximos 7 dias com detalhe expansível. */
export function DailyForecast({ bundle }: { bundle: ForecastBundle }) {
  const { profile } = useProfileContext();
  const [open, setOpen] = useState<string | null>(null);
  const days = bundle.daily.slice(0, 7);

  if (days.length === 0) return null;

  return (
    <section aria-label="Previsão para 7 dias" className="glass rounded-xl p-4 mb-4">
      <h2 className="font-display text-sm font-semibold tracking-wide px-1 mb-3">Próximos 7 dias</h2>
      <div className="flex flex-col gap-1.5">
        {days.map((d) => {
          const expanded = open === d.date;
          return (
            <div key={d.date} className="rounded-xl bg-blue/4 overflow-hidden">
              <button
                onClick={() => setOpen(expanded ? null : d.date)}
                aria-expanded={expanded}
                className="flex w-full items-center gap-3 px-3.5 py-3 text-left transition hover:bg-blue/6 min-h-[44px]"
              >
                <span className="w-[92px] shrink-0 text-xs font-medium text-foreground/90">
                  {formatShortDayLabel(d.date)}
                </span>
                <Meteocon code={d.meteocon} size={34} animated={false} />
                <span className="flex-1 min-w-0 hidden sm:block truncate text-xs text-atmos">{d.weatherLabel}</span>
                <span className="flex items-center gap-1 text-[11px] text-cyan">
                  <Droplets className="size-3" />
                  {d.precipitationProbabilityMax !== null ? `${d.precipitationProbabilityMax}%` : '—'}
                </span>
                <span className="flex items-baseline gap-2 font-display tabular-nums">
                  <span className="text-sm text-atmos">{formatTemp(d.tempMin, profile.temperatureUnit)}</span>
                  <span className="text-sm font-semibold">{formatTemp(d.tempMax, profile.temperatureUnit)}</span>
                </span>
                <ChevronDown className={`size-4 text-atmos transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence initial={false}>
                {expanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-3.5 pb-3.5 pt-1 text-xs">
                      <div className="rounded-xl bg-blue/5 px-3 py-2">
                        <p className="text-atmos text-[10px] uppercase tracking-[0.14em] mb-0.5">Precipitação</p>
                        <p className="font-semibold">{d.precipitationSum.toFixed(1)} mm</p>
                      </div>
                      <div className="rounded-xl bg-blue/5 px-3 py-2">
                        <p className="text-atmos text-[10px] uppercase tracking-[0.14em] mb-0.5">Vento / rajadas</p>
                        <p className="font-semibold flex items-center gap-1">
                          <Wind className="size-3 text-atmos" /> {d.windSpeedMax !== null ? `${Math.round(d.windSpeedMax)} km/h` : '—'}
                          {d.windGustsMax !== null && <span className="text-atmos font-normal">· {Math.round(d.windGustsMax)}</span>}
                        </p>
                      </div>
                      <div className="rounded-xl bg-blue/5 px-3 py-2">
                        <p className="text-atmos text-[10px] uppercase tracking-[0.14em] mb-0.5">UV máximo</p>
                        <p className="font-semibold">
                          {d.uvIndexMax !== null ? `${d.uvIndexMax.toFixed(1)} · ${uvLabel(d.uvIndexMax)}` : '—'}
                        </p>
                      </div>
                      <div className="rounded-xl bg-blue/5 px-3 py-2">
                        <p className="text-atmos text-[10px] uppercase tracking-[0.14em] mb-0.5">Sol</p>
                        <p className="font-semibold flex flex-col gap-0.5">
                          <span className="flex items-center gap-1"><Sunrise className="size-3 text-amber" /> {d.sunrise ? d.sunrise.slice(11, 16) : '—'}</span>
                          <span className="flex items-center gap-1"><Sunset className="size-3 text-violet" /> {d.sunset ? d.sunset.slice(11, 16) : '—'}</span>
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
}
