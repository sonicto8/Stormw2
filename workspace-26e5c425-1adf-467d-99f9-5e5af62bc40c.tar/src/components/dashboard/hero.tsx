'use client';

import { Clock, Droplets, Gauge, Sun, Thermometer, Wind, Zap, CloudRain, ArrowDown, ArrowUp, Eye } from 'lucide-react';
import type { AirQualityBundle, ForecastBundle, WeatherAlert } from '@/lib/types';
import { Meteocon } from '@/components/meteocons/meteocon';
import { computeRainCountdown } from '@/lib/engines/rain-countdown';
import { buildSmartSummary } from '@/lib/engines/summary';
import { aqiLabel, formatTemp, formatTempValue, formatWind, uvLabel, windDirectionLabel } from '@/lib/format';
import { useProfileContext } from '@/hooks/profile-context';
import type { Profile } from '@/lib/schemas/report.schema';

interface HeroProps {
  bundle: ForecastBundle;
  air: AirQualityBundle | null;
  alerts: WeatherAlert[];
  nowMs: number;
}

function DetailTile({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: typeof Thermometer;
  label: string;
  value: string;
  sub?: string | null;
}) {
  return (
    <div className="rounded-lg bg-blue/4 px-3.5 py-3 min-w-0">
      <div className="flex items-center gap-1.5 text-atmos">
        <Icon className="size-3.5 shrink-0" />
        <span className="truncate text-[10px] uppercase tracking-[0.14em]">{label}</span>
      </div>
      <p className="mt-1.5 font-display text-lg font-semibold leading-none truncate">{value}</p>
      {sub && <p className="mt-1 truncate text-[11px] text-atmos">{sub}</p>}
    </div>
  );
}

function RainCountdownCard({ bundle, nowMs, profile }: { bundle: ForecastBundle; nowMs: number; profile: Profile }) {
  const cd = computeRainCountdown(bundle, nowMs);
  const tone =
    cd.status === 'raining' || cd.status === 'imminent'
      ? { bg: 'bg-cyan/8', text: 'text-cyan', icon: 'text-cyan' }
      : cd.status === 'clear'
        ? { bg: 'bg-signal/6', text: 'text-signal', icon: 'text-signal' }
        : { bg: 'bg-blue/4', text: 'text-atmos', icon: 'text-atmos' };

  return (
    <div className={`rounded-lg px-4 py-3.5 ${tone.bg}`}>
      <div className="flex items-center gap-2">
        <Clock className={`size-4 ${tone.icon}`} />
        <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-atmos">Contagem decrescente de chuva</span>
      </div>
      <p className={`mt-2 font-display text-base font-semibold ${tone.text}`}>{cd.headline}</p>
      <p className="mt-1 text-xs leading-relaxed text-foreground/80">{cd.detail}</p>
      {cd.status === 'raining' && cd.durationMinutes !== null && (
        <p className="mt-1 text-[11px] text-atmos">Duração prevista: ~{cd.durationMinutes} min</p>
      )}
    </div>
  );
}

export function WeatherHero({ bundle, air, alerts, nowMs }: HeroProps) {
  const { profile } = useProfileContext();
  const cur = bundle.current;
  const today = bundle.daily[0];
  const summary = buildSmartSummary(bundle, air, computeRainCountdown(bundle, nowMs), alerts);
  const aqi = air?.europeanAqi ?? null;
  const aqiInfo = aqiLabel(aqi);

  return (
    <section aria-label="Condições atuais" className="glass rounded-2xl p-5 sm:p-6 mb-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-5 sm:gap-8">
        {/* Temperatura dominante */}
        <div className="flex items-center gap-4">
          <div className="shrink-0">
            <Meteocon code={cur.meteocon} size={96} />
          </div>
          <div>
            <div className="flex items-start gap-1">
              <span className="font-display text-[64px] sm:text-[76px] font-bold leading-none tracking-tight text-glow-cyan">
                {formatTemp(cur.temperature, profile.temperatureUnit)}
              </span>
            </div>
            <p className="mt-1.5 text-sm font-medium text-foreground/90">{cur.weatherLabel}</p>
            <p className="text-xs text-atmos mt-0.5">
              Sensação de {formatTempValue(cur.apparentTemperature, profile.temperatureUnit)}
            </p>
          </div>
        </div>

        {/* Resumo inteligente */}
        <div className="flex-1 min-w-0 sm:border-l sm:border-blue/8 sm:pl-6">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-atmos mb-1.5">Resumo inteligente</p>
          <p className="text-sm leading-relaxed text-foreground/85">{summary}</p>
        </div>
      </div>

      {/* Contagem decrescente de chuva */}
      <div className="mt-4">
        <RainCountdownCard bundle={bundle} nowMs={nowMs} profile={profile} />
      </div>

      {/* Grelha de detalhes */}
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <DetailTile
          icon={Thermometer}
          label="Máxima hoje"
          value={today ? formatTemp(today.tempMax, profile.temperatureUnit) : '—'}
          sub={today ? `Mínima ${formatTemp(today.tempMin, profile.temperatureUnit)}` : null}
        />
        <DetailTile
          icon={Droplets}
          label="Humidade"
          value={cur.humidity !== null ? `${cur.humidity}%` : '—'}
          sub={today?.precipitationProbabilityMax !== null && today ? `${today.precipitationProbabilityMax}% prob. máxima` : null}
        />
        <DetailTile
          icon={Wind}
          label="Vento"
          value={formatWind(cur.windSpeed, profile.windUnit)}
          sub={`${windDirectionLabel(cur.windDirection)} · rajadas ${formatWind(cur.windGusts, profile.windUnit)}`}
        />
        <DetailTile
          icon={Sun}
          label="Índice UV"
          value={cur.uvIndex !== null ? cur.uvIndex.toFixed(1) : '—'}
          sub={cur.uvIndex !== null ? uvLabel(cur.uvIndex) : null}
        />
        <DetailTile
          icon={CloudRain}
          label="Precipitação"
          value={`${cur.precipitation.toFixed(1)} mm`}
          sub={today ? `${today.precipitationSum.toFixed(1)} mm hoje` : null}
        />
        <DetailTile
          icon={Gauge}
          label="Pressão"
          value={cur.pressureMsl !== null ? `${Math.round(cur.pressureMsl)} hPa` : '—'}
          sub={cur.pressureMsl !== null ? 'ao nível médio do mar' : null}
        />
        <DetailTile
          icon={Eye}
          label="Visibilidade"
          value={cur.visibility !== null ? (cur.visibility >= 1000 ? `${(cur.visibility / 1000).toFixed(cur.visibility >= 10000 ? 0 : 1)} km` : `${Math.round(cur.visibility)} m`) : '—'}
          sub={cur.visibility !== null ? (cur.visibility >= 10000 ? 'Excelente' : cur.visibility >= 4000 ? 'Boa' : cur.visibility >= 1000 ? 'Moderada' : 'Reduzida') : null}
        />
        <DetailTile
          icon={aqiInfo.tone === 'poor' || aqiInfo.tone === 'very-poor' ? Gauge : Zap}
          label="Qualidade do ar"
          value={aqi !== null ? `AQI ${Math.round(aqi)}` : '—'}
          sub={aqi !== null ? aqiInfo.label : 'Indisponível'}
        />
      </div>

      {/* Nascer/pôr do sol */}
      {today?.sunrise && today?.sunset && (
        <div className="mt-3 flex items-center justify-center gap-6 rounded-lg bg-blue/4 px-4 py-2.5 text-xs text-atmos">
          <span className="flex items-center gap-1.5">
            <ArrowUp className="size-3.5 text-amber" /> Nascer {today.sunrise.slice(11, 16)}
          </span>
          <span className="flex items-center gap-1.5">
            <ArrowDown className="size-3.5 text-violet" /> Pôr {today.sunset.slice(11, 16)}
          </span>
        </div>
      )}
    </section>
  );
}
