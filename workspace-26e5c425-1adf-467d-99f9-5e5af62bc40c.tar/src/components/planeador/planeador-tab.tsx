'use client';

import { useMemo } from 'react';
import { Ban, CalendarCheck, Car, CheckCircle2, Info, Shirt, Sparkles, Sun, TreePine } from 'lucide-react';
import type { ForecastBundle, PlannerCriterion } from '@/lib/types';
import { computePlanner } from '@/lib/engines/planner';
import { Meteocon } from '@/components/meteocons/meteocon';
import { formatTemp } from '@/lib/format';
import { useProfileContext } from '@/hooks/profile-context';
import { TileSkeleton, EmptyState, ErrorState } from '@/components/shared/states';
import { SectionTitle } from '@/components/shared/ui';

const CRITERION_META: Record<PlannerCriterion['key'], { icon: typeof Car; accent: string }> = {
  'car-wash': { icon: Car, accent: 'text-cyan' },
  laundry: { icon: Shirt, accent: 'text-violet' },
  outdoor: { icon: Sun, accent: 'text-amber' },
  picnic: { icon: TreePine, accent: 'text-signal' },
};

function CriterionCard({ criterion }: { criterion: PlannerCriterion }) {
  const meta = CRITERION_META[criterion.key];
  const Icon = meta.icon;
  const hasWinner = criterion.winnerDate !== null;

  return (
    <article className="glass glass-hover rounded-xl p-4">
      <div className="flex items-center gap-2.5">
        <div className="flex size-10 items-center justify-center rounded-xl bg-blue/5">
          <Icon className={`size-5 ${meta.accent}`} />
        </div>
        <div className="min-w-0">
          <h3 className="font-display text-sm font-semibold">{criterion.label}</h3>
          <p className="text-[10px] uppercase tracking-[0.16em] text-atmos">Próximos 7 dias</p>
        </div>
      </div>

      {!criterion.sufficientData ? (
        <div className="mt-3 flex items-start gap-2 rounded-xl border-l-[3px] border-l-amber bg-amber/8 px-3 py-2.5">
          <Info className="mt-0.5 size-3.5 shrink-0 text-amber" />
          <p className="text-xs text-amber leading-relaxed">{criterion.justification}</p>
        </div>
      ) : hasWinner ? (
        <div className="mt-3 flex items-center gap-3 rounded-xl bg-signal/8 px-3.5 py-3">
          <CheckCircle2 className="size-5 shrink-0 text-signal" />
          <div className="min-w-0">
            <p className="text-[10px] uppercase tracking-[0.16em] text-atmos">Melhor dia</p>
            <p className="font-display text-base font-bold text-signal">{criterion.winnerLabel}</p>
          </div>
        </div>
      ) : (
        <div className="mt-3 flex items-center gap-3 rounded-xl bg-amber/8 px-3.5 py-3">
          <CalendarCheck className="size-5 shrink-0 text-amber" />
          <p className="text-xs text-amber leading-relaxed">{criterion.winnerLabel}</p>
        </div>
      )}

      <p className="mt-2.5 text-xs leading-relaxed text-foreground/80">{criterion.justification}</p>

      {criterion.alternatives.length > 0 && (
        <div className="mt-3">
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-atmos mb-1.5">Alternativas</p>
          <ul className="flex flex-col gap-1.5">
            {criterion.alternatives.map((a) => (
              <li key={a.date} className="rounded-xl bg-blue/4 px-3 py-2 text-[11px] leading-relaxed">
                <span className="font-semibold">{a.label}</span> — <span className="text-foreground/75">{a.reason}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {criterion.daysToAvoid.length > 0 && (
        <div className="mt-3">
          <p className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-critical mb-1.5">
            <Ban className="size-3" /> Dias a evitar
          </p>
          <ul className="flex flex-col gap-1.5">
            {criterion.daysToAvoid.map((a) => (
              <li key={a.date} className="rounded-xl bg-critical/8 px-3 py-2 text-[11px] leading-relaxed">
                <span className="font-semibold text-critical">{a.label}</span> — <span className="text-foreground/75">{a.reason}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </article>
  );
}

export function PlaneadorTab({
  bundle,
  loading,
  error,
}: {
  bundle: ForecastBundle | null;
  loading: boolean;
  error: string | null;
}) {
  const { profile } = useProfileContext();
  const criteria = useMemo(() => (bundle ? computePlanner(bundle.daily) : []), [bundle]);

  if (loading || !bundle) {
    if (!loading && error) {
      return (
        <div className="animate-fade-up">
          <ErrorState
            title="Planeador indisponível neste momento"
            message={`${error} O planeador depende da previsão diária do Open-Meteo; tenta novamente ou espera que o limite da fonte seja reposto.`}
          />
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-4 animate-fade-up">
        <TileSkeleton className="h-24 w-full" />
        <div className="grid gap-3 lg:grid-cols-2">
          <TileSkeleton className="h-64" />
          <TileSkeleton className="h-64" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 animate-fade-up">
      <div className="glass rounded-xl p-4">
        <SectionTitle kicker="Planeador semanal" title="Quando fazer o quê" />
        <p className="text-xs leading-relaxed text-foreground/75 -mt-1">
          Avaliação automática das regras de cada atividade sobre a previsão diária real dos próximos 7 dias
          na tua localização. Os resultados atualizam com cada atualização dos dados.
        </p>
      </div>

      {criteria.length === 0 ? (
        <EmptyState title="Sem dados diários" message="A previsão para os próximos dias ainda não está disponível." />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {criteria.map((c) => (
            <CriterionCard key={c.key} criterion={c} />
          ))}
        </div>
      )}

      {/* Visão geral dos 7 dias */}
      <section aria-label="Visão geral de 7 dias" className="glass rounded-xl p-4">
        <h2 className="font-display text-sm font-semibold tracking-wide px-1 mb-3">Resumo diário</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {bundle.daily.slice(0, 7).map((d) => (
            <div key={d.date} className="flex flex-col items-center gap-1.5 rounded-xl bg-blue/4 px-2 py-3">
              <span className="text-[10px] text-atmos">{d.date.slice(8, 10)}/{d.date.slice(5, 7)}</span>
              <Meteocon code={d.meteocon} size={32} animated={false} />
              <span className="font-display text-sm font-semibold">{formatTemp(d.tempMax, profile.temperatureUnit)}</span>
              <span className="text-[10px] text-atmos">{formatTemp(d.tempMin, profile.temperatureUnit)}</span>
              <span className="text-[10px] text-cyan">{d.precipitationProbabilityMax !== null ? `${d.precipitationProbabilityMax}%` : '—'}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 flex items-start gap-1.5 text-[10px] text-atmos px-1">
          <Sparkles className="mt-0.5 size-3 shrink-0" />
          Temperatura máxima e mínima com probabilidade máxima de precipitação por dia.
        </p>
      </section>
    </div>
  );
}
