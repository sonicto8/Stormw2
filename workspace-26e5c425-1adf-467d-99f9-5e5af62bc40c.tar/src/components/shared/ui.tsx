'use client';

import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

export function FadeUp({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.28, delay, ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function SectionTitle({ kicker, title, action }: { kicker?: string; title: string; action?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-3 mb-3">
      <div>
        {kicker && (
          <p className="text-[11px] font-display uppercase tracking-[0.22em] text-atmos/90 mb-1">{kicker}</p>
        )}
        <h2 className="text-lg font-display font-semibold tracking-tight">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function Badge({ children, tone = 'neutral', pulse }: { children: ReactNode; tone?: 'cyan' | 'green' | 'amber' | 'red' | 'violet' | 'neutral'; pulse?: boolean }) {
  const tones: Record<string, string> = {
    cyan: 'bg-cyan/10 text-cyan ',
    green: 'bg-signal/10 text-signal ',
    amber: 'bg-amber/10 text-amber ',
    red: 'bg-critical/10 text-critical ',
    violet: 'bg-violet/10 text-violet ',
    neutral: 'bg-blue/5 text-atmos ',
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide ${tones[tone]} ${pulse ? 'alert-critical-pulse' : ''}`}
    >
      {children}
    </span>
  );
}
