'use client';

import { Skeleton } from '@/components/ui/skeleton';
import type { ReactNode } from 'react';

export function TileSkeleton({ className }: { className?: string }) {
  return <Skeleton className={`glass rounded-xl ${className ?? 'h-24 w-full'}`} />;
}

export function ErrorState({ title, message, onRetry }: { title: string; message: string; onRetry?: () => void }) {
  return (
    <div className="glass rounded-xl p-6 text-center">
      <h3 className="font-display font-semibold text-critical">{title}</h3>
      <p className="mt-2 text-sm text-atmos">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 rounded-xl bg-cyan/10 px-4 py-2 text-sm text-cyan transition hover:bg-cyan/20"
        >
          Tentar novamente
        </button>
      )}
    </div>
  );
}

export function EmptyState({ title, message, icon }: { title: string; message: string; icon?: ReactNode }) {
  return (
    <div className="glass rounded-xl p-6 text-center">
      {icon && <div className="mb-3 flex justify-center text-atmos">{icon}</div>}
      <h3 className="font-display font-semibold">{title}</h3>
      <p className="mt-1.5 text-sm text-atmos">{message}</p>
    </div>
  );
}
