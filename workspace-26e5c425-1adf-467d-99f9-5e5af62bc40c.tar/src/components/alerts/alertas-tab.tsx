'use client';

/**
 * Separador Alertas — página dedicada aos avisos meteorológicos:
 *  · alertas inteligentes + avisos IPMA da localização atual;
 *  · todos os avisos oficiais do IPMA para o país inteiro (cores oficiais);
 *  · atividade em tempo real via SSE do alerts-service (porta 3003);
 *  · atalho para ativar notificações push nas Definições.
 */
import { BellRing, RadioTower, ShieldAlert, ShieldCheck, Waves } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useAppStore } from '@/store/app-store';
import type { IpmaWarning, WeatherAlert } from '@/lib/types';
import type { StreamFeedItem, StreamStatus } from '@/hooks/use-alerts-stream';
import { AlertCard } from '@/components/dashboard/alerts-banner';
import { formatRelative, formatTime } from '@/lib/format';

const LEVEL_STYLES: Record<IpmaWarning['level'], { badge: string; dot: string; label: string }> = {
  red: { badge: 'bg-critical/15 text-critical ', dot: 'bg-critical', label: 'Vermelho' },
  orange: { badge: 'bg-amber/15 text-amber ', dot: 'bg-amber', label: 'Laranja' },
  yellow: { badge: 'bg-amber/10 text-amber/90 ', dot: 'bg-amber/80', label: 'Amarelo' },
};

function IcpmaWarningRow({ warning, index }: { warning: IpmaWarning; index: number }) {
  const style = LEVEL_STYLES[warning.level];
  return (
    <motion.li
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.03, 0.3) }}
      className="rounded-xl bg-blue/4 px-3.5 py-3"
    >
      <div className="flex flex-wrap items-center gap-2">
        <span className={`inline-flex items-center gap-1.5 rounded-xl px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-[0.12em] ${style.badge}`}>
          <span className={`size-1.5 rounded-xl ${style.dot}`} />
          {style.label}
        </span>
        <span className="text-sm font-semibold">{warning.phenomenLabel}</span>
        <span className="text-xs text-atmos">· área {warning.area}</span>
      </div>
      {warning.description.length > 0 && (
        <p className="mt-1.5 text-xs leading-relaxed text-foreground/80">{warning.description}</p>
      )}
      <p className="mt-1.5 text-[11px] text-atmos">
        Início: {formatTime(warning.start)} · Fim: {formatTime(warning.end)}
      </p>
    </motion.li>
  );
}

function LiveBadge({ status }: { status: StreamStatus }) {
  if (status === 'live') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-xl bg-cyan/10 px-3 py-1 text-[11px] font-medium text-cyan">
        <span className="relative flex size-2">
          <span className="absolute inline-flex size-full animate-ping rounded-xl bg-cyan opacity-60" />
          <span className="relative inline-flex size-2 rounded-xl bg-cyan" />
        </span>
        Em tempo real
      </span>
    );
  }
  if (status === 'connecting') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-xl bg-blue/5 px-3 py-1 text-[11px] text-atmos">
        <span className="size-2 rounded-xl bg-atmos" />
        A ligar ao serviço…
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-xl bg-amber/10 px-3 py-1 text-[11px] text-amber">
      <span className="size-2 rounded-xl bg-amber" />
      Serviço em tempo real indisponível
    </span>
  );
}

function formatClock(ms: number): string {
  return new Intl.DateTimeFormat('pt-PT', { hour: '2-digit', minute: '2-digit' }).format(ms);
}

export function AlertasTab({
  alerts,
  ipmaWarnings,
  streamStatus,
  streamFeed,
  locationName,
  nowMs,
}: {
  alerts: WeatherAlert[];
  ipmaWarnings: IpmaWarning[];
  streamStatus: StreamStatus;
  streamFeed: StreamFeedItem[];
  locationName: string;
  nowMs: number;
}) {
  const { setActiveTab } = useAppStore();
  const totalActive = alerts.length + ipmaWarnings.length;

  return (
    <div className="flex flex-col gap-4 animate-fade-up">
      {/* Cabeçalho */}
      <section className="glass rounded-xl p-4" aria-label="Estado dos alertas">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-amber/10">
              <ShieldAlert className="size-5 text-amber" />
            </span>
            <div className="min-w-0">
              <h1 className="font-display text-lg font-bold tracking-tight leading-tight">Alertas</h1>
              <p className="text-xs text-atmos mt-0.5">
                {totalActive === 0
                  ? 'Nenhum aviso ativo neste momento'
                  : `${totalActive} aviso${totalActive === 1 ? '' : 's'} ativo${totalActive === 1 ? '' : 's'} em Portugal`}
              </p>
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <LiveBadge status={streamStatus} />
          </div>
        </div>
        <p className="mt-3 text-[11px] leading-relaxed text-atmos">
          Avisos oficiais do IPMA (cores oficiais preservadas) + alertas inteligentes STORMWATCH gerados para{' '}
          <span className="text-foreground/85">{locationName}</span>. O serviço de alertas polla o IPMA a cada 5 minutos
          e difunde avisos novos de imediato.
        </p>
      </section>

      {/* Alertas da localização atual */}
      <section aria-label={`Alertas para ${locationName}`}>
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-2 px-1">
          <ShieldAlert className="size-4 text-cyan" /> Alertas para {locationName}
        </h2>
        {alerts.length === 0 ? (
          <div className="rounded-xl bg-signal/8 px-4 py-4 flex items-start gap-3">
            <ShieldCheck className="size-5 text-signal shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-signal">Sem alertas para esta localização</p>
              <p className="mt-1 text-xs text-foreground/75 leading-relaxed">
                Nenhum aviso oficial do IPMA nem alerta interno (chuva iminente, trovoada, rajadas ≥ 60 km/h, calor
                extremo, frio extremo, qualidade do ar) para {locationName} agora.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            <AnimatePresence initial={false}>
              {alerts.map((alert, i) => (
                <AlertCard key={alert.id} alert={alert} index={i} />
              ))}
            </AnimatePresence>
          </div>
        )}
      </section>

      {/* Avisos oficiais — todo o país */}
      <section className="glass rounded-xl p-4" aria-label="Avisos oficiais do IPMA">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-3 px-1">
          <Waves className="size-4 text-amber" /> Avisos oficiais do IPMA — todo o país
        </h2>
        {ipmaWarnings.length === 0 ? (
          <p className="px-1 text-xs text-atmos">O IPMA não tem avisos publicados para Portugal neste momento.</p>
        ) : (
          <ul className="flex flex-col gap-2 px-1">
            {ipmaWarnings.map((w, i) => (
              <IcpmaWarningRow key={w.id} warning={w} index={i} />
            ))}
          </ul>
        )}
      </section>

      {/* Atividade em tempo real */}
      <section className="glass rounded-xl p-4" aria-label="Atividade em tempo real">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-3 px-1">
          <RadioTower className="size-4 text-cyan" /> Atividade em tempo real
        </h2>
        {streamFeed.length === 0 ? (
          <p className="px-1 text-xs text-atmos leading-relaxed">
            À escuta do serviço de alertas (porta 3003). Quando o IPMA publicar um aviso novo, ele aparece aqui de
            imediato — sem esperar pela próxima atualização.
          </p>
        ) : (
          <ul className="flex flex-col gap-1.5 px-1">
            {streamFeed.map((item) => {
              const style = LEVEL_STYLES[item.level];
              return (
                <li key={`${item.id}-${item.receivedAt}`} className="flex items-start gap-2.5 rounded-xl bg-blue/4 px-3 py-2.5">
                  <span className={`mt-1.5 size-2 shrink-0 rounded-xl ${style.dot}`} aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium">
                      <span className={item.level === 'red' ? 'text-critical' : 'text-amber'}>
                        {style.label}
                      </span>{' '}
                      · {item.phenomenLabel} — área {item.area}
                    </p>
                    <p className="text-[11px] text-atmos mt-0.5">
                      Recebido {formatRelative(item.receivedAt, nowMs)} às {formatClock(item.receivedAt)}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {/* Atalho para notificações */}
      <section className="rounded-xl bg-cyan/6 p-4" aria-label="Ativar notificações">
        <div className="flex flex-wrap items-center gap-3">
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-2 text-sm font-semibold text-cyan">
              <BellRing className="size-4" /> Receber estes avisos no telemóvel
            </p>
            <p className="mt-1 text-[11px] leading-relaxed text-foreground/75">
              Ativa as notificações push nas Definições — o dispositivo fica subscrito no serviço de alertas e recebe
              cada aviso novo do IPMA, mesmo com a app fechada.
            </p>
          </div>
          <button
            onClick={() => setActiveTab('perfil')}
            className="flex min-h-[44px] items-center gap-2 rounded-xl bg-cyan/15 px-4 text-xs font-medium text-cyan transition hover:bg-cyan/25"
          >
            <BellRing className="size-4" /> Ativar notificações
          </button>
        </div>
      </section>
    </div>
  );
}
