'use client';

import 'leaflet/dist/leaflet.css';
import type * as L from 'leaflet';
import { useEffect, useRef, useState } from 'react';
import { useTheme } from 'next-themes';
import type { ActivityReport, GridPoint, RadarFrame } from '@/lib/types';

export const REPORT_COLORS: Record<ActivityReport['type'], string> = {
  'rain-heavy': '#3498DB',
  flood: '#1E3A5F',
  hail: '#F4C542',
  fog: '#7A93AD',
  'extreme-wind': '#FF8C42',
  thunderstorm: '#E63946',
};

export const REPORT_LABELS: Record<ActivityReport['type'], string> = {
  'rain-heavy': 'Chuva intensa',
  flood: 'Inundação',
  hail: 'Granizo',
  fog: 'Nevoeiro',
  'extreme-wind': 'Vento extremo',
  thunderstorm: 'Trovoada',
};

/** Camada visível do mapa. */
export type MapLayer = 'precip' | 'temp' | 'wind' | 'clouds';

/** Mapa base selecionável no canto do mapa. */
export type BaseMapKind = 'claro' | 'escuro' | 'satelite';

const BASEMAP_TILES: Record<BaseMapKind, { base: string; reference: string }> = {
  claro: {
    base: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    reference:
      'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Reference/MapServer/tile/{z}/{y}/{x}',
  },
  escuro: {
    base: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}',
    reference:
      'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}',
  },
  satelite: {
    base: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    reference:
      'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
  },
};

const BASEMAP_OPTIONS: Array<{ kind: BaseMapKind; label: string }> = [
  { kind: 'claro', label: 'Claro' },
  { kind: 'escuro', label: 'Escuro' },
  { kind: 'satelite', label: 'Satélite' },
];

export const TEMP_SCALE: Array<{ max: number; color: string; label: string }> = [
  { max: 0, color: '#1E3A5F', label: '≤ 0°C' },
  { max: 8, color: '#3498DB', label: '0–8°C' },
  { max: 15, color: '#27AE60', label: '8–15°C' },
  { max: 22, color: '#F4C542', label: '15–22°C' },
  { max: 28, color: '#FF8C42', label: '22–28°C' },
  { max: 33, color: '#E63946', label: '28–33°C' },
  { max: Infinity, color: '#B01E30', label: '≥ 33°C' },
];

export const WIND_SCALE: Array<{ max: number; color: string; label: string }> = [
  { max: 15, color: '#27AE60', label: '< 15 km/h' },
  { max: 30, color: '#3498DB', label: '15–30 km/h' },
  { max: 50, color: '#F4C542', label: '30–50 km/h' },
  { max: 70, color: '#FF8C42', label: '50–70 km/h' },
  { max: Infinity, color: '#E63946', label: '≥ 70 km/h' },
];

export const CLOUD_SCALE: Array<{ max: number; color: string; opacity: number; label: string }> = [
  { max: 15, color: '#33566F', opacity: 0.3, label: 'Céu limpo' },
  { max: 45, color: '#5E86AC', opacity: 0.42, label: 'Poucas nuvens' },
  { max: 75, color: '#93B4D4', opacity: 0.55, label: 'Parcialmente nublado' },
  { max: 95, color: '#C4D7EA', opacity: 0.66, label: 'Muito nublado' },
  { max: Infinity, color: '#F0F6FC', opacity: 0.78, label: 'Encoberto' },
];

function tempColor(t: number): string {
  return TEMP_SCALE.find((s) => t <= s.max)?.color ?? TEMP_SCALE[TEMP_SCALE.length - 1].color;
}

function windColor(kmh: number): string {
  return WIND_SCALE.find((s) => kmh < s.max)?.color ?? WIND_SCALE[WIND_SCALE.length - 1].color;
}

function cloudStyle(cover: number): { color: string; opacity: number } {
  const s = CLOUD_SCALE.find((c) => cover < c.max) ?? CLOUD_SCALE[CLOUD_SCALE.length - 1];
  return { color: s.color, opacity: s.opacity };
}

/** Seta de vento (aponta para onde o vento sopra; a direção meteo é «de onde»). */
function windArrowIcon(L: typeof import('leaflet'), point: GridPoint): L.DivIcon {
  const rotation = ((point.windDirection ?? 0) + 180) % 360;
  const color = windColor(point.windSpeed);
  const strong = point.windSpeed >= 50;
  return L.divIcon({
    className: 'wind-arrow-icon',
    html: `<div style="transform: rotate(${rotation}deg); width:26px; height:26px; display:flex; align-items:center; justify-content:center;">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 2 L18 14 L12 11 L6 14 Z" fill="${color}" stroke="rgba(30,58,95,0.90)" stroke-width="1.1" ${strong ? 'stroke-width="1.6"' : ''}/>
      </svg>
    </div>`,
    iconSize: [26, 26],
    iconAnchor: [13, 13],
  });
}

interface RadarMapProps {
  center: [number, number];
  frames: RadarFrame[];
  host: string;
  frameIndex: number;
  reports: ActivityReport[];
  mode: 'radar' | 'reports';
  layer: MapLayer;
  gridPoints: GridPoint[];
  showRadarLayer: boolean;
  pickMode: boolean;
  pendingPosition: [number, number] | null;
  onMapClick: (lat: number, lon: number) => void;
  onSelectReport: (report: ActivityReport) => void;
}

/** Mapa Leaflet: radar RainViewer animado, camadas de variáveis e reportes. */
export function RadarMap({
  center,
  frames,
  host,
  frameIndex,
  reports,
  mode,
  layer,
  gridPoints,
  showRadarLayer,
  pickMode,
  pendingPosition,
  onMapClick,
  onSelectReport,
}: RadarMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const radarLayerRef = useRef<L.TileLayer | null>(null);
  const baseLayerRef = useRef<L.TileLayer | null>(null);
  const referenceLayerRef = useRef<L.TileLayer | null>(null);
  const gridLayerRef = useRef<L.LayerGroup | null>(null);
  const markersRef = useRef<L.LayerGroup | null>(null);
  const pendingRef = useRef<L.CircleMarker | null>(null);
  const clickCbRef = useRef(onMapClick);
  const selectCbRef = useRef(onSelectReport);
  const { resolvedTheme } = useTheme();
  const [basemap, setBasemap] = useState<BaseMapKind>(resolvedTheme === 'dark' ? 'escuro' : 'claro');
  const basemapRef = useRef(basemap);
  const userPickedBasemapRef = useRef(false);

  basemapRef.current = basemap;
  clickCbRef.current = onMapClick;
  selectCbRef.current = onSelectReport;

  // Inicialização (uma vez).
  useEffect(() => {
    let cancelled = false;
    let map: L.Map | null = null;

    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !containerRef.current || mapRef.current) return;
      const L = leaflet.default ?? leaflet;

      map = L.map(containerRef.current, {
        center,
        zoom: 7,
        zoomControl: false,
        attributionControl: true,
        preferCanvas: true,
      });

      // Basemap Esri (Gray Canvas / World Imagery) — sem chave de API e sem
      // marca de água; predefinição segue o tema da aplicação.
      const tiles = BASEMAP_TILES[basemapRef.current];
      baseLayerRef.current = L.tileLayer(tiles.base, {
        attribution: 'Esri, HERE, Garmin, &copy; OpenStreetMap · Radar: RainViewer · Grelha: Open-Meteo',
        maxZoom: 16,
      }).addTo(map);

      // Camada de legendas/topónimos do mesmo estilo Esri (transparência).
      referenceLayerRef.current = L.tileLayer(tiles.reference, {
        maxZoom: 16,
      }).addTo(map);

      L.circleMarker(center, {
        radius: 6,
        color: '#2472B2',
        weight: 2,
        fillColor: '#3498DB',
        fillOpacity: 0.85,
      })
        .bindTooltip('Localização selecionada', { direction: 'top' })
        .addTo(map);

      gridLayerRef.current = L.layerGroup().addTo(map);
      markersRef.current = L.layerGroup().addTo(map);
      map.on('click', (e: L.LeafletMouseEvent) => clickCbRef.current(e.latlng.lat, e.latlng.lng));
      mapRef.current = map;
    })();

    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      radarLayerRef.current = null;
      baseLayerRef.current = null;
      referenceLayerRef.current = null;
      gridLayerRef.current = null;
      markersRef.current = null;
    };
  }, []);

  // Segue o tema da aplicação enquanto o utilizador não escolher um mapa base.
  useEffect(() => {
    if (!userPickedBasemapRef.current) {
      setBasemap(resolvedTheme === 'dark' ? 'escuro' : 'claro');
    }
  }, [resolvedTheme]);

  // Troca o basemap quando a seleção muda.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !mapRef.current) return;
      const L = leaflet.default ?? leaflet;
      const tiles = BASEMAP_TILES[basemap];
      baseLayerRef.current?.remove();
      referenceLayerRef.current?.remove();
      baseLayerRef.current = L.tileLayer(tiles.base, {
        attribution: 'Esri, HERE, Garmin, &copy; OpenStreetMap · Radar: RainViewer · Grelha: Open-Meteo',
        maxZoom: 16,
      }).addTo(mapRef.current);
      referenceLayerRef.current = L.tileLayer(tiles.reference, {
        maxZoom: 16,
      }).addTo(mapRef.current);
    })();
    return () => {
      cancelled = true;
    };
  }, [basemap]);

  // Camada radar conforme o fotograma ativo.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || frames.length === 0 || !showRadarLayer) {
      radarLayerRef.current?.remove();
      radarLayerRef.current = null;
      return;
    }
    let cancelled = false;
    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !mapRef.current) return;
      const L = leaflet.default ?? leaflet;
      const frame = frames[Math.min(frameIndex, frames.length - 1)];
      radarLayerRef.current?.remove();
      const layerInst = L.tileLayer(`${host}${frame.path}`, {
        opacity: 0.75,
        zIndex: 400,
        tileSize: 256,
      });
      layerInst.addTo(mapRef.current);
      radarLayerRef.current = layerInst;
    })();
    return () => {
      cancelled = true;
    };
  }, [frames, host, frameIndex, showRadarLayer]);

  // Camada de variáveis (temperatura / vento / nuvens) sobre a grelha.
  useEffect(() => {
    if (!mapRef.current || !gridLayerRef.current) return;
    const group = gridLayerRef.current;
    group.clearLayers();
    if (layer === 'precip' || gridPoints.length === 0) return;

    let cancelled = false;
    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !mapRef.current) return;
      const L = leaflet.default ?? leaflet;

      for (const p of gridPoints) {
        if (layer === 'temp') {
          const color = tempColor(p.temperature);
          const marker = L.circleMarker([p.latitude, p.longitude], {
            radius: 26,
            stroke: true,
            color,
            weight: 1.5,
            opacity: 0.9,
            fillColor: color,
            fillOpacity: 0.42,
          });
          marker.bindTooltip(
            `<b>${p.name}</b><br>${p.temperature.toFixed(1)}°C · ${p.weatherLabel}<br>Máx. hoje na grelha: ver legenda`,
            { direction: 'top' },
          );
          group.addLayer(marker);
          const label = L.marker([p.latitude, p.longitude], {
            icon: L.divIcon({
              className: 'grid-label-icon',
              html: `<span style="font: 700 11px/1 ui-sans-serif,system-ui; color:#FFFFFF; text-shadow:0 1px 3px rgba(30,58,95,0.95); white-space:nowrap;">${Math.round(p.temperature)}°</span>`,
              iconSize: [30, 14],
              iconAnchor: [15, 7],
            }),
            interactive: false,
            keyboard: false,
          });
          group.addLayer(label);
        } else if (layer === 'wind') {
          const color = windColor(p.windSpeed);
          const halo = L.circleMarker([p.latitude, p.longitude], {
            radius: 18,
            stroke: false,
            fillColor: color,
            fillOpacity: 0.3,
            interactive: false,
          });
          group.addLayer(halo);
          const arrow = L.marker([p.latitude, p.longitude], {
            icon: windArrowIcon(L, p),
          });
          arrow.bindTooltip(
            `<b>${p.name}</b><br>Vento ${Math.round(p.windSpeed)} km/h ${['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'][Math.round((((p.windDirection ?? 0) % 360) + 360) % 360 / 45) % 8]}<br>Rajadas ${Math.round(p.windGusts)} km/h`,
            { direction: 'top' },
          );
          group.addLayer(arrow);
        } else {
          const cover = p.cloudCover ?? 0;
          const style = cloudStyle(cover);
          const marker = L.circleMarker([p.latitude, p.longitude], {
            radius: 22,
            stroke: true,
            color: style.color,
            weight: 1,
            opacity: 0.8,
            fillColor: style.color,
            fillOpacity: style.opacity,
          });
          marker.bindTooltip(`<b>${p.name}</b><br>Nebulosidade ${Math.round(cover)}%<br>${p.weatherLabel}`, {
            direction: 'top',
          });
          group.addLayer(marker);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [layer, gridPoints]);

  // Marcadores de reportes.
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !mapRef.current || !markersRef.current) return;
      const L = leaflet.default ?? leaflet;
      const group = markersRef.current;
      group.clearLayers();
      for (const r of reports) {
        const color = REPORT_COLORS[r.type] ?? '#2472B2';
        const marker = L.circleMarker([r.lat, r.lon], {
          radius: 7 + Math.min(6, r.confirmations),
          color,
          weight: 2,
          fillColor: color,
          fillOpacity: 0.55,
        });
        marker.on('click', () => selectCbRef.current(r));
        marker.bindTooltip(`${REPORT_LABELS[r.type]} · ${r.confirmations} confirmações`, { direction: 'top' });
        group.addLayer(marker);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [reports]);

  // Marcador pendente (posição escolhida para novo reporte).
  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const leaflet = await import('leaflet');
      if (cancelled || !mapRef.current) return;
      const L = leaflet.default ?? leaflet;
      pendingRef.current?.remove();
      pendingRef.current = null;
      if (pendingPosition) {
        const marker = L.circleMarker(pendingPosition, {
          radius: 9,
          color: '#F4C542',
          weight: 2.5,
          dashArray: '4 3',
          fillColor: '#F4C542',
          fillOpacity: 0.25,
        });
        marker.addTo(mapRef.current);
        pendingRef.current = marker;
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [pendingPosition]);

  // Cursor em modo de escolha.
  useEffect(() => {
    const el = containerRef.current;
    if (el) el.style.cursor = pickMode ? 'crosshair' : '';
  }, [pickMode]);

  return (
    <div className="relative z-0">
      <div
        ref={containerRef}
        className="h-[380px] w-full overflow-hidden rounded-xl "
        role="application"
        aria-label={mode === 'radar' ? 'Mapa meteorológico' : 'Mapa de reportes colaborativos'}
      />
      {/* Trocador de mapa base — canto superior direito, cantos retos */}
      <div
        className="absolute right-2 top-2 z-[1000] flex flex-col gap-1"
        role="group"
        aria-label="Tipo de mapa base"
      >
        {BASEMAP_OPTIONS.map((option) => {
          const active = basemap === option.kind;
          return (
            <button
              key={option.kind}
              type="button"
              onClick={() => {
                userPickedBasemapRef.current = true;
                setBasemap(option.kind);
              }}
              aria-pressed={active}
              className={`rounded-xl px-2.5 py-1.5 text-[11px] font-semibold tracking-wide backdrop-blur-md transition-colors ${
                active
                  ? 'border-primary bg-primary text-primary-foreground'
                  : ' bg-white/85 text-foreground '
 }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
