'use client';

import { useState } from 'react';
import { CloudLightning, CloudRain, CloudFog, Wind, Waves, CloudHail, X } from 'lucide-react';
import { toast } from 'sonner';
import type { ReportType } from '@/lib/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useCreateReport } from '@/hooks/use-weather';
import { useAppStore } from '@/store/app-store';
import { distanceKm, formatNumber } from '@/lib/format';
import { QUICK_LOCATIONS } from '@/lib/locations';

const REPORT_OPTIONS: Array<{ type: ReportType; label: string; icon: typeof CloudRain; color: string; description: string }> = [
  { type: 'rain-heavy', label: 'Chuva intensa', icon: CloudRain, color: 'text-cyan', description: 'Chuva forte e persistente nesta zona' },
  { type: 'flood', label: 'Inundação', icon: Waves, color: 'text-blue', description: 'Água acumulada ou a transbordar' },
  { type: 'hail', label: 'Granizo', icon: CloudHail, color: 'text-violet', description: 'Queda de granizo observada' },
  { type: 'fog', label: 'Nevoeiro', icon: CloudFog, color: 'text-atmos', description: 'Visibilidade reduzida por névoa' },
  { type: 'extreme-wind', label: 'Vento extremo', icon: Wind, color: 'text-amber', description: 'Rajadas fortes ou objetos ao vento' },
  { type: 'thunderstorm', label: 'Trovoada', icon: CloudLightning, color: 'text-critical', description: 'Trovões e relâmpagos ativos' },
];

interface ReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  position: [number, number] | null;
}

export function ReportDialog({ open, onOpenChange, position }: ReportDialogProps) {
  const [type, setType] = useState<ReportType | null>(null);
  const [note, setNote] = useState('');
  const create = useCreateReport();
  const { location } = useAppStore();

  // Os estados internos são reiniciados automaticamente: o Radix Dialog
  // desmonta o conteúdo quando fechado.

  const nearestPlace = position
    ? QUICK_LOCATIONS.map((q) => ({ name: q.name, km: distanceKm(position[0], position[1], q.latitude, q.longitude) }))
        .sort((a, b) => a.km - b.km)
        .find((p) => p.km <= 30)?.name ?? null
    : null;

  const submit = () => {
    if (!type || !position) return;
    create.mutate(
      {
        type,
        note: note.trim().length > 0 ? note.trim().slice(0, 240) : null,
        lat: position[0],
        lon: position[1],
        placeName: nearestPlace,
      },
      {
        onSuccess: () => {
          toast.success('Reporte publicado — visível para todos durante 2 horas.');
          onOpenChange(false);
        },
        onError: (err) => {
          const msg = err instanceof Error ? err.message : 'Erro desconhecido';
          toast.error(`Não foi possível publicar: ${msg}`);
        },
      },
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-strong rounded-xl max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Reportar fenómeno</DialogTitle>
          <DialogDescription className="text-atmos">
            {position
              ? `Posição: ${formatNumber(position[0], 4)}°, ${formatNumber(position[1], 4)}°${nearestPlace ? ` · perto de ${nearestPlace}` : ''}`
              : 'Escolhe o local no mapa.'}
            {' '}Os reportes expiram automaticamente em 2 horas.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-2">
          {REPORT_OPTIONS.map((opt) => {
            const Icon = opt.icon;
            const active = type === opt.type;
            return (
              <button
                key={opt.type}
                onClick={() => setType(opt.type)}
                aria-pressed={active}
                className={`flex flex-col items-start gap-1 rounded-xl px-3 py-2.5 text-left transition min-h-[64px] ${
                  active ? ' bg-cyan/10' : ' bg-blue/4 '
 }`}
              >
                <span className="flex items-center gap-1.5 text-xs font-semibold">
                  <Icon className={`size-4 ${opt.color}`} /> {opt.label}
                </span>
                <span className="text-[10px] leading-snug text-atmos">{opt.description}</span>
              </button>
            );
          })}
        </div>

        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Nota opcional (máx. 240 caracteres)…"
          aria-label="Nota do reporte"
          maxLength={240}
          rows={2}
          className="w-full rounded-xl bg-blue/5 px-3.5 py-2.5 text-sm outline-none transition  placeholder:text-atmos/70 resize-none"
        />

        <div className="flex items-center justify-between gap-3">
          <p className="text-[11px] text-atmos">Limite: 1 reporte por 10 min (por dispositivo).</p>
          <div className="flex gap-2">
            <button
              onClick={() => onOpenChange(false)}
              className="flex min-h-[40px] items-center gap-1.5 rounded-xl bg-blue/5 px-4 text-sm text-atmos transition hover:text-foreground"
            >
              <X className="size-4" /> Cancelar
            </button>
            <button
              onClick={submit}
              disabled={!type || create.isPending}
              className="flex min-h-[40px] items-center rounded-xl bg-cyan/15 px-4 text-sm font-medium text-cyan transition hover:bg-cyan/25 disabled:opacity-40"
            >
              {create.isPending ? 'A publicar…' : 'Publicar reporte'}
            </button>
          </div>
        </div>
        <p className="text-[10px] text-atmos/80">
          Localização detetada a partir da tua seleção no mapa. Reportes abusivos podem ser limitados automaticamente.
        </p>
        <span className="sr-only">Localização atual: {location.name}</span>
      </DialogContent>
    </Dialog>
  );
}
