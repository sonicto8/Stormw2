'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  MapPin,
  Pause,
  Play,
  Radar as RadarIcon,
  Users,
  ClipboardList,
  LocateFixed,
  X,
  Thermometer,
  Wind,
  Cloud,
} from 'lucide-react';
import { toast } from 'sonner';
import type { ActivityReport } from '@/lib/types';
import { useAppStore } from '@/store/app-store';
import { useConfirmReport, useGrid, useRadar, useReports } from '@/hooks/use-weather';
import {
  RadarMap,
  REPORT_COLORS,
  REPORT_LABELS,
  TEMP_SCALE,
  WIND_SCALE,
  CLOUD_SCALE,
  type MapLayer,
} from '@/components/radar/radar-map';
import { ReportDialog } from '@/components/radar/report-dialog';
import { filterActiveReports } from '@/lib/engines/report-expiry';
import { ErrorState, EmptyState, TileSkeleton } from '@/components/shared/states';
import { formatClockTime, formatDistance, formatRelative, distanceKm } from '@/lib/format';

const REPORT_TYPES = Object.keys(REPORT_LABELS) as Array<keyof typeof REPORT_LABELS>;

type ViewMode = MapLayer | 'reports';

const MODE_OPTIONS: Array<{ key: ViewMode; label: string; icon: typeof RadarIcon }> = [
  { key: 'precip', label: 'Precipitação', icon: RadarIcon },
  { key: 'temp', label: 'Temperatura', icon: Thermometer },
  { key: 'wind', label: 'Vento', icon: Wind },
  { key: 'clouds', label: 'Nuvens', icon: Cloud },
  { key: 'reports', label: 'Reportes', icon: Users },
];

const GRID_LEGENDS: Record<Exclude<MapLayer, 'precip'>, Array<{ color: string; label: string }>> = {
  temp: TEMP_SCALE.map((s) => ({ color: s.color, label: s.label })),
  wind: WIND_SCALE.map((s) => ({ color: s.color, label: s.label })),
  clouds: CLOUD_SCALE.map((s) => ({ color: s.color, label: s.label })),
};

export function RadarTab() {
  const { location } = useAppStore();
  const radar = useRadar();
  const grid = useGrid();
  const reports = useReports();
  const confirmReport = useConfirmReport();

  const [mode, setMode] = useState<ViewMode>('precip');
  const [frameIndex, setFrameIndex] = useState<number>(0);
  const [playing, setPlaying] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [pickMode, setPickMode] = useState(false);
  const [pendingPosition, setPendingPosition] = useState<[number, number] | null>(null);
  const [selectedReport, setSelectedReport] = useState<ActivityReport | null>(null);
  const playRef = useRef<number | null>(null);

  const frames = radar.data?.radar.frames ?? [];
  const host = radar.data?.radar.host ?? 'https://tilecache.rainviewer.com';
  const activeReports = reports.data?.reports ?? [];
  const gridPoints = grid.data?.points ?? [];

  // Índice inicial: fotograma mais recente (nowcast no fim).
  useEffect(() => {
    if (frames.length > 0 && frameIndex === 0) setFrameIndex(frames.length - 1);
  }, [frames.length, frameIndex]);

  // Animação de reprodução (apenas no modo precipitação).
  useEffect(() => {
    if (!playing || frames.length === 0 || mode !== 'precip') return;
    playRef.current = window.setInterval(() => {
      setFrameIndex((i) => (i + 1) % frames.length);
    }, 700);
    return () => {
      if (playRef.current !== null) window.clearInterval(playRef.current);
    };
  }, [playing, frames.length, mode]);

  const currentFrame = frames[frameIndex] ?? null;
  const frameTimeLabel = currentFrame
    ? `${formatClockTime(currentFrame.time * 1000)}${currentFrame.kind === 'nowcast' ? ' · previsão' : ''}`
    : '—';

  const jump = useCallback(
    (delta: number) => {
      if (frames.length === 0) return;
      setPlaying(false);
      setFrameIndex((i) => Math.min(frames.length - 1, Math.max(0, i + delta)));
    },
    [frames.length],
  );

  const onMapClick = useCallback(
    (lat: number, lon: number) => {
      if (mode !== 'reports' || !pickMode) return;
      setPendingPosition([lat, lon]);
      setDialogOpen(true);
    },
    [mode, pickMode],
  );

  const closeDialog = (open: boolean) => {
    setDialogOpen(open);
    if (!open) {
      setPendingPosition(null);
      setPickMode(false);
    }
  };

  const confirm = (id: string) => {
    confirmReport.mutate(id, {
      onSuccess: () => toast.success('Confirmação registada. Obrigado!'),
      onError: (err) => toast.error(err instanceof Error ? err.message : 'Erro ao confirmar'),
    });
  };

  const reportList = useMemo(() => {
    const now = Date.now();
    return filterActiveReports(activeReports, now).map((r) => ({
      ...r,
      km: distanceKm(location.latitude, location.longitude, r.lat, r.lon),
    }));
  }, [activeReports, location.latitude, location.longitude]);

  const radarUnavailable = mode === 'precip' && !radar.isLoading && frames.length === 0;
  const gridUnavailable = mode !== 'precip' && mode !== 'reports' && !grid.isLoading && gridPoints.length === 0;
  const mapLoading =
    (mode === 'precip' && radar.isLoading) ||
    (mode === 'reports' && reports.isLoading) ||
    (mode !== 'precip' && mode !== 'reports' && grid.isLoading && gridPoints.length === 0);

  return (
    <div className="flex flex-col gap-4 animate-fade-up">
      {/* Alternância de camadas */}
      <div className="glass-strong rounded-xl p-1.5 grid grid-cols-3 sm:grid-cols-5 gap-1.5" role="group" aria-label="Camada do mapa">
        {MODE_OPTIONS.map((opt) => {
          const Icon = opt.icon;
          const active = mode === opt.key;
          return (
            <button
              key={opt.key}
              onClick={() => setMode(opt.key)}
              aria-pressed={active}
              className={`flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl px-2 text-[11px] sm:text-xs font-medium transition ${
                active ? 'bg-cyan/15 text-cyan ' : 'text-atmos hover:text-foreground '
 }`}
            >
              <Icon className="size-4 shrink-0" />
              <span className="truncate">{opt.label}</span>
            </button>
          );
        })}
      </div>

      <div className="relative">
        {mapLoading ? (
          <TileSkeleton className="h-[380px] w-full" />
        ) : (
          <RadarMap
            center={[location.latitude, location.longitude]}
            frames={frames}
            host={host}
            frameIndex={frameIndex}
            reports={mode === 'reports' ? reportList : []}
            mode={mode === 'reports' ? 'reports' : 'radar'}
            layer={mode === 'reports' ? 'precip' : mode}
            gridPoints={mode !== 'reports' ? gridPoints : []}
            showRadarLayer={mode === 'precip'}
            pickMode={pickMode}
            pendingPosition={pendingPosition}
            onMapClick={onMapClick}
            onSelectReport={(r) => setSelectedReport(r)}
          />
        )}

        {/* Legenda do radar de precipitação */}
        {mode === 'precip' && !radarUnavailable && (
          <div className="glass-strong absolute bottom-3 left-3 rounded-xl px-3 py-2 z-[500]">
            <p className="text-[9px] uppercase tracking-[0.16em] text-atmos mb-1">Intensidade</p>
            <div className="flex items-center gap-1">
              {[
                { label: 'Fraca', color: '#7CDFF9' },
                { label: 'Moderada', color: '#3AA8F0' },
                { label: 'Forte', color: '#2C7BDB' },
                { label: 'Muito forte', color: '#8D5BE0' },
                { label: 'Extrema', color: '#FF425F' },
              ].map((s) => (
                <span key={s.label} className="size-3.5 rounded-xl" style={{ background: s.color }} title={s.label} />
              ))}
            </div>
            <div className="flex justify-between text-[9px] text-atmos mt-0.5 w-[86px]">
              <span>fraca</span>
              <span>extrema</span>
            </div>
          </div>
        )}

        {/* Legenda das camadas de variáveis */}
        {(mode === 'temp' || mode === 'wind' || mode === 'clouds') && gridPoints.length > 0 && (
          <div className="glass-strong absolute bottom-3 left-3 rounded-xl px-3 py-2 z-[500] max-w-[210px]">
            <p className="text-[9px] uppercase tracking-[0.16em] text-atmos mb-1.5">
              {mode === 'temp' ? 'Temperatura' : mode === 'wind' ? 'Velocidade do vento' : 'Nebulosidade'}
            </p>
            <ul className="flex flex-col gap-1">
              {GRID_LEGENDS[mode].map((s) => (
                <li key={s.label} className="flex items-center gap-2 text-[10px] text-foreground/85">
                  <span className="size-3 shrink-0 rounded-xl" style={{ background: s.color }} />
                  {s.label}
                </li>
              ))}
            </ul>
            <p className="mt-1.5 text-[9px] text-atmos">
              Grelha: {gridPoints.length} pontos PT · {grid.data?.points[0] ? formatClockTime(grid.data.points[0].fetchedAt) : ''}
            </p>
          </div>
        )}

        {radarUnavailable && (
          <div className="glass-strong absolute top-3 left-3 right-3 rounded-xl px-4 py-2.5 z-[500] text-xs text-amber   bg-amber/10">
            Radar indisponível de momento — sem cobertura publicada pela fonte. O mapa continua disponível.
          </div>
        )}

        {gridUnavailable && (
          <div className="glass-strong absolute top-3 left-3 right-3 rounded-xl px-4 py-2.5 z-[500] text-xs text-amber   bg-amber/10">
            Grelha de pontos indisponível de momento — tenta atualizar. Os mapas de variáveis voltam quando a fonte responder.
          </div>
        )}
      </div>

      {/* Controlos do radar (apenas precipitação) */}
      {mode === 'precip' && frames.length > 0 && (
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setPlaying((p) => !p)}
              className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-cyan/15 text-cyan transition hover:bg-cyan/25"
              aria-label={playing ? 'Pausar animação do radar' : 'Reproduzir animação do radar'}
            >
              {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
            </button>
            <button
              onClick={() => jump(-12)}
              className="rounded-xl bg-blue/5 px-2.5 py-1.5 text-[11px] text-atmos transition hover:text-cyan"
              aria-label="Recuar 2 horas"
            >
              −2 h
            </button>
            <div className="flex-1 min-w-0">
              <input
                type="range"
                min={0}
                max={Math.max(0, frames.length - 1)}
                value={frameIndex}
                onChange={(e) => {
                  setPlaying(false);
                  setFrameIndex(Number(e.target.value));
                }}
                className="w-full accent-[#3498DB]"
                aria-label="Linha temporal do radar"
              />
              <div className="flex justify-between text-[10px] text-atmos mt-0.5">
                <span>{formatClockTime(frames[0].time * 1000)}</span>
                <span className="font-medium text-cyan">{frameTimeLabel}</span>
                <span>{formatClockTime(frames[frames.length - 1].time * 1000)}</span>
              </div>
            </div>
            <button
              onClick={() => jump(12)}
              className="rounded-xl bg-blue/5 px-2.5 py-1.5 text-[11px] text-atmos transition hover:text-cyan"
              aria-label="Avançar 2 horas"
            >
              +2 h
            </button>
          </div>
          <p className="mt-2 text-[10px] text-atmos px-1">
            Cobertura real da fonte: últimos 90 minutos e previsão a 30 minutos. {radar.data?.notice && <span className="text-amber">{radar.data.notice}</span>}
          </p>
        </div>
      )}

      {/* Nota das camadas de variáveis */}
      {(mode === 'temp' || mode === 'wind' || mode === 'clouds') && gridPoints.length > 0 && (
        <p className="text-[10px] text-atmos px-1">
          Mapas construídos sobre {gridPoints.length} pontos de referência (capitais de distrito e ilhas) com valores
          atuais reais da fonte. {grid.data?.notice && <span className="text-amber">{grid.data.notice}</span>}
        </p>
      )}

      {/* Painel de reportes */}
      {mode === 'reports' && (
        <div className="flex flex-col gap-3">
          <div className="glass rounded-xl p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 className="font-display text-sm font-semibold">Reportes colaborativos</h2>
                <p className="text-[11px] text-atmos mt-0.5">
                  Fenómenos reportados pela comunidade · expiram em 2 h
                </p>
              </div>
              <button
                onClick={() => setPickMode((p) => !p)}
                aria-pressed={pickMode}
                className={`flex min-h-[44px] shrink-0 items-center gap-2 rounded-xl px-4 text-sm font-medium transition ${
                  pickMode ? ' bg-amber/15 text-amber' : ' bg-cyan/15 text-cyan hover:bg-cyan/25'
 }`}
              >
                {pickMode ? <X className="size-4" /> : <LocateFixed className="size-4" />}
                {pickMode ? 'Cancelar' : 'Novo reporte'}
              </button>
            </div>
            {pickMode && (
              <p className="mt-2.5 rounded-xl border-l-[3px] border-l-amber bg-amber/8 px-3 py-2 text-xs text-amber">
                Toca no mapa para marcar o local exato do fenómeno.
              </p>
            )}
          </div>

          {reportList.length === 0 ? (
            <EmptyState
              icon={<ClipboardList className="size-6 text-atmos" />}
              title="Sem reportes ativos"
              message="Nenhum fenómeno reportado nas últimas 2 horas. Viste algo? Partilha com a comunidade."
            />
          ) : (
            <div className="flex flex-col gap-2 max-h-[360px] overflow-y-auto scroll-thin pr-1">
              {reportList.map((r) => {
                const confirmedByMe = r.confirmedBy.includes(typeof window !== 'undefined' ? localStorage.getItem('stormwatch-device-id') ?? '' : '');
                return (
                  <article
                    key={r.id}
                    className={`glass rounded-xl p-4 ${selectedReport?.id === r.id ? '' : ''}`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="size-3 shrink-0 rounded-xl" style={{ background: REPORT_COLORS[r.type] }} />
                      <h3 className="text-sm font-semibold">{REPORT_LABELS[r.type]}</h3>
                      <span className="ml-auto text-[10px] text-atmos">{formatRelative(Date.parse(r.createdAt), Date.now())}</span>
                    </div>
                    {r.note && <p className="mt-1.5 text-xs text-foreground/85">{r.note}</p>}
                    <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-atmos">
                      {r.placeName && <span className="flex items-center gap-1"><MapPin className="size-3" /> {r.placeName}</span>}
                      <span>{formatDistance(r.km)} de ti</span>
                      <span>{r.confirmations} confirmação(ões)</span>
                    </div>
                    <button
                      onClick={() => confirm(r.id)}
                      disabled={confirmedByMe || confirmReport.isPending}
                      className={`mt-2.5 flex min-h-[36px] items-center gap-1.5 rounded-xl px-3 text-xs font-medium transition ${
                        confirmedByMe
                          ? ' bg-signal/10 text-signal'
                          : ' bg-cyan/12 text-cyan hover:bg-cyan/25'
 }`}
                    >
                      <Check className="size-3.5" />
                      {confirmedByMe ? 'Já confirmaste' : 'Confirmar ocorrência'}
                    </button>
                  </article>
                );
              })}
            </div>
          )}

          <p className="text-[10px] leading-relaxed text-atmos px-1">
            Os reportes são guardados no servidor da aplicação com limitação de 1 por dispositivo a cada 10 minutos. Não incluem dados pessoais.
          </p>
        </div>
      )}

      {(radar.data?.notice || reports.data?.notice) && mode !== 'reports' && (
        <p className="text-[11px] text-amber px-1">{radar.data?.notice ?? reports.data?.notice}</p>
      )}
      {reports.data?.notice && mode === 'reports' && (
        <p className="text-[11px] text-amber px-1">{reports.data.notice}</p>
      )}

      <ReportDialog open={dialogOpen} onOpenChange={closeDialog} position={pendingPosition} />
    </div>
  );
}
