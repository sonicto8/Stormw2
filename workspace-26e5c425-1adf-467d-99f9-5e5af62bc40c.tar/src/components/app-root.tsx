'use client';

import { ProfileProvider } from '@/hooks/profile-context';
import { Providers } from '@/components/providers';
import { AppShell } from '@/components/layout/app-shell';

/** Raiz da aplicação: fornecedores globais + shell com os cinco separadores. */
export function AppRoot() {
  return (
    <Providers>
      <ProfileProvider>
        <AppShell />
      </ProfileProvider>
    </Providers>
  );
}
