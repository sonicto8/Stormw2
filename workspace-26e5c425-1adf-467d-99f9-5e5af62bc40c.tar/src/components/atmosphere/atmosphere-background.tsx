'use client';

/**
 * Atmosfera dinâmica — camada de fundo cinematográfica que reage à hora do
 * dia, condição meteorológica, precipitação, trovoada e estado de alerta.
 * Limite de 30 elementos DOM animados; desliga com prefers-reduced-motion
 * e em dispositivos de baixo desempenho.
 */
import { useMemo } from 'react';
import { useTheme } from 'next-themes';
import type { MeteoconKey } from '@/lib/types';

export interface AtmosphereState {
  meteocon: MeteoconKey;
  weatherGroup: string;
  isDay: boolean;
  precipitation: number;
  thunder: boolean;
  alertLevel: 'info' | 'warning' | 'critical' | null;
  /** 0..1 — progresso no arco do sol/lua (0 = nascer, 1 = pôr). */
  dayProgress: number;
}

interface AtmosphereBackgroundProps {
  state: AtmosphereState | null;
}

function useReducedMotion(): boolean {
  return useMemo(() => {
    if (typeof window === 'undefined') return true;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return true;
    const cores = navigator.hardwareConcurrency ?? 4;
    return cores <= 2;
  }, []);
}

/** Cores do gradiente conforme condição + dia/noite (identidade céu/natureza). */
function skyColors(state: AtmosphereState | null, light: boolean): { top: string; mid: string; glow: string; bottom: string } {
  if (light) {
    // Tema claro: céu suave sobre Branco Gelo #F5F9FC, cinza-azulado nas condições severas.
    if (!state) return { top: '#D8E9F7', mid: '#EDF4FA', glow: 'rgba(52, 152, 219, 0.10)', bottom: '#F5F9FC' };
    const g = state.weatherGroup;
    if (state.thunder) return { top: '#93A8BF', mid: '#C2CEDC', glow: 'rgba(30, 58, 95, 0.18)', bottom: '#F5F9FC' };
    if (g === 'heavy-rain') return { top: '#A2B6CB', mid: '#CBD6E3', glow: 'rgba(52, 152, 219, 0.12)', bottom: '#F5F9FC' };
    if (g === 'rain' || g === 'drizzle' || g === 'freezing') return { top: '#ACBFD2', mid: '#D2DCE8', glow: 'rgba(52, 152, 219, 0.12)', bottom: '#F5F9FC' };
    if (g === 'snow') return { top: '#BCCBDC', mid: '#DFE6EF', glow: 'rgba(255, 255, 255, 0.35)', bottom: '#F5F9FC' };
    if (g === 'fog') return { top: '#B5C1CE', mid: '#D8DEE6', glow: 'rgba(78, 101, 128, 0.14)', bottom: '#F5F9FC' };
    if (g === 'cloudy' || g === 'partly') return { top: '#B7D3EC', mid: '#DFEAF6', glow: 'rgba(52, 152, 219, 0.12)', bottom: '#F5F9FC' };
    return { top: '#C4E0F6', mid: '#E6F1FB', glow: 'rgba(244, 197, 66, 0.30)', bottom: '#F5F9FC' };
  }
  if (!state) return { top: '#0D1E33', mid: '#142C49', glow: 'rgba(52, 152, 219, 0.10)', bottom: '#0C1A2B' };
  const g = state.weatherGroup;
  const day = state.isDay;
  if (state.thunder) return { top: '#0A1626', mid: '#13253E', glow: 'rgba(111, 168, 220, 0.14)', bottom: '#0C1A2B' };
  if (g === 'heavy-rain') return { top: '#0B1B2D', mid: '#142C49', glow: 'rgba(52, 152, 219, 0.10)', bottom: '#0C1A2B' };
  if (g === 'rain' || g === 'drizzle' || g === 'freezing') return { top: '#0D2136', mid: '#16304F', glow: 'rgba(52, 152, 219, 0.12)', bottom: '#0C1A2B' };
  if (g === 'snow') return { top: '#12233A', mid: '#1B3556', glow: 'rgba(214, 228, 245, 0.10)', bottom: '#0C1A2B' };
  if (g === 'fog') return { top: '#101F31', mid: '#1B3049', glow: 'rgba(167, 188, 212, 0.12)', bottom: '#0C1A2B' };
  if (g === 'cloudy' || g === 'partly') return { top: '#0E2136', mid: '#173252', glow: 'rgba(52, 152, 219, 0.12)', bottom: '#0C1A2B' };
  if (!day) return { top: '#0B1B30', mid: '#152C4B', glow: 'rgba(111, 168, 220, 0.14)', bottom: '#0C1A2B' };
  return { top: '#123354', mid: '#1D4066', glow: 'rgba(244, 197, 66, 0.16)', bottom: '#0C1A2B' };
}

/** Posição do sol/lua no arco (percentagens). */
function arcPosition(progress: number): { x: string; y: string } {
  const p = Math.min(1, Math.max(0, progress));
  const x = 8 + p * 84;
  const y = 68 - Math.sin(p * Math.PI) * 48;
  return { x: `${x}%`, y: `${y}%` };
}

const DENSITY_STEPS = [0, 6, 10, 14, 18] as const;

export function AtmosphereBackground({ state }: AtmosphereBackgroundProps) {
  const reduced = useReducedMotion();
  const { resolvedTheme } = useTheme();
  // O fundo claro é a identidade predefinida; só ativa escuro quando o tema resolvido é «dark»
  // (evita flash escuro antes da hidratação).
  const light = resolvedTheme !== 'dark';
  const colors = skyColors(state, light);

  const rainCount = useMemo(() => {
    if (!state || state.precipitation <= 0) return 0;
    if (state.precipitation < 0.3) return DENSITY_STEPS[1];
    if (state.precipitation < 1) return DENSITY_STEPS[2];
    if (state.precipitation < 3) return DENSITY_STEPS[3];
    return DENSITY_STEPS[4];
  }, [state]);

  const clouds = useMemo(() => {
    if (!state) return 0;
    const g = state.weatherGroup;
    if (g === 'cloudy' || g === 'heavy-rain' || state.thunder) return 4;
    if (g === 'rain' || g === 'drizzle' || g === 'snow' || g === 'fog' || g === 'freezing') return 3;
    if (g === 'partly') return 2;
    return 0;
  }, [state]);

  const showStars = state !== null && !state.isDay && !state.thunder && !light;
  const celestial = arcPosition(state?.dayProgress ?? 0.5);
  const sunVisible = state !== null && state.isDay && (state.weatherGroup === 'clear' || state.weatherGroup === 'partly');
  const moonVisible = state !== null && !state.isDay && (state.weatherGroup === 'clear' || state.weatherGroup === 'partly');
  const alertVignette = state?.alertLevel === 'critical'
    ? 'rgba(230, 57, 70, 0.12)'
    : state?.alertLevel === 'warning'
      ? 'rgba(255, 140, 66, 0.08)'
      : 'transparent';

  // Elementos animados: estrelas(12) + nuvens(4) + gotas(18) + relâmpago(1) + orbe(1) = máx. 36 →
  // em cenários extremos a chuva substitui estrelas; teto prático ≤ 30.
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none" aria-hidden="true">
      {/* Gradiente base */}
      <div
        className="absolute inset-0 transition-[background] duration-1000"
        style={{ background: `linear-gradient(180deg, ${colors.top} 0%, ${colors.mid} 62%, ${colors.bottom} 100%)` }}
      />
      {/* Brilho atmosférico radial */}
      <div
        className="absolute inset-0 transition-[background] duration-1000"
        style={{ background: `radial-gradient(120% 80% at 50% -10%, ${colors.glow} 0%, transparent 60%)` }}
      />

      {reduced ? null : (
        <div className="atmosphere-animated absolute inset-0">
          {/* Estrelas (12) */}
          {showStars &&
            STAR_POSITIONS.map(([x, y, d], i) => (
              <span
                key={`star-${i}`}
                className="absolute rounded-xl bg-[#E8F0FA]"
                style={{
                  left: x,
                  top: y,
                  width: d > 1 ? 2.5 : 1.5,
                  height: d > 1 ? 2.5 : 1.5,
                  opacity: 0.6,
                  animation: `twinkle ${2.4 + d}s ease-in-out ${d * 0.6}s infinite`,
                }}
              />
            ))}

          {/* Sol / Lua no arco */}
          {(sunVisible || moonVisible) && (
            <div
              className="absolute transition-[left,top] duration-[2000ms]"
              style={{ left: celestial.x, top: celestial.y, transform: 'translate(-50%, -50%)' }}
            >
              <div
                className="rounded-xl"
                style={{
                  width: 46,
                  height: 46,
                  background: sunVisible
                    ? 'radial-gradient(circle, #FFEFB0 0%, #F7D774 45%, rgba(244, 197, 66, 0.0) 72%)'
                    : 'radial-gradient(circle, #F4F8FE 0%, #D6E4F5 55%, rgba(214, 228, 245, 0.0) 75%)',
                  boxShadow: sunVisible
                    ? '0 0 60px rgba(247, 215, 116, 0.50), 0 0 140px rgba(244, 197, 66, 0.20)'
                    : '0 0 50px rgba(214, 228, 245, 0.35), 0 0 120px rgba(111, 168, 220, 0.15)',
                  animation: 'float-y 8s ease-in-out infinite',
                }}
              />
            </div>
          )}

          {/* Nuvens em movimento (máx. 4) */}
          {Array.from({ length: clouds }).map((_, i) => (
            <svg
              key={`cloud-${i}`}
              viewBox="0 0 220 80"
              className="absolute"
              style={{
                top: `${8 + i * 16}%`,
                width: 180 + i * 46,
                opacity: 0.10 + i * 0.03,
                animation: `drift ${44 + i * 14}s linear ${-i * 9}s infinite`,
              }}
            >
              <path
                d="M30 62a16 16 0 0 1 3-31 24 24 0 0 1 44-6 17 17 0 0 1 8 32 8 8 0 0 1-3 1H34a14 14 0 0 1-4-1Z"
                fill="#D6E4F5"
              />
            </svg>
          ))}

          {/* Chuva animada (máx. 18 gotas) */}
          {Array.from({ length: rainCount }).map((_, i) => (
            <span
              key={`rain-${i}`}
              className="absolute top-[-6%] w-px rounded-xl"
              style={{
                left: `${(i * 5.7 + 3) % 100}%`,
                height: 34 + ((i * 13) % 26),
                background: light
                  ? 'linear-gradient(180deg, rgba(52, 152, 219, 0) 0%, rgba(52, 152, 219, 0.45) 100%)'
                  : 'linear-gradient(180deg, rgba(74, 169, 238, 0) 0%, rgba(74, 169, 238, 0.55) 100%)',
                ['--drop-opacity' as string]: '0.6',
                animation: `rainfall ${0.9 + ((i * 7) % 40) / 100}s linear ${((i * 17) % 90) / 100}s infinite`,
                opacity: 0.55,
              }}
            />
          ))}

          {/* Relâmpago discreto */}
          {state?.thunder && (
            <div
              className="absolute inset-0"
              style={{
                background:
                  'radial-gradient(80% 60% at 62% 18%, rgba(244, 248, 254, 0.85) 0%, rgba(52, 152, 219, 0.25) 30%, transparent 65%)',
                animation: 'flash 9s linear infinite',
              }}
            />
          )}
        </div>
      )}

      {/* Vinheta de alerta */}
      <div
        className="absolute inset-0 transition-[background] duration-1000"
        style={{
          background: `radial-gradient(130% 100% at 50% 110%, ${alertVignette} 0%, transparent 55%)`,
        }}
      />
    </div>
  );
}

const STAR_POSITIONS: Array<[string, string, number]> = [
  ['6%', '12%', 1.2], ['14%', '22%', 2.4], ['24%', '8%', 0.8], ['33%', '18%', 1.9],
  ['44%', '6%', 1.1], ['55%', '15%', 2.8], ['64%', '10%', 0.7], ['73%', '20%', 1.6],
  ['82%', '9%', 2.2], ['90%', '17%', 1.0], ['19%', '30%', 2.6], ['70%', '28%', 1.4],
];
