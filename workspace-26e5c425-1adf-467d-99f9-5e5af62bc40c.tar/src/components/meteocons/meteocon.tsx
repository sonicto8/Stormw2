'use client';

/**
 * Meteocons — sistema de ícones meteorológicos SVG animados.
 * Sem emoji, sem imagens externas: SVG + CSS puros com gradientes atmosféricos.
 */
import { useId } from 'react';
import type { MeteoconKey } from '@/lib/types';

interface MeteoconProps {
  code: MeteoconKey;
  size?: number;
  className?: string;
  /** Animações suaves ativadas por omissão; desligar em contextos estáticos. */
  animated?: boolean;
}

export function Meteocon({ code, size = 64, className, animated = true }: MeteoconProps) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const anim = animated ? 'mw-anim' : '';

  return (
    <svg
      viewBox="0 0 128 128"
      width={size}
      height={size}
      className={className}
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <radialGradient id={`sun-${uid}`} cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFEFB0" />
          <stop offset="55%" stopColor="#F7D774" />
          <stop offset="100%" stopColor="#F4C542" />
        </radialGradient>
        <radialGradient id={`moon-${uid}`} cx="42%" cy="40%" r="70%">
          <stop offset="0%" stopColor="#F4F8FE" />
          <stop offset="70%" stopColor="#D6E4F5" />
          <stop offset="100%" stopColor="#A9BFDC" />
        </radialGradient>
        <linearGradient id={`cloud-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#EAF1F9" />
          <stop offset="100%" stopColor="#B7C8DD" />
        </linearGradient>
        <linearGradient id={`cloudDark-${uid}`} x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#8FA5BF" />
          <stop offset="100%" stopColor="#5A7391" />
        </linearGradient>
        <linearGradient id={`bolt-${uid}`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F4C542" />
          <stop offset="100%" stopColor="#FF8C42" />
        </linearGradient>
      </defs>

      {code === 'clear-day' && (
        <g>
          <g className={anim ? 'mw-rays' : ''} style={{ transformOrigin: '64px 64px' }}>
            {Array.from({ length: 8 }).map((_, i) => (
              <line
                key={i}
                x1="64"
                y1="18"
                x2="64"
                y2="34"
                stroke="#EFC24B"
                strokeWidth="5"
                strokeLinecap="round"
                transform={`rotate(${i * 45} 64 64)`}
              />
            ))}
          </g>
          <circle cx="64" cy="64" r="26" fill={`url(#sun-${uid})`} />
          <circle cx="64" cy="64" r="34" fill="none" stroke="#EFC24B" strokeOpacity="0.30" strokeWidth="3" className={anim ? 'mw-breathe' : ''} />
        </g>
      )}

      {code === 'clear-night' && (
        <g>
          <path
            d="M78 22a34 34 0 1 0 28 52 30 30 0 0 1-28-52Z"
            fill={`url(#moon-${uid})`}
          />
          <circle cx="34" cy="38" r="3" fill="#D6E4F5" className={anim ? 'mw-star' : ''} />
          <circle cx="100" cy="30" r="2" fill="#D6E4F5" className={anim ? 'mw-star mw-star-2' : ''} />
          <circle cx="104" cy="92" r="2.5" fill="#A9BFDC" className={anim ? 'mw-star mw-star-3' : ''} />
          <circle cx="28" cy="86" r="2" fill="#A9BFDC" className={anim ? 'mw-star mw-star-2' : ''} />
        </g>
      )}

      {(code === 'partly-day' || code === 'partly-night') && (
        <g>
          {code === 'partly-day' ? (
            <g>
              <g className={anim ? 'mw-rays' : ''} style={{ transformOrigin: '86px 40px' }}>
                {Array.from({ length: 6 }).map((_, i) => (
                  <line
                    key={i}
                    x1="86"
                    y1="14"
                    x2="86"
                    y2="24"
                    stroke="#EFC24B"
                    strokeWidth="4.5"
                    strokeLinecap="round"
                    transform={`rotate(${i * 60} 86 40)`}
                  />
                ))}
              </g>
              <circle cx="86" cy="40" r="17" fill={`url(#sun-${uid})`} />
            </g>
          ) : (
            <path d="M92 16a22 22 0 1 0 18 34 19 19 0 0 1-18-34Z" fill={`url(#moon-${uid})`} />
          )}
          <g className={anim ? 'mw-cloud-drift' : ''}>
            <path
              d="M40 88a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H44a13 13 0 0 1-4-1Z"
              fill={`url(#cloud-${uid})`}
            />
          </g>
        </g>
      )}

      {code === 'overcast' && (
        <g>
          <path
            d="M30 62a13 13 0 0 1 3-25 16 16 0 0 1 30-3 11 11 0 0 1 5 21 5 5 0 0 1-2 0H33a10 10 0 0 1-3-1Z"
            fill={`url(#cloudDark-${uid})`}
            opacity="0.7"
            className={anim ? 'mw-cloud-drift-slow' : ''}
          />
          <g className={anim ? 'mw-cloud-drift' : ''}>
            <path
              d="M38 92a17 17 0 0 1 2-33 22 22 0 0 1 42-5 15 15 0 0 1 7 29 7 7 0 0 1-2 0H42a14 14 0 0 1-4-1Z"
              fill={`url(#cloud-${uid})`}
            />
          </g>
        </g>
      )}

      {code === 'fog' && (
        <g>
          <path
            d="M40 70a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H44a13 13 0 0 1-4-1Z"
            fill={`url(#cloud-${uid})`}
          />
          <g stroke="#A9BFDC" strokeWidth="5" strokeLinecap="round" opacity="0.85">
            <line x1="24" y1="84" x2="86" y2="84" className={anim ? 'mw-fog mw-fog-1' : ''} />
            <line x1="42" y1="96" x2="104" y2="96" className={anim ? 'mw-fog mw-fog-2' : ''} />
            <line x1="30" y1="108" x2="88" y2="108" className={anim ? 'mw-fog mw-fog-3' : ''} />
          </g>
        </g>
      )}

      {(code === 'drizzle' || code === 'rain' || code === 'heavy-rain') && (
        <g>
          <path
            d="M38 64a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H42a13 13 0 0 1-4-1Z"
            fill={code === 'heavy-rain' ? `url(#cloudDark-${uid})` : `url(#cloud-${uid})`}
          />
          <g stroke="#3498DB" strokeWidth={code === 'heavy-rain' ? 5 : 4} strokeLinecap="round">
            {DROP_POSITIONS[code === 'drizzle' ? 'small' : code === 'rain' ? 'medium' : 'heavy'].map(
              ([x, y, d], i) => (
                <line
                  key={i}
                  x1={x}
                  y1={y}
                  x2={x}
                  y2={y + (code === 'drizzle' ? 5 : 9)}
                  className={anim ? `mw-drop mw-drop-${d}` : ''}
                  opacity={code === 'drizzle' ? 0.55 : 0.85}
                />
              ),
            )}
          </g>
        </g>
      )}

      {code === 'freezing-rain' && (
        <g>
          <path
            d="M38 60a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H42a13 13 0 0 1-4-1Z"
            fill={`url(#cloud-${uid})`}
          />
          <g stroke="#7FB8DC" strokeWidth="4" strokeLinecap="round">
            {[[44, 74], [62, 78], [80, 74], [54, 92], [72, 94]].map(([x, y], i) => (
              <line key={i} x1={x} y1={y} x2={x} y2={y + 8} className={anim ? `mw-drop mw-drop-${i % 3}` : ''} />
            ))}
          </g>
          <g stroke="#D6E4F5" strokeWidth="3" strokeLinecap="round">
            {[[36, 88], [90, 90]].map(([x, y], i) => (
              <g key={i}>
                <line x1={x - 4} y1={y} x2={x + 4} y2={y} />
                <line x1={x} y1={y - 4} x2={x} y2={y + 4} />
              </g>
            ))}
          </g>
        </g>
      )}

      {code === 'snow' && (
        <g>
          <path
            d="M38 62a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H42a13 13 0 0 1-4-1Z"
            fill={`url(#cloud-${uid})`}
          />
          <g fill="#9FC1DE">
            {[[44, 78], [62, 82], [80, 78], [52, 98], [70, 100], [88, 94]].map(([x, y], i) => (
              <circle key={i} cx={x} cy={y} r="3.4" className={anim ? `mw-flake mw-flake-${i % 3}` : ''} />
            ))}
          </g>
        </g>
      )}

      {(code === 'thunder' || code === 'thunder-hail') && (
        <g>
          <path
            d="M36 58a16 16 0 0 1 2-31 20 20 0 0 1 38-4 14 14 0 0 1 6 27 6 6 0 0 1-2 0H40a13 13 0 0 1-4-1Z"
            fill={`url(#cloudDark-${uid})`}
          />
          <path
            d="M66 62 52 84h12l-6 22 20-28H64l8-16h-6Z"
            fill={`url(#bolt-${uid})`}
            className={anim ? 'mw-bolt' : ''}
          />
          {code === 'thunder-hail' && (
            <g fill="#AFC9E2">
              {[[38, 84], [90, 80], [46, 100]].map(([x, y], i) => (
                <circle key={i} cx={x} cy={y} r="4.5" className={anim ? `mw-flake mw-flake-${i % 3}` : ''} />
              ))}
            </g>
          )}
        </g>
      )}
    </svg>
  );
}

const DROP_POSITIONS = {
  small: [[46, 72, 0], [58, 70, 1], [70, 72, 2], [82, 70, 0]] as Array<[number, number, number]>,
  medium: [[44, 72, 0], [54, 70, 1], [64, 72, 2], [74, 70, 0], [84, 72, 1]] as Array<[number, number, number]>,
  heavy: [[42, 72, 0], [51, 70, 1], [60, 72, 2], [69, 70, 0], [78, 72, 1], [87, 70, 2]] as Array<[number, number, number]>,
};
