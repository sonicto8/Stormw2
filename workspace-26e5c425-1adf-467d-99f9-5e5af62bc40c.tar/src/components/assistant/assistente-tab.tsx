'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ChevronDown, CornerDownLeft, Loader2, MessageSquareText, Sparkles } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { z } from 'zod';
import type { AirQualityBundle, ChatMessage, ForecastBundle } from '@/lib/types';
import { buildIntentAnswer } from '@/lib/engines/intents';
import { useProfileContext } from '@/hooks/profile-context';
import { postInternal } from '@/lib/services/api-client';
import { formatRelative } from '@/lib/format';
import { EmptyState } from '@/components/shared/states';
import { uid } from '@/lib/services/uid';

const HISTORY_KEY = 'stormwatch-chat-history';
const MAX_MESSAGES = 60;

const rephraseResponseSchema = z.object({
  text: z.string(),
  source: z.enum(['llm', 'engine']),
});

function loadHistory(): ChatMessage[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((m): m is ChatMessage => {
        if (typeof m !== 'object' || m === null) return false;
        const msg = m as Record<string, unknown>;
        return typeof msg.id === 'string' && (msg.role === 'user' || msg.role === 'assistant') && typeof msg.text === 'string';
      })
      .slice(-MAX_MESSAGES);
  } catch {
    return [];
  }
}

function persistHistory(messages: ChatMessage[]): void {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(messages.slice(-MAX_MESSAGES)));
  } catch {
    // localStorage indisponível — o histórico vive apenas nesta sessão.
  }
}

interface AssistenteTabProps {
  bundle: ForecastBundle | null;
  air: AirQualityBundle | null;
  nowMs: number;
}

export function AssistenteTab({ bundle, air, nowMs }: AssistenteTabProps) {
  const { profile } = useProfileContext();
  const [messages, setMessages] = useState<ChatMessage[]>(loadHistory);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    persistHistory(messages);
  }, [messages]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages.length, thinking]);

  const ask = useCallback(
    async (question: string) => {
      const text = question.trim();
      if (text.length === 0 || !bundle || thinking) return;

      const userMsg: ChatMessage = {
        id: uid(),
        role: 'user',
        text,
        details: [],
        createdAt: Date.now(),
        final: true,
        intent: null,
      };
      setMessages((prev) => [...prev, userMsg]);
      setThinking(true);

      // 1. Motor determinístico local: a fonte da verdade dos números.
      const answer = buildIntentAnswer(text, { bundle, air, nowMs }, profile);
      const assistantMsg: ChatMessage = {
        id: uid(),
        role: 'assistant',
        text: answer.text,
        details: answer.details,
        createdAt: Date.now(),
        final: false,
        intent: answer.intent,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setThinking(false);

      // 2. Reformulação opcional por LLM (valida preservação dos números no servidor).
      try {
        const res = await postInternal('/api/storm-ai', { answer: answer.text, question: text }, rephraseResponseSchema, {
          timeoutMs: 15000,
        });
        if (res.source === 'llm' && res.text !== answer.text) {
          setMessages((prev) => prev.map((m) => (m.id === assistantMsg.id ? { ...m, text: res.text, final: true } : m)));
        } else {
          setMessages((prev) => prev.map((m) => (m.id === assistantMsg.id ? { ...m, final: true } : m)));
        }
      } catch {
        setMessages((prev) => prev.map((m) => (m.id === assistantMsg.id ? { ...m, final: true } : m)));
      }
    },
    [bundle, air, nowMs, profile, thinking],
  );

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void ask(input);
    setInput('');
  };

  const empty = messages.length === 0;

  const quickQuestions = useMemo(
    () => [
      'Preciso de guarda-chuva hoje?',
      'O que devo vestir?',
      'Qual a melhor hora para correr?',
      'É bom dia para a praia?',
      'Posso lavar o carro amanhã?',
    ],
    [],
  );

  return (
    <div className="flex flex-col gap-4 animate-fade-up">
      <div className="glass rounded-xl p-4">
        <div className="flex items-center gap-3">
          <div className="flex size-11 items-center justify-center rounded-xl bg-cyan/10">
            <MessageSquareText className="size-5 text-cyan" />
          </div>
          <div className="min-w-0">
            <h1 className="font-display text-lg font-bold tracking-tight">STORM AI</h1>
            <p className="text-xs text-atmos">
              Assistente meteorológico · cálculo local e determinístico sobre dados reais
            </p>
          </div>
        </div>
        {!bundle && (
          <p className="mt-3 rounded-xl border-l-[3px] border-l-amber bg-amber/8 px-3 py-2 text-xs text-amber">
            A carregar os dados meteorológicos — as respostas ficam disponíveis de imediato a seguir.
          </p>
        )}
      </div>

      {empty && (
        <EmptyState
          icon={<Sparkles className="size-6 text-cyan" />}
          title="Pergunta o que quiseres sobre o tempo"
          message="As respostas são calculadas localmente com base na previsão em tempo real da tua localização — sem inventar dados."
        />
      )}

      <div ref={listRef} className="flex flex-col gap-3 max-h-[52dvh] overflow-y-auto scroll-thin pr-1" aria-live="polite">
        <AnimatePresence initial={false}>
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.22 }}
              className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[86%] rounded-xl px-4 py-3 ${
                  m.role === 'user'
                    ? ' bg-cyan/12 rounded-xl'
                    : 'glass rounded-xl'
 }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{m.text}</p>
                {m.details.length > 0 && (
                  <div className="mt-2">
                    <button
                      onClick={() => setExpanded(expanded === m.id ? null : m.id)}
                      aria-expanded={expanded === m.id}
                      className="flex items-center gap-1 text-[11px] text-cyan transition hover:text-cyan/80"
                    >
                      Detalhes do cálculo
                      <ChevronDown className={`size-3 transition-transform ${expanded === m.id ? 'rotate-180' : ''}`} />
                    </button>
                    <AnimatePresence initial={false}>
                      {expanded === m.id && (
                        <motion.ul
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          {m.details.map((d, i) => (
                            <li key={i} className="mt-1.5 rounded-xl bg-blue/5 px-3 py-1.5 text-[11px] text-foreground/80">
                              {d}
                            </li>
                          ))}
                        </motion.ul>
                      )}
                    </AnimatePresence>
                  </div>
                )}
                <p className="mt-1.5 text-[10px] text-atmos">
                  {formatRelative(m.createdAt, Date.now())}
                  {m.role === 'assistant' && !m.final && ' · a refinar…'}
                  {m.role === 'assistant' && m.intent === 'fallback' && ' · resposta geral'}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {thinking && (
          <div className="flex items-center gap-2 text-xs text-atmos px-2">
            <Loader2 className="size-3.5 animate-spin text-cyan" /> A calcular com os dados atuais…
          </div>
        )}
      </div>

      {/* As cinco perguntas obrigatórias estão sempre acessíveis. */}
      <div className="flex flex-wrap gap-2">
        {quickQuestions.map((q) => (
          <button
            key={q}
            onClick={() => void ask(q)}
            disabled={!bundle || thinking}
            className="rounded-xl bg-blue/5 px-3 py-1.5 text-[11px] text-atmos transition  hover:text-cyan disabled:opacity-50 min-h-[32px]"
          >
            {q}
          </button>
        ))}
      </div>

      <form onSubmit={onSubmit} className="glass-strong rounded-xl flex items-center gap-2 p-2 pl-4">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={bundle ? 'Pergunta algo sobre o tempo…' : 'A aguardar dados meteorológicos…'}
          aria-label="Escrever pergunta para o STORM AI"
          className="flex-1 bg-transparent text-sm outline-none placeholder:text-atmos/70 min-w-0"
          maxLength={200}
        />
        <button
          type="submit"
          disabled={!bundle || thinking || input.trim().length === 0}
          className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-cyan/15 text-cyan transition hover:bg-cyan/25 disabled:opacity-40"
          aria-label="Enviar pergunta"
        >
          <CornerDownLeft className="size-4" />
        </button>
      </form>
    </div>
  );
}
