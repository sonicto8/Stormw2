'use client';

import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';
import {
  ArrowRight,
  BellRing,
  Check,
  Download,
  Droplets,
  LifeBuoy,
  MapPin,
  MessageCircle,
  Monitor,
  Moon,
  Navigation,
  Pencil,
  Phone,
  Plus,
  Ruler,
  Search,
  Server,
  ShieldAlert,
  Snowflake,
  Sun,
  Thermometer,
  Trash2,
  Wind,
  X,
} from 'lucide-react';
import { toast } from 'sonner';
import type { Profile } from '@/lib/schemas/report.schema';
import { emergencyContactSchema } from '@/lib/schemas/report.schema';
import { useProfileContext } from '@/hooks/profile-context';
import { useInstallPrompt } from '@/hooks/use-install-prompt';
import { useAppStore } from '@/store/app-store';
import { QUICK_LOCATIONS } from '@/lib/locations';
import { PushNotificationsSection } from '@/components/profile/notifications-section';

const ACTIVITY_OPTIONS: Array<{ key: string; label: string }> = [
  { key: 'running', label: 'Corrida' },
  { key: 'walking', label: 'Caminhada' },
  { key: 'cycling', label: 'Ciclismo' },
  { key: 'photography', label: 'Fotografia' },
  { key: 'football', label: 'Futebol' },
  { key: 'beach', label: 'Praia' },
];

const ALERT_OPTIONS: Array<{ key: string; label: string; description: string }> = [
  { key: 'rain', label: 'Precipitação iminente', description: 'Chuva > 0,1 mm/15 min' },
  { key: 'thunderstorm', label: 'Trovoada', description: 'Códigos 95–99 do WMO' },
  { key: 'wind', label: 'Rajadas fortes', description: '≥ 60 km/h aviso · ≥ 90 crítico' },
  { key: 'heat', label: 'Calor extremo', description: '≥ 35°C' },
  { key: 'cold', label: 'Frio extremo', description: 'Sensação ≤ 0°C' },
  { key: 'air', label: 'Qualidade do ar', description: 'AQI > 60 sensíveis · > 100 todos' },
];

function SensitivitySlider({
  label,
  icon: Icon,
  value,
  onChange,
  lowLabel,
  highLabel,
}: {
  label: string;
  icon: typeof Thermometer;
  value: number;
  onChange: (v: number) => void;
  lowLabel: string;
  highLabel: string;
}) {
  return (
    <div className="rounded-xl bg-blue/4 p-4">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-sm font-medium">
          <Icon className="size-4 text-cyan" /> {label}
        </span>
        <span className="font-display text-lg font-bold text-cyan">{value}/5</span>
      </div>
      <input
        type="range"
        min={1}
        max={5}
        step={1}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-3 w-full accent-[#3498DB]"
        aria-label={`${label}: ${value} de 5`}
      />
      <div className="flex justify-between text-[10px] text-atmos mt-1">
        <span>{lowLabel}</span>
        <span>{highLabel}</span>
      </div>
    </div>
  );
}

function ChipToggle({
  label,
  active,
  onToggle,
}: {
  label: string;
  active: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      aria-pressed={active}
      className={`flex min-h-[40px] items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-medium transition ${
        active
          ? ' bg-cyan/12 text-cyan'
          : ' bg-blue/4 text-atmos hover:text-foreground'
 }`}
    >
      {active && <Check className="size-3.5" />}
      {label}
    </button>
  );
}

function Onboarding() {
  const { setProfile } = useProfileContext();
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState<Profile>(() => ({
    coldSensitivity: 3,
    heatSensitivity: 3,
    favoriteActivities: [],
    alertTypes: ALERT_OPTIONS.map((a) => a.key),
    temperatureUnit: 'celsius',
    windUnit: 'kmh',
    favoriteLocations: [],
    emergencyContacts: [],
    browserNotifications: false,
    onboardingDone: false,
  }));

  const steps = ['Sensibilidade ao frio', 'Sensibilidade ao calor', 'Atividades favoritas', 'Alertas', 'Unidades'];
  const last = step === steps.length - 1;

  const finish = () => {
    setProfile({ ...draft, onboardingDone: true });
    toast.success('Perfil guardado — as recomendações estão personalizadas.');
  };

  return (
    <div className="glass rounded-xl p-5 animate-fade-up" aria-label="Configuração inicial">
      <div className="flex items-center justify-between gap-2 mb-4">
        <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-cyan">
          Passo {step + 1} de {steps.length}
        </p>
        <p className="text-xs text-atmos">{steps[step]}</p>
      </div>
      <div className="mb-5 flex gap-1.5" aria-hidden="true">
        {steps.map((_, i) => (
          <div key={i} className={`h-1 flex-1 rounded-xl transition-colors duration-300 ${i <= step ? 'bg-cyan' : 'bg-blue/12'}`} />
        ))}
      </div>

      {step === 0 && (
        <div>
          <h2 className="font-display text-lg font-bold">Quão sensível és ao frio?</h2>
          <p className="mt-1 text-xs text-atmos mb-4">Usamos isto para ajustar avisos pessoais e sugestões de roupa.</p>
          <SensitivitySlider
            label="Sensibilidade ao frio"
            icon={Snowflake}
            value={draft.coldSensitivity}
            onChange={(v) => setDraft((d) => ({ ...d, coldSensitivity: v }))}
            lowLabel="Resisto bem"
            highLabel="Sinto muito"
          />
        </div>
      )}

      {step === 1 && (
        <div>
          <h2 className="font-display text-lg font-bold">E ao calor?</h2>
          <p className="mt-1 text-xs text-atmos mb-4">Afeta avisos de calor intenso e recomendações de hidratação.</p>
          <SensitivitySlider
            label="Sensibilidade ao calor"
            icon={Thermometer}
            value={draft.heatSensitivity}
            onChange={(v) => setDraft((d) => ({ ...d, heatSensitivity: v }))}
            lowLabel="Tolero bem"
            highLabel="Afeição rápida"
          />
        </div>
      )}

      {step === 2 && (
        <div>
          <h2 className="font-display text-lg font-bold">Que atividades fazes?</h2>
          <p className="mt-1 text-xs text-atmos mb-4">Os índices destas atividades ganham destaque no Início.</p>
          <div className="flex flex-wrap gap-2">
            {ACTIVITY_OPTIONS.map((a) => (
              <ChipToggle
                key={a.key}
                label={a.label}
                active={draft.favoriteActivities.includes(a.key)}
                onToggle={() =>
                  setDraft((d) => ({
                    ...d,
                    favoriteActivities: d.favoriteActivities.includes(a.key)
                      ? d.favoriteActivities.filter((k) => k !== a.key)
                      : [...d.favoriteActivities, a.key],
                  }))
                }
              />
            ))}
          </div>
        </div>
      )}

      {step === 3 && (
        <div>
          <h2 className="font-display text-lg font-bold">Que alertas queres receber?</h2>
          <p className="mt-1 text-xs text-atmos mb-4">
            Os avisos oficiais do IPMA são sempre apresentados, com a cor oficial.
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            {ALERT_OPTIONS.map((a) => {
              const active = draft.alertTypes.includes(a.key);
              return (
                <button
                  key={a.key}
                  onClick={() =>
                    setDraft((d) => ({
                      ...d,
                      alertTypes: active ? d.alertTypes.filter((k) => k !== a.key) : [...d.alertTypes, a.key],
                    }))
                  }
                  aria-pressed={active}
                  className={`rounded-xl px-3.5 py-2.5 text-left transition min-h-[56px] ${
                    active ? ' bg-cyan/10' : ' bg-blue/4 '
 }`}
                >
                  <p className={`flex items-center gap-1.5 text-xs font-semibold ${active ? 'text-cyan' : ''}`}>
                    <BellRing className="size-3.5" /> {a.label}
                  </p>
                  <p className="mt-0.5 text-[10px] text-atmos">{a.description}</p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {step === 4 && (
        <div>
          <h2 className="font-display text-lg font-bold">Unidades preferidas</h2>
          <p className="mt-1 text-xs text-atmos mb-4">Podes alterar isto em qualquer momento nas Definições.</p>
          <div className="flex flex-col gap-3">
            <div className="rounded-xl bg-blue/4 p-4">
              <p className="flex items-center gap-2 text-sm font-medium mb-3"><Thermometer className="size-4 text-cyan" /> Temperatura</p>
              <div className="grid grid-cols-2 gap-2">
                {(['celsius', 'fahrenheit'] as const).map((u) => (
                  <button
                    key={u}
                    onClick={() => setDraft((d) => ({ ...d, temperatureUnit: u }))}
                    aria-pressed={draft.temperatureUnit === u}
                    className={`rounded-xl px-3 py-2 text-xs font-medium transition min-h-[40px] ${
                      draft.temperatureUnit === u ? ' bg-cyan/12 text-cyan' : ' bg-blue/4 text-atmos'
 }`}
                  >
                    {u === 'celsius' ? 'Celsius (°C)' : 'Fahrenheit (°F)'}
                  </button>
                ))}
              </div>
            </div>
            <div className="rounded-xl bg-blue/4 p-4">
              <p className="flex items-center gap-2 text-sm font-medium mb-3"><Wind className="size-4 text-cyan" /> Vento</p>
              <div className="grid grid-cols-2 gap-2">
                {(['kmh', 'ms'] as const).map((u) => (
                  <button
                    key={u}
                    onClick={() => setDraft((d) => ({ ...d, windUnit: u }))}
                    aria-pressed={draft.windUnit === u}
                    className={`rounded-xl px-3 py-2 text-xs font-medium transition min-h-[40px] ${
                      draft.windUnit === u ? ' bg-cyan/12 text-cyan' : ' bg-blue/4 text-atmos'
 }`}
                  >
                    {u === 'kmh' ? 'km/h' : 'm/s'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 flex items-center justify-between">
        <button
          onClick={() => (step === 0 ? finish() : setStep((s) => s - 1))}
          className="rounded-xl bg-blue/5 px-4 py-2.5 text-sm text-atmos transition hover:text-foreground min-h-[44px]"
        >
          {step === 0 ? 'Configurar mais tarde' : 'Anterior'}
        </button>
        <button
          onClick={() => (last ? finish() : setStep((s) => s + 1))}
          className="flex items-center gap-2 rounded-xl bg-cyan/15 px-5 py-2.5 text-sm font-medium text-cyan transition hover:bg-cyan/25 min-h-[44px]"
        >
          {last ? 'Concluir' : 'Continuar'} <ArrowRight className="size-4" />
        </button>
      </div>
    </div>
  );
}

/** Contacto de emergência: nome + telemóvel, máximo 2, partilha WhatsApp em SOS. */
function EmergencyContactsSection() {
  const { profile, setProfile } = useProfileContext();
  const contacts = profile.emergencyContacts ?? [];
  const [editing, setEditing] = useState<'new' | string | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState<string | null>(null);

  const startEdit = (id: string | 'new') => {
    const existing = id === 'new' ? null : contacts.find((c) => c.id === id) ?? null;
    setName(existing?.name ?? '');
    setPhone(existing?.phone ?? '');
    setError(null);
    setEditing(id);
  };

  const cancel = () => {
    setEditing(null);
    setName('');
    setPhone('');
    setError(null);
  };

  const save = () => {
    const parsed = emergencyContactSchema.safeParse({
      id: editing === 'new' ? `contact-${Date.now()}` : editing,
      name,
      phone,
    });
    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      setError(issue?.message ?? 'Dados inválidos');
      return;
    }
    const next = editing === 'new' ? [...contacts, parsed.data] : contacts.map((c) => (c.id === editing ? parsed.data : c));
    setProfile({ emergencyContacts: next });
    toast.success(editing === 'new' ? 'Contacto de emergência guardado.' : 'Contacto atualizado.');
    cancel();
  };

  const remove = (id: string) => {
    setProfile({ emergencyContacts: contacts.filter((c) => c.id !== id) });
    toast.success('Contacto removido.');
  };

  const canAdd = contacts.length < 2;

  return (
    <section className="glass rounded-xl p-4" aria-label="Contactos de emergência">
      <div className="flex items-center justify-between px-1 mb-1 gap-3">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold">
          <LifeBuoy className="size-4 text-critical" /> Contactos de emergência
        </h2>
        {canAdd && editing === null && (
          <button
            onClick={() => startEdit('new')}
            className="flex items-center gap-1.5 rounded-xl bg-cyan/12 px-3 py-1.5 text-xs text-cyan transition hover:bg-cyan/25 min-h-[36px]"
          >
            <Plus className="size-3.5" /> Adicionar
          </button>
        )}
      </div>
      <p className="text-[11px] leading-relaxed text-atmos px-1 mb-3">
        Até 2 contactos. Em caso de desastre, o painel de emergência (Início) partilha a tua localização, o mapa e os
        avisos ativos por WhatsApp com estes contactos.
      </p>

      {contacts.length === 0 && editing === null && (
        <div className="mx-1 rounded-xl bg-blue/4 px-3.5 py-3">
          <p className="text-xs text-atmos">
            Nenhum contacto configurado. Adiciona quem deve receber a tua localização em situações graves.
          </p>
        </div>
      )}

      {contacts.length > 0 && (
        <ul className="flex flex-col gap-1.5 px-1">
          {contacts.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 rounded-xl bg-blue/4 px-3 py-2">
              <div className="min-w-0">
                <p className="text-xs font-medium truncate">{c.name}</p>
                <p className="flex items-center gap-1 text-[11px] text-atmos">
                  <Phone className="size-3" /> {c.phone}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => startEdit(c.id)}
                  aria-label={`Editar ${c.name}`}
                  className="flex size-8 items-center justify-center rounded-xl text-atmos transition hover:text-cyan "
                >
                  <Pencil className="size-3.5" />
                </button>
                <button
                  onClick={() => remove(c.id)}
                  aria-label={`Remover ${c.name}`}
                  className="flex size-8 items-center justify-center rounded-xl text-atmos transition hover:text-critical "
                >
                  <X className="size-3.5" />
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      {editing !== null && (
        <div className="mt-3 mx-1 rounded-xl bg-cyan/6 px-3.5 py-3.5">
          <p className="flex items-center gap-1.5 text-xs font-semibold text-cyan mb-3">
            <ShieldAlert className="size-3.5" />
            {editing === 'new' ? 'Novo contacto de emergência' : 'Editar contacto'}
          </p>
          <div className="flex flex-col gap-2.5">
            <label className="flex flex-col gap-1">
              <span className="text-[11px] text-atmos">Nome</span>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={40}
                placeholder="Ex.: Maria Silva"
                className="rounded-xl bg-blue/6 px-3 py-2 text-sm outline-none transition  min-h-[44px]"
                aria-label="Nome do contacto de emergência"
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-[11px] text-atmos">Telemóvel (com WhatsApp)</span>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                inputMode="tel"
                placeholder="912 345 678 ou +351 912 345 678"
                className="rounded-xl bg-blue/6 px-3 py-2 text-sm outline-none transition  min-h-[44px]"
                aria-label="Número de telemóvel do contacto"
              />
            </label>
            {error && (
              <p className="rounded-xl bg-critical/10 px-3 py-2 text-xs text-critical">{error}</p>
            )}
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={save}
                className="flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-cyan/15 px-4 text-sm font-medium text-cyan transition hover:bg-cyan/25"
              >
                <Check className="size-4" /> Guardar contacto
              </button>
              <button
                onClick={cancel}
                className="flex min-h-[44px] items-center rounded-xl bg-blue/5 px-4 text-sm text-atmos transition hover:text-foreground"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {!canAdd && editing === null && (
        <p className="mt-2 text-[10px] text-atmos px-1">Limite de 2 contactos atingido — remove um para adicionar outro.</p>
      )}
    </section>
  );
}

function SettingsView() {
  const { profile, setProfile, resetProfile } = useProfileContext();
  const { theme, resolvedTheme, setTheme } = useTheme();
  const { setTheme: setStoreTheme, setLocationDialogOpen } = useAppStore();
  const { canInstall, installed, install } = useInstallPrompt();
  const [addingLocation, setAddingLocation] = useState(false);

  const toggleInList = (list: string[], key: string): string[] =>
    list.includes(key) ? list.filter((k) => k !== key) : [...list, key];

  return (
    <div className="flex flex-col gap-4 animate-fade-up">
      {/* Contactos de emergência — partilha WhatsApp em caso de desastre */}
      <EmergencyContactsSection />

      {/* Sensibilidades */}
      <section className="glass rounded-xl p-4" aria-label="Sensibilidade">
        <h2 className="font-display text-sm font-semibold mb-3 px-1">Sensibilidade pessoal</h2>
        <div className="grid gap-2.5 sm:grid-cols-2">
          <SensitivitySlider
            label="Sensibilidade ao frio"
            icon={Snowflake}
            value={profile.coldSensitivity}
            onChange={(v) => setProfile({ coldSensitivity: v })}
            lowLabel="Resisto bem"
            highLabel="Sinto muito"
          />
          <SensitivitySlider
            label="Sensibilidade ao calor"
            icon={Thermometer}
            value={profile.heatSensitivity}
            onChange={(v) => setProfile({ heatSensitivity: v })}
            lowLabel="Tolero bem"
            highLabel="Afeição rápida"
          />
        </div>
      </section>

      {/* Atividades e alertas */}
      <section className="glass rounded-xl p-4" aria-label="Preferências de conteúdo">
        <h2 className="font-display text-sm font-semibold mb-3 px-1">Atividades favoritas</h2>
        <div className="flex flex-wrap gap-2 px-1">
          {ACTIVITY_OPTIONS.map((a) => (
            <ChipToggle
              key={a.key}
              label={a.label}
              active={profile.favoriteActivities.includes(a.key)}
              onToggle={() => setProfile({ favoriteActivities: toggleInList(profile.favoriteActivities, a.key) })}
            />
          ))}
        </div>

        <h2 className="font-display text-sm font-semibold mt-5 mb-3 px-1">Tipos de alerta internos</h2>
        <div className="flex flex-wrap gap-2 px-1">
          {ALERT_OPTIONS.map((a) => (
            <ChipToggle
              key={a.key}
              label={a.label}
              active={profile.alertTypes.includes(a.key)}
              onToggle={() => setProfile({ alertTypes: toggleInList(profile.alertTypes, a.key) })}
            />
          ))}
        </div>
      </section>

      {/* Unidades */}
      <section className="glass rounded-xl p-4" aria-label="Unidades">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-3 px-1"><Ruler className="size-4 text-cyan" /> Unidades</h2>
        <div className="grid grid-cols-2 gap-2 px-1">
          {(['celsius', 'fahrenheit'] as const).map((u) => (
            <button
              key={u}
              onClick={() => setProfile({ temperatureUnit: u })}
              aria-pressed={profile.temperatureUnit === u}
              className={`rounded-xl px-3 py-2 text-xs font-medium transition min-h-[40px] ${
                profile.temperatureUnit === u ? ' bg-cyan/12 text-cyan' : ' bg-blue/4 text-atmos'
 }`}
            >
              {u === 'celsius' ? 'Celsius (°C)' : 'Fahrenheit (°F)'}
            </button>
          ))}
        </div>
        <div className="mt-2 grid grid-cols-2 gap-2 px-1">
          {(['kmh', 'ms'] as const).map((u) => (
            <button
              key={u}
              onClick={() => setProfile({ windUnit: u })}
              aria-pressed={profile.windUnit === u}
              className={`rounded-xl px-3 py-2 text-xs font-medium transition min-h-[40px] ${
                profile.windUnit === u ? ' bg-cyan/12 text-cyan' : ' bg-blue/4 text-atmos'
 }`}
            >
              {u === 'kmh' ? 'Vento em km/h' : 'Vento em m/s'}
            </button>
          ))}
        </div>
      </section>

      {/* Localidades favoritas */}
      <section className="glass rounded-xl p-4" aria-label="Localidades favoritas">
        <div className="flex items-center justify-between px-1 mb-3">
          <h2 className="flex items-center gap-2 font-display text-sm font-semibold"><MapPin className="size-4 text-cyan" /> Localidades favoritas</h2>
          <button
            onClick={() => setAddingLocation((v) => !v)}
            className="rounded-xl bg-cyan/12 px-3 py-1.5 text-xs text-cyan transition hover:bg-cyan/25 min-h-[36px]"
          >
            {addingLocation ? 'Fechar' : 'Adicionar'}
          </button>
        </div>
        <div className="mx-1 mb-3 flex flex-wrap gap-2">
          <button
            onClick={() => setLocationDialogOpen(true)}
            className="flex min-h-[40px] items-center gap-2 rounded-xl bg-blue/5 px-4 text-xs font-medium transition  hover:text-cyan"
          >
            <Search className="size-3.5" /> Pesquisar cidade
          </button>
          <button
            onClick={() => setLocationDialogOpen(true)}
            className="flex min-h-[40px] items-center gap-2 rounded-xl bg-blue/5 px-4 text-xs font-medium transition  hover:text-cyan"
          >
            <Navigation className="size-3.5" /> Ativar localização
          </button>
        </div>
        {profile.favoriteLocations.length === 0 && !addingLocation && (
          <p className="text-xs text-atmos px-1">Ainda não tens localidades guardadas.</p>
        )}
        {profile.favoriteLocations.length > 0 && (
          <ul className="flex flex-col gap-1.5 px-1">
            {profile.favoriteLocations.map((loc) => (
              <li key={loc.id} className="flex items-center justify-between rounded-xl bg-blue/4 px-3 py-2">
                <span className="text-xs font-medium">{loc.name}</span>
                <button
                  onClick={() => setProfile({ favoriteLocations: profile.favoriteLocations.filter((l) => l.id !== loc.id) })}
                  aria-label={`Remover ${loc.name}`}
                  className="flex size-8 items-center justify-center rounded-xl text-atmos transition hover:text-critical "
                >
                  <X className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
        )}
        {addingLocation && (
          <div className="mt-2.5 flex flex-wrap gap-2 px-1">
            {QUICK_LOCATIONS.slice(0, 12).map((q) => {
              const already = profile.favoriteLocations.some((l) => l.id === q.id);
              return (
                <button
                  key={q.id}
                  disabled={already}
                  onClick={() =>
                    setProfile({
                      favoriteLocations: [
                        ...profile.favoriteLocations,
                        { id: q.id, name: q.name, latitude: q.latitude, longitude: q.longitude },
                      ],
                    })
                  }
                  className="rounded-xl bg-blue/5 px-3 py-1.5 text-[11px] text-atmos transition  hover:text-cyan disabled:opacity-40  min-h-[32px]"
                >
                  {q.name}
                </button>
              );
            })}
          </div>
        )}
      </section>

      {/* Aparência e instalação */}
      <section className="glass rounded-xl p-4" aria-label="Aparência e aplicação">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-3 px-1">Aparência e aplicação</h2>
        <p className="text-[11px] text-atmos px-1 mb-2">Escolhe o modo de visualização da aplicação.</p>
        <div className="grid grid-cols-3 gap-2 px-1" role="group" aria-label="Modo claro ou escuro">
          {([
            { key: 'light', label: 'Claro', icon: Sun },
            { key: 'dark', label: 'Escuro', icon: Moon },
            { key: 'system', label: 'Automático', icon: Monitor },
          ] as const).map((o) => {
            const Icon = o.icon;
            const active = (theme ?? 'system') === o.key;
            return (
              <button
                key={o.key}
                onClick={() => {
                  setTheme(o.key);
                  setStoreTheme(o.key === 'dark' || (o.key === 'system' && resolvedTheme === 'dark') ? 'dark' : 'light');
                }}
                aria-pressed={active}
                className={`flex min-h-[56px] flex-col items-center justify-center gap-1 rounded-xl px-3 py-2 text-xs font-medium transition ${
                  active ? 'bg-cyan/15 text-cyan' : 'bg-blue/6 text-atmos hover:bg-blue/10 hover:text-foreground'
 }`}
              >
                <Icon className="size-4" />
                {o.label}
                {active && <Check className="size-3" aria-hidden="true" />}
              </button>
            );
          })}
        </div>
        <p className="mt-2 text-[11px] text-atmos px-1">
          «Automático» segue a definição clara/escura do teu telemóvel. A escolha fica guardada neste dispositivo.
        </p>
        <div className="flex flex-wrap items-center gap-2 px-1 mt-4">
          {canInstall && !installed && (
            <button
              onClick={() => void install()}
              className="flex min-h-[40px] items-center gap-2 rounded-xl bg-cyan/15 px-4 text-xs font-medium text-cyan transition hover:bg-cyan/25"
            >
              <Download className="size-4" /> Instalar aplicação
            </button>
          )}
          {installed && (
            <span className="flex items-center gap-1.5 rounded-xl bg-signal/10 px-4 text-xs text-signal min-h-[40px]">
              <Check className="size-4" /> Aplicação instalada
            </span>
          )}
        </div>
        {!canInstall && !installed && (
          <p className="mt-2 text-[11px] text-atmos px-1">
            Para instalar, usa o menu do navegador («Adicionar ao ecrã principal»). A aplicação funciona offline com a última previsão guardada.
          </p>
        )}
      </section>

      {/* Notificações — automáticas sobre alterações climáticas */}
      <section className="glass rounded-xl p-4" aria-label="Notificações">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-2 px-1"><BellRing className="size-4 text-cyan" /> Notificações automáticas</h2>
        <div className="mx-1 rounded-xl bg-blue/4 px-3.5 py-3 mb-2.5">
          <p className="text-xs text-foreground/85 leading-relaxed">
            A aplicação vigia alterações significativas entre atualizações — avisos oficiais novos, saltos de
            temperatura ≥ 3°C, chuva a chegar e rajadas a intensificar-se — e avisa-te com mensagens dentro da app.
          </p>
        </div>
        <div className="mx-1 flex items-center justify-between gap-3 rounded-xl bg-blue/4 px-3.5 py-3">
          <div className="min-w-0">
            <p className="text-xs font-medium">Avisos do navegador</p>
            <p className="text-[11px] text-atmos mt-0.5">
              {profile.browserNotifications
                ? typeof Notification !== 'undefined' && Notification.permission === 'granted'
                  ? 'Ativo — recebes também notificações do sistema.'
                  : 'Ativado, mas falta autorizar no navegador.'
                : 'Desativado — os avisos aparecem apenas dentro da app.'}
            </p>
          </div>
          <button
            role="switch"
            aria-checked={profile.browserNotifications}
            onClick={async () => {
              const next = !profile.browserNotifications;
              if (next && typeof Notification !== 'undefined' && Notification.permission !== 'granted') {
                const perm = await Notification.requestPermission();
                if (perm !== 'granted') {
                  setProfile({ browserNotifications: false });
                  toast.error('Autorização de notificações recusada pelo navegador.');
                  return;
                }
                toast.success('Notificações do navegador ativas.');
              } else if (next) {
                toast.success('Notificações do navegador ativas.');
              }
              setProfile({ browserNotifications: next });
            }}
            className={`relative h-7 w-12 shrink-0 rounded-xl transition ${
              profile.browserNotifications ? ' bg-cyan/25' : ' bg-blue/8'
 }`}
            aria-label="Ativar avisos do navegador"
          >
            <span
              className={`absolute top-1/2 size-5 -translate-y-1/2 rounded-xl transition-all ${
                profile.browserNotifications ? 'left-6 bg-cyan' : 'left-1 bg-atmos'
 }`}
            />
          </button>
        </div>
      </section>

      {/* Notificações push — Web Push (VAPID) contra o alerts-service */}
      <PushNotificationsSection />

      {/* Dados e infraestrutura */}
      <section className="glass rounded-xl p-4" aria-label="Fontes de dados">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-2 px-1"><Server className="size-4 text-cyan" /> Fontes de dados</h2>
        <ul className="mx-1 flex flex-col gap-1.5 text-[11px] text-foreground/80">
          <li className="rounded-xl bg-blue/4 px-3 py-2">
            <span className="font-medium">Open-Meteo</span> — previsão, qualidade do ar e geocodificação · cache de 10 min
          </li>
          <li className="rounded-xl bg-blue/4 px-3 py-2">
            <span className="font-medium">IPMA</span> — avisos meteorológicos oficiais (cores oficiais preservadas)
          </li>
          <li className="rounded-xl bg-blue/4 px-3 py-2">
            <span className="font-medium">RainViewer</span> — radar de precipitação animado
          </li>
          <li className="rounded-xl bg-blue/4 px-3 py-2">
            <span className="font-medium">alerts-service</span> — serviço dedicado na porta 3003 · polling IPMA a cada 5 min · Web Push VAPID + SSE
          </li>
        </ul>
      </section>

      {/* Repor dados */}
      <section className="glass rounded-xl p-4" aria-label="Dados do dispositivo">
        <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-3 px-1"><Droplets className="size-4 text-critical" /> Dados do dispositivo</h2>
        <button
          onClick={() => {
            resetProfile();
            try {
              localStorage.removeItem('stormwatch-chat-history');
              localStorage.removeItem('stormwatch-app');
            } catch {
              // ignore
            }
            toast.success('Dados locais repostos. A configuração inicial será mostrada de novo.');
            setTimeout(() => window.location.reload(), 600);
          }}
          className="mx-1 flex min-h-[44px] items-center gap-2 rounded-xl bg-critical/10 px-4 text-xs font-medium text-critical transition hover:bg-critical/20"
        >
          <Trash2 className="size-4" /> Repor perfil e histórico
        </button>
        <p className="mt-2 text-[10px] text-atmos px-1">
          Remove o perfil, o histórico do STORM AI e as preferências guardadas neste dispositivo.
        </p>
      </section>
    </div>
  );
}

export function PerfilTab() {
  const { profile } = useProfileContext();
  return (
    <div className="flex flex-col gap-4">
      <div className="glass rounded-xl p-4">
        <h1 className="font-display text-lg font-bold tracking-tight">Definições</h1>
        <p className="text-xs text-atmos mt-0.5">
          Personaliza a STORMWATCH — as respostas, os avisos e as recomendações adaptam-se aos teus valores.
        </p>
      </div>
      {profile.onboardingDone ? <SettingsView /> : <Onboarding />}
    </div>
  );
}
