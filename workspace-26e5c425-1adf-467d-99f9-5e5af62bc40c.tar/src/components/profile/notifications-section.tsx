'use client';

/**
 * Secção «Notificações push» das Definições — substitui o aviso estático por
 * uma implementação real de Web Push (VAPID) contra o alerts-service:
 *  · estado do serviço (porta 3003) e último polling do IPMA;
 *  · «Ativar notificações» → permissão + subscrição + notificação de teste;
 *  · «Enviar notificação de teste» e «Desativar»;
 *  · estados explícitos: sem chaves VAPID, serviço offline, iOS sem PWA
 *    instalada, permissão recusada — nunca falha em silêncio.
 */
import { BellRing, BellOff, CheckCircle2, Send, XCircle } from 'lucide-react';
import { usePushNotifications } from '@/hooks/use-push';
import { formatClockTime } from '@/lib/format';

export function PushNotificationsSection() {
  const push = usePushNotifications();
  const status = push.status;

  return (
    <section className="glass rounded-xl p-4" aria-label="Notificações push">
      <h2 className="flex items-center gap-2 font-display text-sm font-semibold mb-2 px-1">
        <BellRing className="size-4 text-cyan" /> Notificações push
      </h2>
      <p className="text-[11px] leading-relaxed text-atmos px-1 mb-3">
        Recebe avisos oficiais novos do IPMA e alertas críticos fora da app. O dispositivo fica subscrito no serviço de
        alertas (porta 3003), que polla o IPMA a cada 5 minutos.
      </p>

      {/* Estado do serviço */}
      <div className="mx-1 flex items-start justify-between gap-3 rounded-xl bg-blue/4 px-3.5 py-3 mb-2">
        <div className="min-w-0">
          <p className="text-xs font-medium">Serviço de alertas</p>
          <p className="text-[11px] text-atmos mt-0.5">
            {push.serviceLoading
              ? 'A verificar ligação…'
              : push.serviceOnline && status
                ? `Ligado (porta 3003) · ${status.activeCount} aviso(s) IPMA ativo(s)${
                    status.lastPollAt ? ` · último polling ${formatClockTime(Date.parse(status.lastPollAt))}` : ''
                  }`
                : 'Indisponível — sem ele as notificações push não podem ser ativadas.'}
          </p>
        </div>
        <span
          className={`mt-1 size-2.5 shrink-0 rounded-xl ${push.serviceOnline ? 'bg-signal' : 'bg-amber'}`}
          aria-hidden="true"
        />
      </div>

      {/* Sem chaves VAPID — modo «preparado, não configurado» */}
      {push.serviceOnline && status && !status.pushConfigured && (
        <div className="mx-1 mt-2 rounded-xl border-l-[3px] border-l-amber bg-amber/8 px-3.5 py-2.5">
          <p className="text-xs text-amber font-medium">Notificações push não configuradas (faltam as chaves VAPID)</p>
          <p className="mt-1 text-[11px] leading-relaxed text-foreground/75">
            A arquitetura está pronta — falta gerar as chaves e colocá-las no <code>.env</code> do
            alerts-service (<code>mini-services/alerts-service/README.md</code>). Os avisos dentro da app e do navegador
            continuam a funcionar sem configuração adicional.
          </p>
        </div>
      )}

      {/* iOS sem PWA instalada */}
      {push.iosNeedsInstall && (
        <div className="mx-1 mt-2 rounded-xl border-l-[3px] border-l-amber bg-amber/8 px-3.5 py-2.5">
          <p className="text-xs text-amber font-medium">iPhone: instala a app primeiro</p>
          <p className="mt-1 text-[11px] leading-relaxed text-foreground/75">
            O iOS só entrega notificações push em apps instaladas no ecrã principal (Safari → Partilhar → Adicionar ao
            Ecrã Inicial, iOS 16.4+) e abertas pelo ícone pelo menos uma vez.
          </p>
        </div>
      )}

      {/* Permissão recusada */}
      {push.permission === 'denied' && (
        <div className="mx-1 mt-2 flex items-start gap-2 rounded-xl border-l-[3px] border-l-critical bg-critical/8 px-3.5 py-2.5">
          <XCircle className="size-4 text-critical shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed text-foreground/85">
            Autorização de notificações recusada neste navegador. Para receber avisos, permite as notificações para este
            site nas definições do navegador (ou do iOS, para PWAs instaladas).
          </p>
        </div>
      )}

      {/* Ações */}
      {push.serviceOnline && status?.pushConfigured && !push.iosNeedsInstall && (
        <div className="mx-1 mt-2.5 flex flex-wrap items-center gap-2">
          {!push.subscribed ? (
            <button
              onClick={() => void push.enable()}
              disabled={push.busy || push.checking || push.permission === 'denied' || !push.supported}
              className="flex min-h-[44px] items-center gap-2 rounded-xl bg-cyan/15 px-4 text-sm font-medium text-cyan transition hover:bg-cyan/25 disabled:opacity-40 disabled:hover:bg-cyan/15"
            >
              <BellRing className="size-4" />
              {push.busy ? 'A ativar…' : 'Ativar notificações'}
            </button>
          ) : (
            <>
              <span className="flex min-h-[40px] items-center gap-2 rounded-xl bg-signal/10 px-4 text-xs text-signal">
                <CheckCircle2 className="size-4" /> Notificações push ativas neste dispositivo
              </span>
              <button
                onClick={() => void push.sendTest()}
                className="flex min-h-[40px] items-center gap-2 rounded-xl bg-blue/5 px-4 text-xs font-medium transition  hover:text-cyan"
              >
                <Send className="size-3.5" /> Enviar notificação de teste
              </button>
              <button
                onClick={() => void push.disable()}
                disabled={push.busy}
                className="flex min-h-[40px] items-center gap-2 rounded-xl bg-blue/5 px-4 text-xs text-atmos transition hover:text-critical  disabled:opacity-40"
              >
                <BellOff className="size-3.5" /> Desativar
              </button>
            </>
          )}
        </div>
      )}

      {!push.supported && (
        <p className="mx-1 mt-2 text-[11px] text-atmos px-1">
          Este navegador não suporta notificações push (PushManager indisponível). Experimenta o Safari no iPhone
          (app instalada) ou um navegador de computador atualizado.
        </p>
      )}

      {/* Mensagem de sucesso é apresentada pelo toast do hook (sonner). */}
      <p className="mx-1 mt-2 text-[10px] text-atmos px-1" role="note">
        Ao ativar, enviamos de imediato uma notificação de teste: «STORMWATCH — Notificações ativadas».
      </p>
    </section>
  );
}
