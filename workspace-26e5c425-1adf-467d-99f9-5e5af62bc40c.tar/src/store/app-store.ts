'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type TabKey = 'inicio' | 'alertas' | 'assistente' | 'radar' | 'comunidade' | 'planeador' | 'perfil';

export interface SelectedLocation {
  name: string;
  admin: string | null;
  latitude: number;
  longitude: number;
  /** true quando a localização vem do GPS do dispositivo. */
  fromGeolocation: boolean;
}

const DEFAULT_LOCATION: SelectedLocation = {
  name: 'Lisboa',
  admin: 'Grande Lisboa',
  latitude: 38.7223,
  longitude: -9.1393,
  fromGeolocation: false,
};

interface AppState {
  activeTab: TabKey;
  location: SelectedLocation;
  theme: 'dark' | 'light';
  /** Diálogo de localização partilhado (TopBar + Definições). Não é persistido. */
  locationDialogOpen: boolean;
  setActiveTab: (tab: TabKey) => void;
  setLocation: (loc: SelectedLocation) => void;
  setTheme: (theme: 'dark' | 'light') => void;
  setLocationDialogOpen: (open: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      activeTab: 'inicio',
      location: DEFAULT_LOCATION,
      theme: 'dark',
      locationDialogOpen: false,
      setActiveTab: (activeTab) => set({ activeTab }),
      setLocation: (location) => set({ location }),
      setTheme: (theme) => set({ theme }),
      setLocationDialogOpen: (locationDialogOpen) => set({ locationDialogOpen }),
    }),
    {
      name: 'stormwatch-app',
      partialize: (state) => ({
        activeTab: state.activeTab,
        location: state.location,
        theme: state.theme,
      }),
    },
  ),
);
