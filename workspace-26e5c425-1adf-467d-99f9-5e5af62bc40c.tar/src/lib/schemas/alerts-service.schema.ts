/** Schemas Zod para as respostas do alerts-service (porta 3003, via gateway). */
import { z } from 'zod';

/** Aviso IPMA normalizado — idêntico ao modelo interno IpmaWarning. */
export const serviceWarningSchema = z.object({
  id: z.string(),
  level: z.enum(['yellow', 'orange', 'red']),
  area: z.string(),
  phenomen: z.string(),
  phenomenLabel: z.string(),
  description: z.string(),
  start: z.string(),
  end: z.string(),
});

export type ServiceWarning = z.infer<typeof serviceWarningSchema>;

export const serviceStatusSchema = z.object({
  ok: z.boolean(),
  service: z.literal('alerts-service'),
  pushConfigured: z.boolean(),
  vapidPublicKey: z.string().nullable(),
  subscriptions: z.number(),
  streamClients: z.number().optional(),
  activeCount: z.number(),
  lastPollAt: z.string().nullable(),
  pollingError: z.string().nullable().optional(),
  pollIntervalMs: z.number(),
});

export type ServiceStatus = z.infer<typeof serviceStatusSchema>;

export const serviceAlertsEnvelopeSchema = z.object({
  ok: z.boolean(),
  alerts: z.array(serviceWarningSchema),
  fetchedAt: z.string().nullable(),
  pollingError: z.string().nullable().optional(),
});

export const servicePollResponseSchema = z.object({
  ok: z.boolean(),
  activeCount: z.number(),
  lastPollAt: z.string().nullable(),
});

export const pushSubscribeResponseSchema = z.object({
  ok: z.boolean(),
  subscriptions: z.number(),
});

export const pushUnsubscribeResponseSchema = z.object({
  ok: z.boolean(),
  removed: z.number(),
  subscriptions: z.number(),
});

export const pushTestResponseSchema = z.object({
  ok: z.boolean(),
  sent: z.number().optional(),
  failures: z.number().optional(),
});

/** Erro estruturado do serviço (respostas 4xx/5xx). */
export const serviceErrorSchema = z.object({
  ok: z.literal(false),
  error: z.string(),
});
