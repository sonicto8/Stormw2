/** Schemas Zod dos payloads internos servidos pelos route handlers. */
import { z } from 'zod';
import { reportTypes } from '@/lib/schemas/report.schema';

export const meteoconKeySchema = z.enum([
  'clear-day', 'clear-night', 'partly-day', 'partly-night', 'overcast', 'fog',
  'drizzle', 'rain', 'heavy-rain', 'freezing-rain', 'snow', 'thunder', 'thunder-hail',
]);

export const dataSourceSchema = z.enum(['network', 'cache-server', 'cache-offline']);

export const currentWeatherSchema = z.object({
  time: z.string(),
  temperature: z.number(),
  apparentTemperature: z.number(),
  humidity: z.number().nullable(),
  isDay: z.boolean(),
  precipitation: z.number(),
  weatherCode: z.number(),
  weatherLabel: z.string(),
  meteocon: meteoconKeySchema,
  cloudCover: z.number().nullable(),
  pressureMsl: z.number().nullable(),
  visibility: z.number().nullable(),
  windSpeed: z.number(),
  windDirection: z.number().nullable(),
  windGusts: z.number(),
  uvIndex: z.number().nullable(),
});

export const hourlyPointSchema = z.object({
  time: z.string(),
  temperature: z.number(),
  apparentTemperature: z.number(),
  precipitationProbability: z.number().nullable(),
  precipitation: z.number(),
  weatherCode: z.number(),
  weatherLabel: z.string(),
  meteocon: meteoconKeySchema,
  humidity: z.number().nullable(),
  visibility: z.number().nullable(),
  windSpeed: z.number(),
  windGusts: z.number(),
  cloudCover: z.number().nullable(),
  uvIndex: z.number().nullable(),
  isDay: z.boolean(),
});

export const minutelyPointSchema = z.object({
  time: z.string(),
  precipitation: z.number().nullable(),
  weatherCode: z.number().nullable(),
});

export const dailyPointSchema = z.object({
  date: z.string(),
  weatherCode: z.number(),
  weatherLabel: z.string(),
  meteocon: meteoconKeySchema,
  tempMax: z.number(),
  tempMin: z.number(),
  tempMean: z.number().nullable(),
  apparentMax: z.number().nullable(),
  apparentMin: z.number().nullable(),
  precipitationSum: z.number(),
  precipitationHours: z.number().nullable(),
  precipitationProbabilityMax: z.number().nullable(),
  windSpeedMax: z.number().nullable(),
  windSpeedMean: z.number().nullable(),
  windGustsMax: z.number().nullable(),
  humidityMean: z.number().nullable(),
  cloudCoverMean: z.number().nullable(),
  uvIndexMax: z.number().nullable(),
  sunrise: z.string().nullable(),
  sunset: z.string().nullable(),
});

export const forecastBundleSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
  elevation: z.number().nullable(),
  timezone: z.string(),
  current: currentWeatherSchema,
  hourly: z.array(hourlyPointSchema),
  minutely15: z.array(minutelyPointSchema),
  daily: z.array(dailyPointSchema),
  historyDaily: z.array(dailyPointSchema).default([]),
  fetchedAt: z.number(),
  source: dataSourceSchema,
});

export const forecastApiEnvelopeSchema = z.object({
  data: forecastBundleSchema,
  notice: z.string().nullable(),
});

export const airQualityBundleSchema = z.object({
  time: z.string(),
  europeanAqi: z.number().nullable(),
  pm10: z.number().nullable(),
  pm25: z.number().nullable(),
  ozone: z.number().nullable(),
  no2: z.number().nullable(),
  so2: z.number().nullable(),
  fetchedAt: z.number(),
  source: dataSourceSchema,
});

export const airQualityApiEnvelopeSchema = z.object({
  data: airQualityBundleSchema,
  notice: z.string().nullable(),
});

export const ipmaLevelSchema = z.enum(['yellow', 'orange', 'red']);

export const ipmaWarningInternalSchema = z.object({
  id: z.string(),
  level: ipmaLevelSchema,
  area: z.string(),
  phenomen: z.string(),
  phenomenLabel: z.string(),
  description: z.string(),
  start: z.string(),
  end: z.string(),
});

export const ipmaApiEnvelopeSchema = z.object({
  data: z.array(ipmaWarningInternalSchema),
  notice: z.string().nullable(),
  fetchedAt: z.number(),
});

export const radarFrameSchema = z.object({
  time: z.number(),
  path: z.string(),
  kind: z.enum(['past', 'nowcast']),
});

export const radarBundleSchema = z.object({
  host: z.string(),
  generated: z.number(),
  frames: z.array(radarFrameSchema),
  fetchedAt: z.number(),
});

export const radarApiEnvelopeSchema = z.object({
  data: radarBundleSchema,
  notice: z.string().nullable(),
});

export const gridPointInternalSchema = z.object({
  id: z.string(),
  name: z.string(),
  admin: z.string(),
  latitude: z.number(),
  longitude: z.number(),
  temperature: z.number(),
  weatherCode: z.number(),
  weatherLabel: z.string(),
  meteocon: meteoconKeySchema,
  cloudCover: z.number().nullable(),
  windSpeed: z.number(),
  windDirection: z.number().nullable(),
  windGusts: z.number(),
  fetchedAt: z.number(),
});

export const gridApiEnvelopeSchema = z.object({
  data: z.array(gridPointInternalSchema),
  notice: z.string().nullable(),
});

export const geocodingPlaceSchema = z.object({
  id: z.number(),
  name: z.string(),
  latitude: z.number(),
  longitude: z.number(),
  country: z.string().nullable(),
  admin1: z.string().nullable(),
  timezone: z.string().nullable(),
});

export const activityReportApiSchema = z.object({
  id: z.string(),
  type: z.enum(reportTypes),
  note: z.string().nullable(),
  lat: z.number(),
  lon: z.number(),
  placeName: z.string().nullable(),
  createdAt: z.string(),
  confirmations: z.number(),
  confirmedBy: z.array(z.string()),
});

export const reportsApiEnvelopeSchema = z.object({
  data: z.array(activityReportApiSchema),
  rateLimitedUntil: z.number().nullable().nullable().optional(),
});

export const reportPostResponseSchema = z.object({
  data: activityReportApiSchema,
  notice: z.string().nullable(),
});
