/**
 * Schemas Zod das respostas Open-Meteo (Forecast + Geocoding).
 * Os arrays paralelos são validados explicitamente: cada variável pedida é
 * um array (nulo permitido por posição) e o adaptador cruza os comprimentos.
 */
import { z } from 'zod';

/** Números que podem ser nulas (dado em falta) — obrigatório em open-meteo. */
export const nullableNumber = z.number().nullable();

/** Objeto `current` do endpoint /v1/forecast. */
export const openMeteoCurrentSchema = z.object({
  time: z.string(),
  interval: z.number().optional(),
  temperature_2m: z.number(),
  relative_humidity_2m: nullableNumber.optional(),
  apparent_temperature: z.number(),
  is_day: z.number(),
  precipitation: z.number(),
  weather_code: z.number(),
  cloud_cover: nullableNumber.optional(),
  pressure_msl: nullableNumber.optional(),
  wind_speed_10m: z.number(),
  wind_direction_10m: nullableNumber.optional(),
  wind_gusts_10m: z.number(),
  uv_index: nullableNumber.optional(),
});

export const openMeteoHourlySchema = z.object({
  time: z.array(z.string()).optional(),
  temperature_2m: z.array(nullableNumber).optional(),
  relative_humidity_2m: z.array(nullableNumber).optional(),
  apparent_temperature: z.array(nullableNumber).optional(),
  precipitation_probability: z.array(nullableNumber).optional(),
  precipitation: z.array(nullableNumber).optional(),
  weather_code: z.array(nullableNumber).optional(),
  cloud_cover: z.array(nullableNumber).optional(),
  visibility: z.array(nullableNumber).optional(),
  wind_speed_10m: z.array(nullableNumber).optional(),
  wind_gusts_10m: z.array(nullableNumber).optional(),
  uv_index: z.array(nullableNumber).optional(),
  is_day: z.array(nullableNumber).optional(),
});

export const openMeteoMinutelySchema = z.object({
  time: z.array(z.string()).optional(),
  precipitation: z.array(nullableNumber).optional(),
  weather_code: z.array(nullableNumber).optional(),
});

export const openMeteoDailySchema = z.object({
  time: z.array(z.string()).optional(),
  weather_code: z.array(nullableNumber).optional(),
  temperature_2m_max: z.array(nullableNumber).optional(),
  temperature_2m_min: z.array(nullableNumber).optional(),
  temperature_2m_mean: z.array(nullableNumber).optional(),
  apparent_temperature_max: z.array(nullableNumber).optional(),
  apparent_temperature_min: z.array(nullableNumber).optional(),
  precipitation_sum: z.array(nullableNumber).optional(),
  precipitation_hours: z.array(nullableNumber).optional(),
  precipitation_probability_max: z.array(nullableNumber).optional(),
  wind_speed_10m_max: z.array(nullableNumber).optional(),
  wind_speed_10m_mean: z.array(nullableNumber).optional(),
  wind_gusts_10m_max: z.array(nullableNumber).optional(),
  relative_humidity_2m_mean: z.array(nullableNumber).optional(),
  cloud_cover_mean: z.array(nullableNumber).optional(),
  uv_index_max: z.array(nullableNumber).optional(),
  sunrise: z.array(z.string()).optional(),
  sunset: z.array(z.string()).optional(),
});

export const openMeteoForecastSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
  elevation: nullableNumber.optional(),
  timezone: z.string(),
  utc_offset_seconds: z.number().optional(),
  current: openMeteoCurrentSchema,
  hourly: openMeteoHourlySchema.optional(),
  minutely_15: openMeteoMinutelySchema.optional(),
  daily: openMeteoDailySchema.optional(),
});

export const openMeteoForecastErrorSchema = z.object({
  error: z.literal(true),
  reason: z.string().optional(),
});

/** Resposta do endpoint /v1/search (geocoding). */
export const openMeteoGeocodingSchema = z.object({
  results: z
    .array(
      z.object({
        id: z.number(),
        name: z.string(),
        latitude: z.number(),
        longitude: z.number(),
        country: z.string().nullable().optional(),
        admin1: z.string().nullable().optional(),
        timezone: z.string().nullable().optional(),
      }),
    )
    .optional(),
});

/**
 * Pedido em lote do /v1/forecast (várias coordenadas): a API devolve um array
 * de respostas, uma por local, mantendo a ordem do pedido. O `current` do
 * pedido em lote é mais leve (só as variáveis pedidas para os mapas).
 */
export const openMeteoGridCurrentSchema = z.object({
  time: z.string(),
  interval: z.number().optional(),
  temperature_2m: z.number(),
  is_day: z.number().optional(),
  weather_code: z.number(),
  cloud_cover: nullableNumber.optional(),
  wind_speed_10m: z.number(),
  wind_direction_10m: nullableNumber.optional(),
  wind_gusts_10m: z.number(),
});

export const openMeteoGridLocationSchema = z.object({
  latitude: z.number(),
  longitude: z.number(),
  elevation: nullableNumber.optional(),
  timezone: z.string(),
  current: openMeteoGridCurrentSchema,
});

export const openMeteoGridSchema = z.array(openMeteoGridLocationSchema);

export type OpenMeteoForecastResponse = z.infer<typeof openMeteoForecastSchema>;
export type OpenMeteoGeocodingResponse = z.infer<typeof openMeteoGeocodingSchema>;
