/** Schemas Zod para a API de qualidade do ar Open-Meteo. */
import { z } from 'zod';

export const airQualitySchema = z.object({
  time: z.string().optional(),
  current: z
    .object({
      time: z.string(),
      interval: z.number().optional(),
      european_aqi: z.number().nullable().optional(),
      pm10: z.number().nullable().optional(),
      pm2_5: z.number().nullable().optional(),
      ozone: z.number().nullable().optional(),
      nitrogen_dioxide: z.number().nullable().optional(),
      sulphur_dioxide: z.number().nullable().optional(),
    })
    .optional(),
});

export type AirQualityResponse = z.infer<typeof airQualitySchema>;
