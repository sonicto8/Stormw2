/** Schemas Zod para a API de avisos oficiais do IPMA (warnings_www.json). */
import { z } from 'zod';

export const ipmaLevelSchema = z.enum(['yellow', 'orange', 'red']);

/**
 * Entrada crua do IPMA (formato real de warnings_www.json):
 * níveis são y/o/r, tipos são awarenessTypeId + descrições PT/EN.
 */
export const ipmaRawWarningSchema = z
  .object({
    areaId: z.string().optional(),
    areaID: z.string().optional(),
    area: z.string().optional(),
    awarenessTypeId: z.number().optional(),
    awarenessTypeDescription: z.string().optional(),
    awarenessTypeDescriptionPT: z.string().optional(),
    awarenessLevelId: z.string().optional(),
    awarenessLevelDescriptionPT: z.string().optional(),
    text: z.string().optional(),
    textPT: z.string().optional(),
    textEN: z.string().optional(),
    startTime: z.string().optional(),
    endTime: z.string().optional(),
    start: z.string().optional(),
    end: z.string().optional(),
    id: z.union([z.string(), z.number()]).optional(),
    level: ipmaLevelSchema.optional(),
    description: z.string().optional(),
    phenomen: z.string().optional(),
  })
  .refine(
    (w) =>
      // Aceita formato cru (awarenessLevelId) ou já normalizado (level).
      w.awarenessLevelId !== undefined || w.level !== undefined,
    { message: 'Entrada de aviso sem nível reconhecível' },
  );

export const ipmaWarningsSchema = z.object({
  forecast: z.array(ipmaRawWarningSchema).optional(),
});

export type IpmaRawWarning = z.infer<typeof ipmaRawWarningSchema>;
export type IpmaWarningsResponse = z.infer<typeof ipmaWarningsSchema>;
export type IpmaLevelValue = z.infer<typeof ipmaLevelSchema>;
