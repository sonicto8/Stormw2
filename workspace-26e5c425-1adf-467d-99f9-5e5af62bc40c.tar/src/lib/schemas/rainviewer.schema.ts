/** Schemas Zod para a API pública do RainViewer. */
import { z } from 'zod';

const frameSchema = z.object({
  time: z.number(),
  path: z.string(),
});

export const rainViewerSchema = z.object({
  version: z.string().optional(),
  generated: z.number().optional(),
  host: z.string().optional(),
  radar: z
    .object({
      past: z.array(frameSchema).optional(),
      nowcast: z.array(frameSchema).optional(),
    })
    .optional(),
});

export type RainViewerResponse = z.infer<typeof rainViewerSchema>;
