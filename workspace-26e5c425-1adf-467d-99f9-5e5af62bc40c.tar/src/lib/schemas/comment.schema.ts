/** Schemas Zod dos comentários da comunidade em tempo real. */
import { z } from 'zod';

export const createCommentSchema = z.object({
  deviceId: z.string().min(8).max(64),
  /** Alcunha pública opcional; «Anónimo» quando omitida. */
  nickname: z.string().trim().max(24).optional().nullable(),
  message: z
    .string()
    .trim()
    .min(1, 'A mensagem não pode estar vazia')
    .max(280, 'Máximo de 280 caracteres'),
  lat: z.number().min(30).max(46).optional().nullable(),
  lon: z.number().min(-33).max(-5).optional().nullable(),
  placeName: z.string().trim().max(80).optional().nullable(),
  /** Contexto meteorológico real no momento da publicação (única finalidade: exibição). */
  weatherLabel: z.string().trim().max(48).optional().nullable(),
  temperature: z.number().min(-60).max(60).optional().nullable(),
});

export const commentResponseSchema = z.object({
  id: z.string(),
  nickname: z.string(),
  message: z.string(),
  lat: z.number().nullable(),
  lon: z.number().nullable(),
  placeName: z.string().nullable(),
  weatherLabel: z.string().nullable(),
  temperature: z.number().nullable(),
  createdAt: z.string(),
  /** true quando o comentário foi publicado por este dispositivo. */
  mine: z.boolean().optional(),
});

export type CreateCommentInput = z.infer<typeof createCommentSchema>;
export type CommentResponse = z.infer<typeof commentResponseSchema>;
