/** Schemas Zod para reportes colaborativos e perfil de utilizador. */
import { z } from 'zod';

export const reportTypes = [
  'rain-heavy',
  'flood',
  'hail',
  'fog',
  'extreme-wind',
  'thunderstorm',
] as const;

export type ReportTypeValue = (typeof reportTypes)[number];

export const createReportSchema = z.object({
  deviceId: z.string().min(8).max(64),
  type: z.enum(reportTypes),
  note: z.string().max(240).optional().nullable(),
  lat: z.number().min(30).max(46),
  lon: z.number().min(-33).max(-5),
  placeName: z.string().max(80).optional().nullable(),
});

export const confirmReportSchema = z.object({
  deviceId: z.string().min(8).max(64),
});

export const reportResponseSchema = z.object({
  id: z.string(),
  type: z.enum(reportTypes),
  note: z.string().nullable().optional(),
  lat: z.number(),
  lon: z.number(),
  placeName: z.string().nullable().optional(),
  createdAt: z.string(),
  confirmations: z.number(),
  confirmedBy: z.array(z.string()).optional().default([]),
});

export const reportsListSchema = z.array(reportResponseSchema);

/** Perfil meteorológico do utilizador (secção 12 da especificação). */
export const sensitivitySchema = z.number().int().min(1).max(5);

/** Contacto de emergência: nome + número de telemóvel (validação pt-PT flexível). */
export const emergencyContactSchema = z.object({
  id: z.string().min(4).max(64),
  name: z.string().trim().min(1, 'O nome é obrigatório').max(40),
  phone: z
    .string()
    .trim()
    .regex(/^[+0-9][0-9\s-]{7,19}$/, 'Número inválido — usa 9 dígitos ou formato internacional'),
});

export const profileSchema = z.object({
  coldSensitivity: sensitivitySchema,
  heatSensitivity: sensitivitySchema,
  favoriteActivities: z.array(z.string()).max(12),
  alertTypes: z.array(z.string()).max(12),
  temperatureUnit: z.enum(['celsius', 'fahrenheit']),
  windUnit: z.enum(['kmh', 'ms']),
  favoriteLocations: z
    .array(
      z.object({
        id: z.string(),
        name: z.string(),
        latitude: z.number(),
        longitude: z.number(),
      }),
    )
    .max(8),
  /** Máximo 2 contactos de emergência para partilha WhatsApp. */
  emergencyContacts: z.array(emergencyContactSchema).max(2).default([]),
  /** Notificações locais do navegador sobre alterações climáticas. */
  browserNotifications: z.boolean().default(false),
  onboardingDone: z.boolean(),
});

export type EmergencyContact = z.infer<typeof emergencyContactSchema>;
export type Profile = z.infer<typeof profileSchema>;

export const defaultProfile: Profile = {
  coldSensitivity: 3,
  heatSensitivity: 3,
  favoriteActivities: ['running', 'walking'],
  alertTypes: ['rain', 'thunderstorm', 'wind', 'heat', 'cold', 'air'],
  temperatureUnit: 'celsius',
  windUnit: 'kmh',
  favoriteLocations: [],
  emergencyContacts: [],
  browserNotifications: false,
  onboardingDone: false,
};
