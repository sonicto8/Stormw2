/**
 * STORMWATCH — Modelos internos tipados.
 * Estes modelos são o contrato único da aplicação; os adaptadores convertem
 * as respostas externas (Open-Meteo, IPMA, RainViewer) para estas formas.
 */

/** Chave de cada meteocon animado do sistema de design. */
export type MeteoconKey =
  | 'clear-day'
  | 'clear-night'
  | 'partly-day'
  | 'partly-night'
  | 'overcast'
  | 'fog'
  | 'drizzle'
  | 'rain'
  | 'heavy-rain'
  | 'freezing-rain'
  | 'snow'
  | 'thunder'
  | 'thunder-hail';

export type WeatherDataSource = 'network' | 'cache-server' | 'cache-offline';

export interface CurrentWeather {
  /** ISO local devolvido pela API. */
  time: string;
  temperature: number;
  apparentTemperature: number;
  humidity: number | null;
  isDay: boolean;
  precipitation: number;
  weatherCode: number;
  weatherLabel: string;
  meteocon: MeteoconKey;
  cloudCover: number | null;
  pressureMsl: number | null;
  /** Visibilidade horizontal em metros (da hora mais próxima). */
  visibility: number | null;
  windSpeed: number;
  windDirection: number | null;
  windGusts: number;
  uvIndex: number | null;
}

export interface HourlyPoint {
  time: string;
  temperature: number;
  apparentTemperature: number;
  precipitationProbability: number | null;
  precipitation: number;
  weatherCode: number;
  weatherLabel: string;
  meteocon: MeteoconKey;
  humidity: number | null;
  /** Visibilidade horizontal em metros. */
  visibility: number | null;
  windSpeed: number;
  windGusts: number;
  cloudCover: number | null;
  uvIndex: number | null;
  isDay: boolean;
}

export interface MinutelyPoint {
  time: string;
  precipitation: number | null;
  weatherCode: number | null;
}

export interface DailyPoint {
  date: string;
  weatherCode: number;
  weatherLabel: string;
  meteocon: MeteoconKey;
  tempMax: number;
  tempMin: number;
  tempMean: number | null;
  apparentMax: number | null;
  apparentMin: number | null;
  precipitationSum: number;
  precipitationHours: number | null;
  precipitationProbabilityMax: number | null;
  windSpeedMax: number | null;
  windSpeedMean: number | null;
  windGustsMax: number | null;
  humidityMean: number | null;
  cloudCoverMean: number | null;
  uvIndexMax: number | null;
  sunrise: string | null;
  sunset: string | null;
}

export interface ForecastBundle {
  latitude: number;
  longitude: number;
  elevation: number | null;
  timezone: string;
  current: CurrentWeather;
  hourly: HourlyPoint[];
  minutely15: MinutelyPoint[];
  daily: DailyPoint[];
  /** Histórico: dias anteriores a hoje (quando a fonte devolve past_days). */
  historyDaily: DailyPoint[];
  fetchedAt: number;
  source: WeatherDataSource;
}

export interface AirQualityBundle {
  time: string;
  europeanAqi: number | null;
  pm10: number | null;
  pm25: number | null;
  ozone: number | null;
  no2: number | null;
  so2: number | null;
  fetchedAt: number;
  source: WeatherDataSource;
}

export interface GeocodingPlace {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  country: string | null;
  admin1: string | null;
  timezone: string | null;
}

export type IpmaLevel = 'yellow' | 'orange' | 'red';

export interface IpmaWarning {
  id: string;
  level: IpmaLevel;
  area: string;
  phenomen: string;
  phenomenLabel: string;
  description: string;
  start: string;
  end: string;
}

export type RadarFrameKind = 'past' | 'nowcast';

export interface RadarFrame {
  time: number;
  path: string;
  kind: RadarFrameKind;
}

export interface RadarBundle {
  host: string;
  generated: number;
  frames: RadarFrame[];
  fetchedAt: number;
}

/** Ponto da grelha de referência usada nos mapas de temperatura, vento e nuvens. */
export interface GridPoint {
  id: string;
  name: string;
  admin: string;
  latitude: number;
  longitude: number;
  temperature: number;
  weatherCode: number;
  weatherLabel: string;
  meteocon: MeteoconKey;
  cloudCover: number | null;
  windSpeed: number;
  windDirection: number | null;
  windGusts: number;
  fetchedAt: number;
}

export type ReportType =
  | 'rain-heavy'
  | 'flood'
  | 'hail'
  | 'fog'
  | 'extreme-wind'
  | 'thunderstorm';

export interface ActivityReport {
  id: string;
  type: ReportType;
  note: string | null;
  lat: number;
  lon: number;
  placeName: string | null;
  createdAt: string;
  confirmations: number;
  confirmedBy: string[];
}

export type ActivityKey =
  | 'running'
  | 'walking'
  | 'cycling'
  | 'photography'
  | 'football'
  | 'beach';

export interface ActivityScore {
  key: ActivityKey;
  label: string;
  score: number;
  classification: string;
  bestHour: string | null;
  justification: string;
  sufficientData: boolean;
}

export interface ActivityIndex {
  key: ActivityKey;
  label: string;
  score: number;
  classification: string;
  bestHour: string | null;
  justification: string;
  perHour: Array<{ time: string; score: number }>;
  /** false quando campos usados no cálculo estão indisponíveis. */
  sufficientData: boolean;
}

export type AlertSeverity = 'info' | 'warning' | 'critical';

export type AlertOrigin = 'internal' | 'ipma';

export interface WeatherAlert {
  id: string;
  origin: AlertOrigin;
  severity: AlertSeverity;
  /** Cor oficial do IPMA quando origin === 'ipma'; caso interno, null. */
  officialLevel: IpmaLevel | null;
  title: string;
  description: string;
  /** ISO de início; null quando imediato. */
  start: string | null;
  end: string | null;
  area: string | null;
  createdAt: number;
}

export interface RainCountdownResult {
  /** Estado do cálculo para a UI saber o que apresentar. */
  status: 'raining' | 'imminent' | 'clear' | 'insufficient-data';
  /** Minutos até começar (status imminent). */
  minutesUntilStart: number | null;
  /** Minutos estimados de duração da precipitação. */
  durationMinutes: number | null;
  /** Intensidade estimada mm/15min no início. */
  expectedIntensity: number | null;
  headline: string;
  detail: string;
}

export interface RecommendationItem {
  key: string;
  title: string;
  hour: string;
  score: number;
  confidence: number;
  justification: string;
  sufficientData: boolean;
}

export interface PlannerCriterion {
  key: 'car-wash' | 'laundry' | 'outdoor' | 'picnic';
  label: string;
  /** Dia vencedor (YYYY-MM-DD). */
  winnerDate: string | null;
  winnerLabel: string;
  justification: string;
  alternatives: Array<{ date: string; label: string; reason: string }>;
  daysToAvoid: Array<{ date: string; label: string; reason: string }>;
  sufficientData: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  details: string[];
  createdAt: number;
  /** false quando o texto final (possivelmente reformulado por LLM) ainda não chegou. */
  final: boolean;
  intent: string | null;
}

/** Re-export do perfil (contrato único de tipos da aplicação). */
export type { Profile } from '@/lib/schemas/report.schema';
