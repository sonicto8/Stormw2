/**
 * Rain Countdown — contagem decrescente para a próxima precipitação.
 * Baseado exclusivamente nos dados `minutely_15` do Open-Meteo.
 * Nunca inventa previsões quando a resolução não existe.
 */
import type { ForecastBundle, RainCountdownResult } from '@/lib/types';
import { parseLocalIso } from '@/lib/format';

/** Janela de análise: 2 horas = 8 passos de 15 min. */
const WINDOW_STEPS = 8;
/** Limiar (mm/15min) acima do qual consideramos precipitação. */
const WET_THRESHOLD = 0.1;

interface WetStep {
  index: number;
  minutesFromNow: number;
  precipitation: number;
  weatherCode: number | null;
}

function describeIntensity(mm: number): string | null {
  if (mm >= 1.0) return 'Chuva forte';
  if (mm >= 0.5) return 'Chuva moderada';
  return 'Chuva';
}

export function computeRainCountdown(bundle: ForecastBundle, nowMs: number): RainCountdownResult {
  const series = bundle.minutely15;

  if (series.length === 0 || series.every((s) => s.precipitation === null)) {
    return {
      status: 'insufficient-data',
      minutesUntilStart: null,
      durationMinutes: null,
      expectedIntensity: null,
      headline: 'Resolução minutely indisponível',
      detail:
        'Os dados de curto prazo não estão disponíveis neste momento. Consulta a probabilidade de precipitação na previsão horária.',
    };
  }

  const currentTime = bundle.current.time;
  const nowBase = parseLocalIso(currentTime).getTime();
  // Índice do primeiro passo não anterior a "agora".
  let startIndex = series.findIndex((s) => parseLocalIso(s.time).getTime() >= nowBase);
  if (startIndex === -1) startIndex = Math.max(0, series.length - 1);

  const window = series.slice(startIndex, startIndex + WINDOW_STEPS);
  const nowIdx = startIndex;

  const wetSteps: WetStep[] = [];
  window.forEach((step, i) => {
    if (step.precipitation !== null && step.precipitation > WET_THRESHOLD) {
      const stepMs = parseLocalIso(step.time).getTime();
      const minutesFromNow = Math.max(0, Math.round((stepMs - nowMs) / 60000));
      wetSteps.push({ index: nowIdx + i, minutesFromNow, precipitation: step.precipitation, weatherCode: step.weatherCode });
    }
  });

  // Já está a chover neste momento?
  const currentStep = series[Math.min(nowIdx, series.length - 1)];
  if (currentStep.precipitation !== null && currentStep.precipitation > WET_THRESHOLD) {
    let wet = 0;
    for (let i = nowIdx; i < series.length; i++) {
      const p = series[i].precipitation;
      if (p !== null && p > WET_THRESHOLD) wet++;
      else break;
    }
    const duration = wet * 15;
    const thunder = window.some((s) => (s.weatherCode ?? 0) >= 95);
    return {
      status: 'raining',
      minutesUntilStart: 0,
      durationMinutes: duration,
      expectedIntensity: currentStep.precipitation,
      headline:
        duration >= WINDOW_STEPS * 15
          ? `Precipitação nas próximas ${WINDOW_STEPS} horas`
          : `Precipitação durante aproximadamente ${duration} min`,
      detail: thunder
        ? 'Trovoada associada à precipitação em curso. Evita zonas abertas e árvores isoladas.'
        : `Intensidade atual de ${currentStep.precipitation.toFixed(1)} mm/15 min.`,
    };
  }

  const first = wetSteps[0];
  if (first) {
    let wet = 0;
    for (let i = first.index; i < series.length; i++) {
      const p = series[i].precipitation;
      if (p !== null && p > WET_THRESHOLD) wet++;
      else break;
    }
    const duration = wet * 15;
    const intensityLabel = describeIntensity(first.precipitation);
    const thunder = window.some((s) => (s.weatherCode ?? 0) >= 95);
    const cappedMinutes = Math.min(first.minutesFromNow, 120);
    return {
      status: 'imminent',
      minutesUntilStart: cappedMinutes,
      durationMinutes: duration,
      expectedIntensity: first.precipitation,
      headline:
        first.precipitation > WET_THRESHOLD
          ? `${intensityLabel}${first.minutesFromNow <= 15 ? ' em breve' : ` em ${cappedMinutes} min`}`
          : `Precipitação em ${cappedMinutes} min`,
      detail:
        duration >= WINDOW_STEPS * 15
          ? `Prevista durar pelo menos ${duration} min${thunder ? ', com trovoada' : ''}.`
          : `Duração estimada de ${duration} min${thunder ? ', com trovoada' : ''}.`,
    };
  }

  return {
    status: 'clear',
    minutesUntilStart: null,
    durationMinutes: null,
    expectedIntensity: null,
    headline: 'Sem chuva nas próximas 2 horas',
    detail: 'Nenhuma precipitação prevista nos dados de curto prazo para as próximas duas horas.',
  };
}
