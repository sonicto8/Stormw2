/**
 * STORM AI — motor de intenções local e determinístico.
 * Todas as respostas usam exclusivamente valores calculados das APIs.
 * As respostas têm 1–3 frases, indicam horas relevantes e identificam
 * dados indisponíveis em vez de inventar.
 */
import type { AirQualityBundle, ForecastBundle, Profile } from '@/lib/types';
import {
  formatHour,
  formatShortDayLabel,
  formatTemp,
  formatWind,
  parseLocalIso,
  uvLabel,
  windDirectionLabel,
} from '@/lib/format';
import { computeRainCountdown } from '@/lib/engines/rain-countdown';
import { computeActivityIndex } from '@/lib/engines/activity-index';

export type IntentKey =
  | 'chuva'
  | 'vestuario'
  | 'corrida'
  | 'caminhada'
  | 'praia'
  | 'lavagem_carro'
  | 'sol'
  | 'uv'
  | 'vento'
  | 'frio'
  | 'calor'
  | 'fallback';

export interface IntentAnswer {
  intent: IntentKey;
  text: string;
  details: string[];
}

export interface IntentContext {
  bundle: ForecastBundle;
  air: AirQualityBundle | null;
  nowMs: number;
}

/** Remove acentos e pontuação para matching robusto. */
function normalize(text: string): string {
  return text
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[?!.,;:]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const INTENT_PATTERNS: Array<{ key: IntentKey; patterns: RegExp[] }> = [
  { key: 'chuva', patterns: [/guarda.chuva|guarda chuva|chover|chuva|molhad|banho de agua|precipita/] },
  { key: 'vestuario', patterns: [/vestir|vestuario|roupa que|o que levo|levar roupa|calças|jaqueta|casaco/] },
  { key: 'corrida', patterns: [/correr|corrida|running|trote/] },
  { key: 'caminhada', patterns: [/passear|passeio|caminhar|caminhada|andar a pe|caminhada/] },
  { key: 'praia', patterns: [/praia|mar\b|banhos|tomar banho na praia|areia/] },
  { key: 'lavagem_carro', patterns: [/lavar (o )?carro|carro ao lavadoiro|lavadoiro/] },
  { key: 'sol', patterns: [/\bsol\b|ensolarad|sol da tarde|tempo bom/] },
  { key: 'uv', patterns: [/\buv\b|ultravioleta|queimadura solar|protetor solar/] },
  { key: 'vento', patterns: [/vento|ventos|ventar|rajada|brisa/] },
  { key: 'frio', patterns: [/frio|fria|gelad|agasalho/] },
  { key: 'calor', patterns: [/calor|calorinho|quente|arda|temperatura alta/] },
];

export function detectIntent(message: string): IntentKey | null {
  const n = normalize(message);
  for (const { key, patterns } of INTENT_PATTERNS) {
    if (patterns.some((p) => p.test(n))) return key;
  }
  return null;
}

export const MANDATORY_QUESTIONS: Array<{ question: string; intent: IntentKey }> = [
  { question: 'Preciso de guarda-chuva hoje?', intent: 'chuva' },
  { question: 'O que devo vestir?', intent: 'vestuario' },
  { question: 'Qual a melhor hora para correr?', intent: 'corrida' },
  { question: 'É bom dia para a praia?', intent: 'praia' },
  { question: 'Posso lavar o carro amanhã?', intent: 'lavagem_carro' },
];

function nextWetHour(bundle: ForecastBundle, nowMs: number): { hour: number; prob: number } | null {
  const upcoming = bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= nowMs).slice(0, 24);
  for (const h of upcoming) {
    if (h.precipitationProbability !== null && h.precipitationProbability >= 50) {
      return { hour: parseLocalIso(h.time).getUTCHours(), prob: h.precipitationProbability };
    }
  }
  return null;
}

function summarizeWindow(bundle: ForecastBundle, nowMs: number): string {
  const upcoming = bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= nowMs).slice(0, 12);
  if (upcoming.length === 0) return 'Sem dados horários disponíveis.';
  const maxTemp = Math.max(...upcoming.map((h) => h.temperature));
  const minTemp = Math.min(...upcoming.map((h) => h.temperature));
  const maxProb = Math.max(...upcoming.map((h) => h.precipitationProbability ?? 0));
  return `Nas próximas ${upcoming.length} horas: entre ${formatTemp(minTemp, 'celsius')} e ${formatTemp(maxTemp, 'celsius')}${upcoming[0].precipitationProbability !== null ? `, probabilidade máxima de chuva de ${maxProb}%` : ''}.`;
}

function answerChuva(ctx: IntentContext): IntentAnswer {
  const cd = computeRainCountdown(ctx.bundle, ctx.nowMs);
  const details: string[] = [`Estado: ${cd.headline}.`];
  if (cd.status === 'raining') {
    return {
      intent: 'chuva',
      text: `Sim — está a chover agora. ${cd.detail}`,
      details,
    };
  }
  if (cd.status === 'imminent') {
    return {
      intent: 'chuva',
      text: `Sim, aconselho guarda-chuva: ${cd.headline.toLowerCase()}. ${cd.detail}`,
      details,
    };
  }
  if (cd.status === 'clear') {
    const nextWet = nextWetHour(ctx.bundle, ctx.nowMs);
    details.push(nextWet ? `Próxima chuva provável às ${String(nextWet.hour).padStart(2, '0')}h (${nextWet.prob}%).` : 'Sem chuva significativa nas próximas 24 horas.');
    return {
      intent: 'chuva',
      text: `Não é preciso guarda-chuva nas próximas 2 horas. ${nextWet ? `Atenção: ${nextWet.prob}% de probabilidade de chuva às ${String(nextWet.hour).padStart(2, '0')}h.` : ''}`,
      details,
    };
  }
  const probNow = ctx.bundle.hourly.find((h) => parseLocalIso(h.time).getTime() >= ctx.nowMs)?.precipitationProbability;
  return {
    intent: 'chuva',
    text: `Não tenho resolução minutely neste momento. Pela previsão horária, ${probNow !== null ? `a probabilidade de chuva agora é de ${probNow}%.` : 'não há probabilidade de precipitação disponível.'}`,
    details,
  };
}

function answerVestuario(ctx: IntentContext, profile: Profile): IntentAnswer {
  const cur = ctx.bundle.current;
  const t = cur.apparentTemperature;
  const coldS = profile.coldSensitivity;
  const heatS = profile.heatSensitivity;
  const pieces: string[] = [];
  if (t <= 5) pieces.push(coldS >= 4 ? 'casaco de inverno e cachecol (sensibilidade elevada ao frio)' : 'casaco quente');
  else if (t <= 12) pieces.push(coldS >= 4 ? 'casaco médio com camadas' : 'casaco');
  else if (t <= 18) pieces.push('camadas leves, tipo camisa e camisola');
  else if (t <= 26) pieces.push('roupa leve, t-shirt ou camisa');
  else pieces.push(heatS >= 4 ? 'roupa muito leve e clara (sensibilidade elevada ao calor)' : 'roupa leve e clara');
  if (cur.windGusts >= 40) pieces.push('corta-vento (rajadas de ' + formatWind(cur.windGusts, profile.windUnit) + ')');
  if (cur.precipitation > 0.1 || ctx.bundle.minutely15.some((m) => (m.precipitation ?? 0) > 0.1)) pieces.push('impermeável ou guarda-chuva');
  const uv = cur.uvIndex;
  if (uv !== null && uv >= 6) pieces.push('protetor solar (UV ' + uv.toFixed(0) + ')');
  return {
    intent: 'vestuario',
    text: `Com ${formatTemp(t, profile.temperatureUnit)} de sensação térmica, recomendo ${pieces.join(', ')}.`,
    details: [`${cur.weatherLabel}, humidade ${cur.humidity !== null ? cur.humidity + '%' : 'indisponível'}.`],
  };
}

function answerCorrida(ctx: IntentContext, profile: Profile): IntentAnswer {
  const idx = computeActivityIndex('running', ctx.bundle.hourly, ctx.bundle.daily, ctx.nowMs);
  if (!idx || !idx.bestHour) {
    return { intent: 'corrida', text: 'Não tenho dados horários suficientes para apontar a melhor hora de corrida.', details: [] };
  }
  const cd = computeRainCountdown(ctx.bundle, ctx.nowMs);
  const rainNote = cd.status === 'imminent' ? ` Atenção: ${cd.headline.toLowerCase()}.` : '';
  return {
    intent: 'corrida',
    text: `A melhor janela para correr é às ${formatHour(idx.bestHour)} — índice de corrida ${idx.score}/100 (${idx.classification.toLowerCase()}). ${idx.justification}${rainNote}`,
    details: [`Índice geral: ${idx.score}/100.`, `Temperatura ideal considerada para o teu perfil: ${profile.heatSensitivity >= 4 ? 'menor intensidade ao calor' : 'padrão'}.`],
  };
}

function answerCaminhada(ctx: IntentContext): IntentAnswer {
  const idx = computeActivityIndex('walking', ctx.bundle.hourly, ctx.bundle.daily, ctx.nowMs);
  if (!idx || !idx.bestHour) {
    return { intent: 'caminhada', text: 'Sem dados horários suficientes para recomendar a melhor hora de caminhada.', details: [] };
  }
  return {
    intent: 'caminhada',
    text: `Para caminhar, o melhor momento é às ${formatHour(idx.bestHour)} — índice ${idx.score}/100 (${idx.classification.toLowerCase()}). ${idx.justification}`,
    details: [`Índice geral: ${idx.score}/100.`],
  };
}

function answerPraia(ctx: IntentContext): IntentAnswer {
  const cur = ctx.bundle.current;
  const today = ctx.bundle.daily[0];
  const idx = computeActivityIndex('beach', ctx.bundle.hourly, ctx.bundle.daily, ctx.nowMs);
  const reasons: string[] = [];
  let verdict = '';
  const tMax = today?.tempMax ?? cur.temperature;
  const upcoming = ctx.bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= ctx.nowMs).slice(0, 12);
  const prob = upcoming.reduce((acc, h) => Math.max(acc, h.precipitationProbability ?? 0), 0);
  const uv = today?.uvIndexMax ?? cur.uvIndex;
  if (tMax >= 24 && (prob ?? 0) <= 40 && (ctx.bundle.current.windGusts) < 45) {
    verdict = 'É um bom dia para a praia.';
  } else if (tMax >= 20 && (prob ?? 0) <= 60) {
    verdict = 'Dá para a praia, mas com reservas.';
  } else {
    verdict = 'Hoje não é um bom dia para a praia.';
  }
  reasons.push(`Máxima de ${formatTemp(tMax, 'celsius')}`);
  if (prob !== undefined) reasons.push(`${prob}% de probabilidade de chuva`);
  if (uv !== null) reasons.push(`UV máximo ${uv.toFixed(0)} (${uvLabel(uv).toLowerCase()})`);
  const bestHour = idx?.bestHour ? ` Melhor janela: ${formatHour(idx.bestHour)}.` : '';
  return {
    intent: 'praia',
    text: `${verdict} ${reasons.join(', ')}.${bestHour}`,
    details: [summarizeWindow(ctx.bundle, ctx.nowMs)],
  };
}

function answerLavagemCarro(ctx: IntentContext): IntentAnswer {
  const days = ctx.bundle.daily;
  if (days.length < 2) {
    return { intent: 'lavagem_carro', text: 'Não tenho previsão suficiente para os próximos dias.', details: [] };
  }
  const candidates = days.slice(0, 5).filter((d) => {
    const clean = d.precipitationSum < 0.1 && d.precipitationProbabilityMax !== null && d.precipitationProbabilityMax < 20;
    return clean;
  });
  if (candidates.length > 0) {
    const best = candidates[0];
    const next = days[days.indexOf(best) + 1];
    const protectedOk = next ? next.precipitationSum < 0.5 : true;
    const dayName = formatShortDayLabel(best.date);
    return {
      intent: 'lavagem_carro',
      text: protectedOk
        ? `Sim — ${dayName} não tem chuva prevista (${best.precipitationProbabilityMax ?? 0}% de probabilidade) e o dia seguinte mantém-se seco.`
        : `Podes lavar em ${dayName}, mas atenção: no dia seguinte há ${next.precipitationSum.toFixed(1)} mm previstos.`,
      details: days.slice(0, 5).map((d) => `${d.date}: ${d.precipitationSum.toFixed(1)} mm, ${d.precipitationProbabilityMax ?? '—'}%`),
    };
  }
  return {
    intent: 'lavagem_carro',
    text: 'Nos próximos 5 dias há chuva prevista em todos os dias. Se puder esperar, adiante a lavagem.',
    details: days.slice(0, 5).map((d) => `${d.date}: ${d.precipitationSum.toFixed(1)} mm, ${d.precipitationProbabilityMax ?? '—'}%`),
  };
}

function answerSol(ctx: IntentContext): IntentAnswer {
  const upcoming = ctx.bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= ctx.nowMs).slice(0, 12);
  const sunny = upcoming.filter((h) => (h.cloudCover ?? 100) <= 30 || [0, 1].includes(h.weatherCode));
  if (sunny.length === 0) {
    return { intent: 'sol', text: `Não há períodos de céu limpo nas próximas 12 horas — ${ctx.bundle.current.weatherLabel.toLowerCase()}.`, details: [] };
  }
  const first = sunny[0];
  return {
    intent: 'sol',
    text: `O céu estará mais limpo às ${formatHour(first.time)} (${first.cloudCover !== null ? `${first.cloudCover}% de nebulosidade` : first.weatherLabel.toLowerCase()}).`,
    details: sunny.slice(0, 4).map((h) => `${formatHour(h.time)}: ${h.weatherLabel}, ${h.temperature}°C`),
  };
}

function answerUv(ctx: IntentContext): IntentAnswer {
  const cur = ctx.bundle.current;
  const today = ctx.bundle.daily[0];
  const uvNow = cur.uvIndex;
  const uvMax = today?.uvIndexMax ?? null;
  if (uvNow === null && uvMax === null) {
    return { intent: 'uv', text: 'O índice UV não está disponível neste momento.', details: [] };
  }
  const parts: string[] = [];
  if (uvNow !== null) parts.push(`agora é ${uvNow.toFixed(1)} (${uvLabel(uvNow)})`);
  if (uvMax !== null) parts.push(`máximo hoje de ${uvMax.toFixed(1)} (${uvLabel(uvMax)})`);
  const advice = (uvMax ?? uvNow ?? 0) >= 6 ? ' Usa protetor solar e evita exposição entre as 12h e as 16h.' : '';
  return { intent: 'uv', text: `Índice UV: ${parts.join('; ')}.${advice}`, details: [] };
}

function answerVento(ctx: IntentContext, profile: Profile): IntentAnswer {
  const cur = ctx.bundle.current;
  const maxGustToday = ctx.bundle.daily[0]?.windGustsMax ?? cur.windGusts;
  return {
    intent: 'vento',
    text: `Vento atual de ${formatWind(cur.windSpeed, profile.windUnit)} (${windDirectionLabel(cur.windDirection)}) com rajadas de ${formatWind(cur.windGusts, profile.windUnit)}. Máxima hoje: ${formatWind(maxGustToday, profile.windUnit)}.`,
    details: [],
  };
}

function answerFrio(ctx: IntentContext, profile: Profile): IntentAnswer {
  const cur = ctx.bundle.current;
  const upcoming = ctx.bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= ctx.nowMs).slice(0, 12);
  const minFeel = upcoming.length > 0 ? Math.min(...upcoming.map((h) => h.apparentTemperature)) : cur.apparentTemperature;
  if (cur.apparentTemperature > 15) {
    return { intent: 'frio', text: `Não estou à espera de frio: sensação térmica atual de ${formatTemp(cur.apparentTemperature, profile.temperatureUnit)}. Mínima prevista nas próximas horas: ${formatTemp(minFeel, profile.temperatureUnit)}.`, details: [] };
  }
  return {
    intent: 'frio',
    text: `Sensação térmica de ${formatTemp(cur.apparentTemperature, profile.temperatureUnit)}${cur.apparentTemperature <= 0 ? ' — condições de frio extremo' : ''}. A mínima prevista nas próximas horas é ${formatTemp(minFeel, profile.temperatureUnit)}. ${profile.coldSensitivity >= 4 ? 'Como tens sensibilidade elevada ao frio, agasalha-te bem.' : ''}`,
    details: [],
  };
}

function answerCalor(ctx: IntentContext, profile: Profile): IntentAnswer {
  const cur = ctx.bundle.current;
  const today = ctx.bundle.daily[0];
  const upcoming = ctx.bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= ctx.nowMs).slice(0, 12);
  const maxFeel = upcoming.length > 0 ? Math.max(...upcoming.map((h) => h.apparentTemperature)) : cur.apparentTemperature;
  if (cur.apparentTemperature < 18) {
    return { intent: 'calor', text: `Sem calor para já: sensação térmica de ${formatTemp(cur.apparentTemperature, profile.temperatureUnit)}. Máxima hoje: ${today ? formatTemp(today.tempMax, profile.temperatureUnit) : 'indisponível'}.`, details: [] };
  }
  return {
    intent: 'calor',
    text: `Sensação térmica de ${formatTemp(cur.apparentTemperature, profile.temperatureUnit)} e máxima hoje de ${today ? formatTemp(today.tempMax, profile.temperatureUnit) : '—'}. O pico de calor será de ${formatTemp(maxFeel, profile.temperatureUnit)} de sensação.${profile.heatSensitivity >= 4 ? ' Com a tua sensibilidade ao calor, evita o sol direto a meio do dia.' : ''}`,
    details: [],
  };
}

function answerFallback(ctx: IntentContext, profile: Profile): IntentAnswer {
  const cur = ctx.bundle.current;
  const air = ctx.air?.europeanAqi ?? null;
  const nextWet = nextWetHour(ctx.bundle, ctx.nowMs);
  return {
    intent: 'fallback',
    text: `${cur.weatherLabel} com ${formatTemp(cur.temperature, profile.temperatureUnit)} (sensação de ${formatTemp(cur.apparentTemperature, profile.temperatureUnit)}). ${nextWet ? `Próxima chuva provável às ${String(nextWet.hour).padStart(2, '0')}h.` : 'Sem chuva significativa nas próximas 24 horas.'}${air !== null ? ` Qualidade do ar: AQI ${Math.round(air)}.` : ''}`,
    details: [summarizeWindow(ctx.bundle, ctx.nowMs)],
  };
}

/** Constrói a resposta determinística para uma mensagem do utilizador. */
export function buildIntentAnswer(message: string, ctx: IntentContext, profile: Profile): IntentAnswer {
  const intent = detectIntent(message);
  switch (intent) {
    case 'chuva': return answerChuva(ctx);
    case 'vestuario': return answerVestuario(ctx, profile);
    case 'corrida': return answerCorrida(ctx, profile);
    case 'caminhada': return answerCaminhada(ctx);
    case 'praia': return answerPraia(ctx);
    case 'lavagem_carro': return answerLavagemCarro(ctx);
    case 'sol': return answerSol(ctx);
    case 'uv': return answerUv(ctx);
    case 'vento': return answerVento(ctx, profile);
    case 'frio': return answerFrio(ctx, profile);
    case 'calor': return answerCalor(ctx, profile);
    default: return answerFallback(ctx, profile);
  }
}

/** Extrai todos os números de um texto (para validação de reformulação por LLM). */
export function extractNumbers(text: string): string[] {
  return text.match(/\d+(?:[.,]\d+)?/g) ?? [];
}
