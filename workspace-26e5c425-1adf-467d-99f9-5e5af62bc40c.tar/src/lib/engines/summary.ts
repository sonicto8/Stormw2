/**
 * Resumo inteligente — 1 a 4 frases que condensam o estado meteorológico atual,
 * construídas exclusivamente a partir de valores calculados das APIs.
 */
import type { AirQualityBundle, ForecastBundle, RainCountdownResult, WeatherAlert } from '@/lib/types';
import { aqiLabel, formatTemp, formatWind, windDirectionLabel } from '@/lib/format';

export function buildSmartSummary(
  bundle: ForecastBundle,
  air: AirQualityBundle | null,
  countdown: RainCountdownResult,
  alerts: WeatherAlert[],
): string {
  const cur = bundle.current;
  const today = bundle.daily[0];
  const tomorrow = bundle.daily[1];
  const sentences: string[] = [];

  // Frase 1: condição, temperatura, sensação e extremos do dia.
  const parts: string[] = [`${cur.weatherLabel.toLowerCase()} a ${formatTemp(cur.temperature)}`];
  parts.push(`sensação de ${formatTemp(cur.apparentTemperature)}`);
  if (today) parts.push(`entre ${formatTemp(today.tempMin)} e ${formatTemp(today.tempMax)} hoje`);
  sentences.push(`${parts.join(', ').replace(/^./, (c) => c.toUpperCase())}.`);

  // Frase 2: precipitação imediata quando relevante.
  if (countdown.status === 'raining' || countdown.status === 'imminent') {
    sentences.push(countdown.headline + '.');
  }

  // Frase 3: guarda-chuva quando a probabilidade de hoje é significativa.
  const probToday = today?.precipitationProbabilityMax ?? null;
  if (probToday !== null && probToday >= 50 && countdown.status !== 'raining') {
    sentences.push(`Probabilidade de chuva máxima de ${probToday}% hoje — convém levar guarda-chuva.`);
  }

  // Frase 4: amanhã.
  if (tomorrow) {
    const tomorrowParts = [`${tomorrow.weatherLabel.toLowerCase()}`, `entre ${formatTemp(tomorrow.tempMin)} e ${formatTemp(tomorrow.tempMax)}`];
    sentences.push(`Amanhã: ${tomorrowParts.join(', ')}.`);
  }

  // Frase final: vento, qualidade do ar e avisos oficiais.
  const tail: string[] = [];
  if (cur.windGusts >= 40) {
    tail.push(
      `vento de ${formatWind(cur.windSpeed)} (${windDirectionLabel(cur.windDirection)}) com rajadas de ${formatWind(cur.windGusts)}`,
    );
  }
  if (air?.europeanAqi !== null && air?.europeanAqi !== undefined) {
    tail.push(`qualidade do ar ${aqiLabel(air.europeanAqi).label.toLowerCase()} (AQI ${Math.round(air.europeanAqi)})`);
  }
  const official = alerts.find((a) => a.origin === 'ipma');
  if (official && official.officialLevel) {
    tail.push(`aviso ${official.officialLevel === 'red' ? 'vermelho' : official.officialLevel === 'orange' ? 'laranja' : 'amarelo'} do IPMA para ${official.area}`);
  }
  if (tail.length > 0) {
    sentences.push(`${tail.join('; ').replace(/^./, (c) => c.toUpperCase())}.`);
  }

  return sentences.slice(0, 5).join(' ');
}
