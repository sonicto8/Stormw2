/**
 * Secção "INTELIGÊNCIA PARA TI" — recomendações de melhor hora com índice de
 * confiança e justificação baseada exclusivamente em dados reais.
 */
import type { ForecastBundle, HourlyPoint, Profile, RecommendationItem } from '@/lib/types';
import { formatHour, parseLocalIso } from '@/lib/format';

interface Candidate {
  hour: HourlyPoint;
  score: number;
}

function upcomingHours(bundle: ForecastBundle, nowMs: number, windowHours: number): HourlyPoint[] {
  return bundle.hourly.filter((h) => parseLocalIso(h.time).getTime() >= nowMs).slice(0, windowHours);
}

function confidenceFor(candidates: Candidate[], fieldsUsed: Array<number | null>): number {
  if (candidates.length === 0) return 0;
  const completeness =
    fieldsUsed.filter((v) => v !== null && v !== undefined).length / Math.max(1, fieldsUsed.length);
  const spread = Math.min(1, candidates.length / 4);
  return Math.round(60 + completeness * 25 + spread * 15);
}

function bestCandidate(hours: HourlyPoint[], scorer: (h: HourlyPoint) => number | null): Candidate[] {
  return hours
    .map((hour) => ({ hour, score: scorer(hour) }))
    .filter((c): c is Candidate => c.score !== null)
    .sort((a, b) => b.score - a.score);
}

function tempComfort(h: HourlyPoint): number {
  return Math.max(0, 100 - Math.abs(h.apparentTemperature - 19) * 6);
}

function precipFactor(h: HourlyPoint): number {
  const mm = Math.max(h.precipitation, (h.precipitationProbability ?? 0) > 60 ? 0.3 : 0);
  return Math.max(0, 100 - mm * 120);
}

function windFactor(h: HourlyPoint): number {
  return Math.max(0, 100 - Math.max(0, h.windSpeed - 20) * 3);
}

export function computeRecommendations(
  bundle: ForecastBundle,
  nowMs: number,
  profile: Profile,
): RecommendationItem[] {
  const items: RecommendationItem[] = [];
  const hours = upcomingHours(bundle, nowMs, 12);

  if (hours.length === 0) {
    return [
      {
        key: 'no-data',
        title: 'Recomendações indisponíveis',
        hour: '—',
        score: 0,
        confidence: 0,
        justification: 'A previsão horária não está disponível de momento. Tenta atualizar mais tarde.',
        sufficientData: false,
      },
    ];
  }

  // — Melhor hora para sair (próximas 4h, equilíbrio precipitação/temperatura)
  const goOut = bestCandidate(hours.slice(0, 4), (h) => precipFactor(h) * 0.5 + tempComfort(h) * 0.4 + windFactor(h) * 0.1);
  if (goOut.length > 0) {
    const best = goOut[0];
    const rain = best.hour.precipitationProbability;
    items.push({
      key: 'sair',
      title: 'Melhor hora para sair',
      hour: formatHour(best.hour.time),
      score: Math.round(best.score),
      confidence: confidenceFor(
        goOut,
        goOut.map((c) => c.hour.precipitationProbability),
      ),
      justification:
        rain !== null && rain > 50
          ? `Às ${formatHour(best.hour.time)} a probabilidade de chuva é a menor da janela (${rain}%).`
          : `Às ${formatHour(best.hour.time)}: ${best.hour.temperature}°C${best.hour.precipitationProbability !== null ? `, ${best.hour.precipitationProbability}% de probabilidade de chuva` : ', sem precipitação prevista'} e vento de ${best.hour.windSpeed} km/h.`,
      sufficientData: best.hour.precipitationProbability !== null || best.hour.precipitation === 0,
    });
  }

  // — Melhor hora para correr
  const run = bestCandidate(hours, (h) => {
    const t = Math.max(0, 100 - Math.abs(h.apparentTemperature - 14) * 8);
    const p = precipFactor(h);
    const w = Math.max(0, 100 - Math.max(0, h.windSpeed - 25) * 4);
    return t * 0.4 + p * 0.4 + w * 0.2;
  });
  if (run.length > 0) {
    const best = run[0];
    items.push({
      key: 'correr',
      title: 'Melhor hora para correr',
      hour: formatHour(best.hour.time),
      score: Math.round(best.score),
      confidence: confidenceFor(
        run,
        run.map((c) => c.hour.precipitationProbability),
      ),
      justification: `Sensação térmica de ${best.hour.apparentTemperature}°C às ${formatHour(best.hour.time)}${best.hour.precipitation > 0 ? ` com ${best.hour.precipitation.toFixed(1)} mm de precipitação` : ', sem precipitação prevista'}.`,
      sufficientData: true,
    });
  }

  // — Melhor hora para passear
  const walk = bestCandidate(hours, (h) => {
    const t = Math.max(0, 100 - Math.abs(h.apparentTemperature - 18) * 7);
    const p = precipFactor(h);
    const w = windFactor(h);
    return t * 0.35 + p * 0.4 + w * 0.25;
  });
  if (walk.length > 0) {
    const best = walk[0];
    items.push({
      key: 'passear',
      title: 'Melhor hora para passear',
      hour: formatHour(best.hour.time),
      score: Math.round(best.score),
      confidence: confidenceFor(
        walk,
        walk.map((c) => c.hour.precipitationProbability),
      ),
      justification: `Às ${formatHour(best.hour.time)}: ${best.hour.weatherLabel.toLowerCase()}, ${best.hour.temperature}°C e vento de ${best.hour.windSpeed} km/h.`,
      sufficientData: true,
    });
  }

  // — Melhor hora para estender roupa
  const laundry = bestCandidate(hours, (h) => {
    if (h.precipitation > 0.1 || (h.precipitationProbability ?? 0) > 40) return null;
    const wind = h.windSpeed;
    const windScore = wind >= 5 && wind <= 25 ? 100 : Math.max(0, 100 - Math.abs(wind - 15) * 6);
    const humidity = h.humidity === null ? 60 : Math.max(0, 100 - Math.max(0, h.humidity - 60) * 3);
    return windScore * 0.45 + humidity * 0.3 + tempComfort(h) * 0.25;
  });
  if (laundry.length > 0) {
    const best = laundry[0];
    items.push({
      key: 'roupa',
      title: 'Melhor hora para estender roupa',
      hour: formatHour(best.hour.time),
      score: Math.round(best.score),
      confidence: confidenceFor(
        laundry,
        laundry.map((c) => c.hour.humidity),
      ),
      justification: `Vento de ${best.hour.windSpeed} km/h${best.hour.humidity !== null ? ` e humidade de ${best.hour.humidity}%` : ''} às ${formatHour(best.hour.time)} — condições ideais para secagem.`,
      sufficientData: best.hour.humidity !== null || best.hour.windSpeed >= 0,
    });
  }

  // Personalização pelo perfil: se o utilizador é muito sensível ao frio e está frio,
  // realça o aviso na primeira recomendação disponível.
  const tempNow = bundle.current.apparentTemperature;
  if (profile.coldSensitivity >= 4 && tempNow <= 10 && items.length > 0) {
    items.unshift({
      key: 'frio-personalizado',
      title: 'Indicador pessoal de frio',
      hour: 'agora',
      score: 0,
      confidence: 85,
      justification: `Definiste sensibilidade elevada ao frio (${profile.coldSensitivity}/5). Com sensação térmica de ${tempNow}°C, considera camadas extra.`,
      sufficientData: true,
    });
  }

  return items.slice(0, 4);
}
