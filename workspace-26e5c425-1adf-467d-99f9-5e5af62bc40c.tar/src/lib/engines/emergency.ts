/**
 * Motor de emergência — prepara a partilha de localização por WhatsApp para os
 * contactos de emergência do perfil. A mensagem é construída exclusivamente a
 * partir de dados reais da aplicação (localização ativa, avisos ativos e
 * condição atual); nada é inventado.
 */
import type { WeatherAlert } from '@/lib/types';
import { formatTempValue, formatDateTimeMs, formatWind } from '@/lib/format';
import type { Profile } from '@/lib/schemas/report.schema';

export interface EmergencyContext {
  /** Nome do local ativo (GPS ou localidade escolhida). */
  placeName: string;
  latitude: number;
  longitude: number;
  /** Coordenadas precisas de GPS quando disponíveis (caso de emergência real). */
  gps: { latitude: number; longitude: number } | null;
  alerts: WeatherAlert[];
  /** Condição atual (label) e temperatura — reais, da última previsão. */
  conditionLabel: string | null;
  temperatureC: number | null;
  windKmh: number | null;
  /** Hora da mensagem (epoch ms). */
  now: number;
}

/** Número de telemóvel do contacto em formato wa.me (apenas dígitos com prefixo). */
export function waNumber(raw: string): string {
  const digits = raw.replace(/[^\d+]/g, '').replace(/^\+/, '');
  // Números portugueses sem indicativo: 9 dígitos a começar por 9 (móvel) ou 2 (fixo).
  if (digits.length === 9 && /^[92]/.test(digits)) return `351${digits}`;
  return digits;
}

export function buildEmergencyMessage(ctx: EmergencyContext): string {
  const lat = ctx.gps?.latitude ?? ctx.latitude;
  const lon = ctx.gps?.longitude ?? ctx.longitude;
  const mapsUrl = `https://maps.google.com/?q=${lat.toFixed(5)},${lon.toFixed(5)}`;
  const lines: string[] = [];

  lines.push('ALERTA STORMWATCH — Partilha de emergência');
  lines.push('');
  lines.push('Preciso de ajuda. Estou a partilhar a minha localização a partir da aplicação STORMWATCH.');
  lines.push('');
  lines.push(`Local: ${ctx.placeName}`);
  lines.push(`Coordenadas: ${lat.toFixed(5)}, ${lon.toFixed(5)}`);
  lines.push(`Mapa: ${mapsUrl}`);
  lines.push(`Hora: ${formatDateTimeMs(ctx.now)}`);

  if (ctx.conditionLabel || ctx.temperatureC !== null) {
    const cond = [ctx.conditionLabel, ctx.temperatureC !== null ? formatTempValue(ctx.temperatureC) : null]
      .filter(Boolean)
      .join(', ');
    lines.push(`Condição atual: ${cond}`);
  }
  if (ctx.windKmh !== null) {
    lines.push(`Vento: ${formatWind(ctx.windKmh)}`);
  }

  if (ctx.alerts.length > 0) {
    lines.push('');
    lines.push('Avisos meteorológicos ativos:');
    for (const a of ctx.alerts.slice(0, 4)) {
      const area = a.area ? ` (${a.area})` : '';
      lines.push(`- ${a.title}${area}: ${a.description}`);
    }
  } else {
    lines.push('');
    lines.push('Sem avisos oficiais ativos para esta zona neste momento.');
  }

  lines.push('');
  lines.push('Mensagem enviada automaticamente pela STORMWATCH com a minha localização.');

  return lines.join('\n');
}

/** Link WhatsApp (wa.me) para um contacto com a mensagem codificada. */
export function whatsappLink(contactPhone: string, message: string): string {
  return `https://wa.me/${waNumber(contactPhone)}?text=${encodeURIComponent(message)}`;
}

/** Estado de emergência: true quando existe aviso crítico (interno ou IPMA vermelho/laranja). */
export function isDisasterSituation(alerts: WeatherAlert[]): boolean {
  return alerts.some(
    (a) => a.severity === 'critical' || (a.origin === 'ipma' && (a.officialLevel === 'red' || a.officialLevel === 'orange')),
  );
}

/** Contactos válidos do perfil (máximo 2, já garantido pelo schema). */
export function emergencyContactsOf(profile: Profile): Profile['emergencyContacts'] {
  return profile.emergencyContacts ?? [];
}
