/**
 * Motor de alertas inteligentes. Funde regras internas com avisos oficiais do
 * IPMA, preservando sempre a cor oficial (amarelo / laranja / vermelho).
 */
import type {
  AirQualityBundle,
  ForecastBundle,
  IpmaWarning,
  Profile,
  WeatherAlert,
} from '@/lib/types';
import { parseLocalIso } from '@/lib/format';

const SEVERITY_ORDER: Record<WeatherAlert['severity'], number> = {
  critical: 3,
  warning: 2,
  info: 1,
};

function normalizeArea(area: string): string {
  return area
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function internalAlert(
  id: string,
  severity: WeatherAlert['severity'],
  title: string,
  description: string,
  createdAt: number,
  start: string | null = null,
): WeatherAlert {
  return {
    id,
    origin: 'internal',
    severity,
    officialLevel: null,
    title,
    description,
    start,
    end: null,
    area: null,
    createdAt,
  };
}

/** Converte avisos IPMA em alertas internos com cor oficial preservada. */
export function ipmaToAlerts(warnings: IpmaWarning[], createdAt: number): WeatherAlert[] {
  return warnings.map((w) => {
    const severity: WeatherAlert['severity'] =
      w.level === 'red' ? 'critical' : w.level === 'orange' ? 'warning' : 'info';
    return {
      id: `ipma-${w.id}`,
      origin: 'ipma' as const,
      severity,
      officialLevel: w.level,
      title: `${w.phenomenLabel} — ${w.area}`,
      description: w.description || `Aviso ${w.level} do IPMA para ${w.area} (${w.phenomenLabel}).`,
      start: w.start,
      end: w.end,
      area: w.area,
      createdAt,
    };
  });
}

/** Devolve os avisos IPMA relativos à área indicada (ou todos se null). */
export function filterIpmaForArea(warnings: IpmaWarning[], area: string | null): IpmaWarning[] {
  if (!area) return warnings;
  const target = normalizeArea(area);
  const direct = warnings.filter((w) => normalizeArea(w.area) === target);
  return direct.length > 0 ? direct : warnings;
}

/**
 * Motor principal: gera alertas internos segundo as regras da especificação
 * e funde-os com os avisos oficiais (que ficam sempre primeiro).
 */
export function computeAlerts(
  bundle: ForecastBundle | null,
  air: AirQualityBundle | null,
  ipmaWarnings: IpmaWarning[],
  locationName: string | null,
  nowMs: number,
  profile: Profile,
): WeatherAlert[] {
  const alerts: WeatherAlert[] = [];

  // — Avisos oficiais IPMA (cor oficial preservada)
  const relevant = filterIpmaForArea(ipmaWarnings, locationName);
  alerts.push(...ipmaToAlerts(relevant, nowMs));

  if (bundle) {
    const cur = bundle.current;
    const rules = new Set(profile.alertTypes);

    // Chuva iminente: > 0,1 mm/15min (minutely_15)
    if (rules.has('rain')) {
      const nextWet = bundle.minutely15.find(
        (m) => m.precipitation !== null && m.precipitation > 0.1,
      );
      if (nextWet && parseLocalIso(nextWet.time).getTime() >= nowMs - 15 * 60000) {
        const mins = Math.max(
          0,
          Math.round((parseLocalIso(nextWet.time).getTime() - nowMs) / 60000),
        );
        alerts.push(
          internalAlert(
            'rain-imminent',
            mins <= 15 ? 'warning' : 'info',
            'Precipitação iminente',
            `${nextWet.precipitation?.toFixed(1)} mm/15 min previstos${mins > 0 ? ` em ~${mins} min` : ' agora'}.`,
            nowMs,
            nextWet.time,
          ),
        );
      }
    }

    // Trovoada: weather_code 95–99
    if (rules.has('thunderstorm')) {
      const thunder =
        cur.weatherCode >= 95 ||
        bundle.minutely15.some((m) => (m.weatherCode ?? 0) >= 95) ||
        bundle.hourly
          .filter((h) => parseLocalIso(h.time).getTime() >= nowMs)
          .slice(0, 6)
          .some((h) => h.weatherCode >= 95);
      if (thunder) {
        alerts.push(
          internalAlert(
            'thunder',
            'warning',
            'Trovoada no horizonte',
            'Condições de trovoada previstas nas próximas horas. Evita zonas abertas e desligue equipamentos sensíveis.',
            nowMs,
          ),
        );
      }
    }

    // Rajadas
    if (rules.has('wind')) {
      if (cur.windGusts >= 90) {
        alerts.push(
          internalAlert('gust-critical', 'critical', 'Rajadas críticas', `Rajadas de ${Math.round(cur.windGusts)} km/h. Evita deslocações e objetos soltos no exterior.`, nowMs),
        );
      } else if (cur.windGusts >= 60) {
        alerts.push(
          internalAlert('gust-warning', 'warning', 'Rajadas fortes', `Rajadas de ${Math.round(cur.windGusts)} km/h. Cuidado em zonas costeiras e na condução.`, nowMs),
        );
      }
    }

    // Calor ≥ 35°C
    if (rules.has('heat') && cur.temperature >= 35) {
      alerts.push(
        internalAlert('heat', 'critical', 'Calor extremo', `${Math.round(cur.temperature)}°C neste momento. Hidrata-te e evita exposição direta ao sol.`, nowMs),
      );
    }

    // Frio: sensação térmica ≤ 0°C
    if (rules.has('cold') && cur.apparentTemperature <= 0) {
      alerts.push(
        internalAlert('cold', 'warning', 'Frio extremo', `Sensação térmica de ${cur.apparentTemperature}°C. Protege extremidades e limita a exposição prolongada.`, nowMs),
      );
    }
  }

  // Qualidade do ar
  if (air && air.europeanAqi !== null) {
    if (air.europeanAqi > 100) {
      alerts.push(
        internalAlert('aqi-all', 'critical', 'Qualidade do ar má', `AQI europeu de ${Math.round(air.europeanAqi)}. Evita esforço ao ar livre — impacto para todos.`, nowMs),
      );
    } else if (air.europeanAqi > 60) {
      alerts.push(
        internalAlert('aqi-sensitive', 'warning', 'Qualidade do ar moderada', `AQI europeu de ${Math.round(air.europeanAqi)}. Grupos sensíveis devem reduzir esforço intenso ao ar livre.`, nowMs),
      );
    }
  }

  // Ordenar: críticos primeiro; dentro da mesma severidade, IPMA antes dos internos.
  return alerts.sort((a, b) => {
    const s = SEVERITY_ORDER[b.severity] - SEVERITY_ORDER[a.severity];
    if (s !== 0) return s;
    if (a.origin !== b.origin) return a.origin === 'ipma' ? -1 : 1;
    return b.createdAt - a.createdAt;
  });
}
