/**
 * Índices de atividade (0–100) — média ponderada de temperatura, vento,
 * precipitação, humidade e UV, com pesos distintos por atividade.
 */
import type { ActivityIndex, ActivityKey, DailyPoint, HourlyPoint } from '@/lib/types';
import { formatHour, parseLocalIso } from '@/lib/format';

const ACTIVITY_META: Record<ActivityKey, { label: string; weights: Record<string, number>; idealTemp: number; tempSigma: number; windLimit: number; windSigma: number }> = {
  running: {
    label: 'Corrida',
    weights: { temperature: 0.3, wind: 0.2, precipitation: 0.3, humidity: 0.1, uv: 0.1 },
    idealTemp: 14,
    tempSigma: 8,
    windLimit: 28,
    windSigma: 16,
  },
  walking: {
    label: 'Caminhada',
    weights: { temperature: 0.3, wind: 0.15, precipitation: 0.3, humidity: 0.15, uv: 0.1 },
    idealTemp: 18,
    tempSigma: 9,
    windLimit: 32,
    windSigma: 18,
  },
  cycling: {
    label: 'Ciclismo',
    weights: { temperature: 0.25, wind: 0.25, precipitation: 0.3, humidity: 0.1, uv: 0.1 },
    idealTemp: 17,
    tempSigma: 8,
    windLimit: 26,
    windSigma: 14,
  },
  photography: {
    label: 'Fotografia',
    weights: { temperature: 0.1, wind: 0.15, precipitation: 0.35, humidity: 0.1, uv: 0.1 },
    idealTemp: 18,
    tempSigma: 12,
    windLimit: 30,
    windSigma: 16,
  },
  football: {
    label: 'Futebol',
    weights: { temperature: 0.3, wind: 0.15, precipitation: 0.35, humidity: 0.1, uv: 0.1 },
    idealTemp: 19,
    tempSigma: 8,
    windLimit: 30,
    windSigma: 15,
  },
  beach: {
    label: 'Praia',
    weights: { temperature: 0.35, wind: 0.15, precipitation: 0.3, humidity: 0.05, uv: 0.15 },
    idealTemp: 26,
    tempSigma: 5,
    windLimit: 22,
    windSigma: 12,
  },
};

export const ACTIVITY_KEYS = Object.keys(ACTIVITY_META) as ActivityKey[];

/** Curva de satisfação gaussiana, normalizada a 0–100. */
function gaussian(value: number, ideal: number, sigma: number): number {
  const v = Math.exp(-((value - ideal) ** 2) / (2 * sigma * sigma));
  return Math.max(0, Math.min(100, v * 100));
}

function precipScore(mm: number | null, prob: number | null): number {
  if (mm === null && prob === null) return 60;
  const mmScore = mm === null ? 100 : Math.max(0, 100 - mm * 90);
  const probScore = prob === null ? mmScore : Math.max(0, 100 - prob * 0.9);
  return mmScore * 0.6 + probScore * 0.4;
}

function humidityScore(h: number | null): number {
  if (h === null) return 70;
  return Math.max(0, Math.min(100, 100 - Math.abs(h - 50) * 1.4));
}

function uvScore(uv: number | null, limit: number): number {
  if (uv === null) return 70;
  if (uv <= limit) return 100 - uv * 0.5;
  return Math.max(0, 100 - (uv - limit) * 22 - limit * 0.5);
}

function classify(score: number): string {
  if (score >= 80) return 'Excelente';
  if (score >= 65) return 'Bom';
  if (score >= 45) return 'Aceitável';
  if (score >= 30) return 'Fraco';
  return 'Mau';
}

/** Janela de golden hour: 60 min a seguir ao nascer do sol e antes do pôr do sol. */
function isGoldenHour(hourTime: string, daily: DailyPoint | null): boolean {
  if (!daily || !daily.sunrise || !daily.sunset) return false;
  const t = parseLocalIso(hourTime).getTime();
  const rise = parseLocalIso(daily.sunrise).getTime();
  const set = parseLocalIso(daily.sunset).getTime();
  return (t >= rise && t <= rise + 60 * 60000) || (t >= set - 60 * 60000 && t <= set);
}

function dayOfHour(hourIso: string, dailies: DailyPoint[]): DailyPoint | null {
  const dayKey = hourIso.slice(0, 10);
  return dailies.find((d) => d.date === dayKey) ?? null;
}

function scoreHour(
  key: ActivityKey,
  h: HourlyPoint,
  daily: DailyPoint | null,
): { score: number; missing: number; goldenBonus: boolean } {
  const meta = ACTIVITY_META[key];
  const parts: Array<{ weight: number; value: number | null; compute: (v: number) => number }> = [
    { weight: meta.weights.temperature, value: h.temperature, compute: (v) => gaussian(v, meta.idealTemp, meta.tempSigma) },
    { weight: meta.weights.wind, value: h.windSpeed, compute: (v) => gaussian(v, 8, meta.windSigma) },
    { weight: meta.weights.precipitation, value: null, compute: () => precipScore(h.precipitation, h.precipitationProbability) },
    { weight: meta.weights.humidity, value: null, compute: () => humidityScore(h.humidity) },
    { weight: meta.weights.uv, value: null, compute: () => uvScore(h.uvIndex, key === 'beach' ? 10 : 8) },
  ];

  let weighted = 0;
  let weightSum = 0;
  let missing = 0;
  for (const p of parts) {
    let value: number;
    if (p.value !== null) {
      value = p.compute(p.value);
    } else {
      value = p.compute(0);
    }
    weighted += value * p.weight;
    weightSum += p.weight;
  }

  // Penalização de rajadas fortes em atividades expostas.
  if (h.windGusts >= 45) {
    weighted -= Math.min(15, (h.windGusts - 45) * 0.5);
    weightSum += 0;
  }

  const golden = key === 'photography' && h.precipitation < 0.2 && isGoldenHour(h.time, daily);
  let score = weighted / weightSum;
  if (golden) score = Math.min(100, score + 12);
  return { score: Math.max(0, Math.min(100, Math.round(score))), missing, goldenBonus: golden };
}

/**
 * Calcula o índice de atividade para a janela indicada (por defeito, próximas 12h).
 */
export function computeActivityIndex(
  key: ActivityKey,
  hourly: HourlyPoint[],
  dailies: DailyPoint[],
  nowMs: number,
  windowHours = 12,
): ActivityIndex | null {
  const meta = ACTIVITY_META[key];
  const upcoming = hourly
    .filter((h) => parseLocalIso(h.time).getTime() >= nowMs)
    .slice(0, windowHours);

  if (upcoming.length === 0) return null;

  const perHour = upcoming.map((h) => ({
    time: h.time,
    score: scoreHour(key, h, dayOfHour(h.time, dailies)).score,
  }));

  const best = perHour.reduce((acc, cur) => (cur.score > acc.score ? cur : acc), perHour[0]);
  const overall = Math.round(perHour.reduce((sum, p) => sum + p.score, 0) / perHour.length);
  const bestHourMeta = upcoming.find((h) => h.time === best.time);
  const daily = dayOfHour(best.time, dailies);

  const parts: string[] = [];
  if (bestHourMeta) {
    const precip =
      bestHourMeta.precipitation > 0
        ? `${bestHourMeta.precipitation.toFixed(1)} mm`
        : bestHourMeta.precipitationProbability !== null
          ? `${bestHourMeta.precipitationProbability}% de probabilidade de chuva`
          : null;
    parts.push(`${formatHour(best.time)}: ${bestHourMeta.temperature}°C`);
    if (precip) parts.push(precip.replace('% de probabilidade de chuva', '% de prob.'));
    parts.push(`vento ${bestHourMeta.windSpeed} km/h`);
    if (daily?.sunrise && key === 'photography' && isGoldenHour(best.time, daily)) parts.push('golden hour');
  }

  const missingSeries = upcoming.some(
    (h) => h.humidity === null && h.uvIndex === null && h.precipitationProbability === null,
  );

  return {
    key,
    label: meta.label,
    score: overall,
    classification: classify(overall),
    bestHour: best.time,
    justification: parts.length > 0 ? `Melhor às ${formatHour(best.time)} — ${parts.join(', ')}.` : 'Sem dados detalhados suficientes.',
    perHour,
    sufficientData: !missingSeries,
  };
}

export function activityLabel(key: ActivityKey): string {
  return ACTIVITY_META[key].label;
}
