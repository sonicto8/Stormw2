/**
 * Expiração de reportes colaborativos — 2 horas.
 * Helper puro usado pelo cliente para filtragem defensiva e pelos testes.
 */
import type { ActivityReport } from '@/lib/types';

export const REPORT_EXPIRY_MS = 2 * 60 * 60 * 1000;

/** true quando o reporte já ultrapassou as 2 horas de vida. */
export function isReportExpired(report: ActivityReport, nowMs: number): boolean {
  const created = Date.parse(report.createdAt);
  if (Number.isNaN(created)) return true;
  return nowMs - created >= REPORT_EXPIRY_MS;
}

/** Filtra apenas reportes ainda ativos, mais recentes primeiro. */
export function filterActiveReports(reports: ActivityReport[], nowMs: number): ActivityReport[] {
  return reports.filter((r) => !isReportExpired(r, nowMs)).sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
}
