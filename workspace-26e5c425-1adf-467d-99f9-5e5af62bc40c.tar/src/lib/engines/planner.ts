/**
 * Planeador semanal — melhor dia para lavar o carro, estender roupa,
 * atividades ao ar livre e passeio/picnic nos próximos 7 dias.
 * Regras da especificação, avaliadas com os dados efetivos do Open-Meteo.
 */
import type { DailyPoint, PlannerCriterion } from '@/lib/types';
import { formatShortDayLabel } from '@/lib/format';

interface DayEvaluation {
  date: string;
  label: string;
  score: number;
  passes: string[];
  fails: string[];
}

function evaluateDay(d: DailyPoint, criterion: PlannerCriterion['key']): DayEvaluation | null {
  const label = formatShortDayLabel(d.date);
  const passes: string[] = [];
  const fails: string[] = [];
  let score = 0;

  if (criterion === 'car-wash') {
    const dry = d.precipitationSum < 0.1;
    const probOk = d.precipitationProbabilityMax !== null ? d.precipitationProbabilityMax < 20 : false;
    if (dry) passes.push('sem precipitação prevista'); else fails.push(`${d.precipitationSum.toFixed(1)} mm previstos`);
    if (probOk) passes.push(`${d.precipitationProbabilityMax}% de probabilidade`); else fails.push('probabilidade de chuva ≥ 20%');
    score = (dry ? 60 : 0) + (probOk ? 40 : 0);
  }

  if (criterion === 'laundry') {
    const wind = d.windSpeedMean ?? d.windSpeedMax;
    const windOk = wind !== null ? wind >= 5 && wind <= 25 : false;
    const humidityOk = d.humidityMean !== null ? d.humidityMean < 60 : false;
    const dry = d.precipitationSum < 0.1;
    const skyOk = d.weatherCode >= 0 && d.weatherCode <= 2;
    if (windOk) passes.push(`vento ${wind?.toFixed(0)} km/h`); else fails.push('vento fora de 5–25 km/h');
    if (humidityOk) passes.push(`humidade ${d.humidityMean?.toFixed(0)}%`); else fails.push('humidade ≥ 60%');
    if (dry) passes.push('sem chuva'); else fails.push('com chuva');
    if (skyOk) passes.push('céu pouco nublado'); else fails.push(d.weatherLabel.toLowerCase());
    score = (windOk ? 30 : 0) + (humidityOk ? 25 : 0) + (dry ? 25 : 0) + (skyOk ? 20 : 0);
  }

  if (criterion === 'outdoor') {
    const tempOk = d.tempMean !== null ? d.tempMean >= 15 && d.tempMean <= 28 : d.tempMax >= 15 && d.tempMin <= 28;
    const uvOk = d.uvIndexMax !== null ? d.uvIndexMax < 8 : false;
    const windOk = d.windSpeedMax !== null ? d.windSpeedMax < 35 : false;
    if (tempOk) passes.push(`temperatura ${d.tempMin.toFixed(0)}–${d.tempMax.toFixed(0)}°C`); else fails.push('temperatura fora de 15–28°C');
    if (uvOk) passes.push(`UV ${d.uvIndexMax?.toFixed(0)}`); else fails.push('UV ≥ 8');
    if (windOk) passes.push('vento < 35 km/h'); else fails.push('vento ≥ 35 km/h');
    score = (tempOk ? 40 : 0) + (uvOk ? 30 : 0) + (windOk ? 30 : 0);
  }

  if (criterion === 'picnic') {
    const tempOk = d.tempMean !== null ? d.tempMean >= 15 && d.tempMean <= 28 : d.tempMax >= 15 && d.tempMin <= 28;
    const dry = d.precipitationSum < 0.1;
    const windOk = d.windSpeedMax !== null ? d.windSpeedMax < 30 : false;
    const skyOk = d.weatherCode >= 0 && d.weatherCode <= 2;
    if (tempOk) passes.push(`${d.tempMin.toFixed(0)}–${d.tempMax.toFixed(0)}°C`); else fails.push('temperatura desconfortável');
    if (dry) passes.push('sem chuva'); else fails.push('com chuva');
    if (windOk) passes.push('vento moderado'); else fails.push('vento forte');
    if (skyOk) passes.push(d.weatherLabel.toLowerCase()); else fails.push(d.weatherLabel.toLowerCase());
    score = (tempOk ? 35 : 0) + (dry ? 35 : 0) + (windOk ? 15 : 0) + (skyOk ? 15 : 0);
  }

  return { date: d.date, label, score, passes, fails };
}

function buildCriterion(dailies: DailyPoint[], key: PlannerCriterion['key']): PlannerCriterion {
  const evaluated = dailies
    .map((d) => evaluateDay(d, key))
    .filter((e): e is DayEvaluation => e !== null)
    .sort((a, b) => b.score - a.score || a.date.localeCompare(b.date));

  const labels: Record<PlannerCriterion['key'], string> = {
    'car-wash': 'Lavar o carro',
    laundry: 'Estender roupa',
    outdoor: 'Atividades ao ar livre',
    picnic: 'Passeio / Picnic',
  };

  if (evaluated.length === 0) {
    return {
      key,
      label: labels[key],
      winnerDate: null,
      winnerLabel: 'Indisponível',
      justification: 'Sem dados diários suficientes para avaliar este critério.',
      alternatives: [],
      daysToAvoid: [],
      sufficientData: false,
    };
  }

  const winner = evaluated[0];
  const sufficient = winner.score >= 60;
  const alternatives = evaluated.slice(1, 3).map((e) => ({
    date: e.date,
    label: e.label,
    reason: e.score >= 60 ? `${e.passes.join(', ')}.` : `${e.fails.length} condição(ões) não cumpridas: ${e.fails.join(', ')}.`,
  }));
  const daysToAvoid = [...evaluated].reverse().slice(0, 2).filter((e) => e.score <= 30).map((e) => ({
    date: e.date,
    label: e.label,
    reason: e.fails.length > 0 ? e.fails.join(', ') + '.' : 'Pior pontuação da semana.',
  }));

  return {
    key,
    label: labels[key],
    winnerDate: sufficient ? winner.date : null,
    winnerLabel: sufficient ? winner.label : 'Nenhum dia cumpre as regras',
    justification: sufficient
      ? `${winner.label}: ${winner.passes.join(', ')}.`
      : `Nenhum dia nos próximos 7 dias cumpre todas as condições. Melhor aproximação: ${winner.label} (${winner.fails.join(', ') || 'sem falhas'}).`,
    alternatives,
    daysToAvoid,
    sufficientData: true,
  };
}

export function computePlanner(dailies: DailyPoint[]): PlannerCriterion[] {
  const keys: PlannerCriterion['key'][] = ['car-wash', 'laundry', 'outdoor', 'picnic'];
  return keys.map((k) => buildCriterion(dailies, k));
}
