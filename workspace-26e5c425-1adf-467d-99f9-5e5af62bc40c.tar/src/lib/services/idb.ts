/**
 * Wrapper minimalista e tipado de IndexedDB para snapshots offline.
 */
const DB_NAME = 'stormwatch';
const DB_VERSION = 1;
const STORE = 'snapshots';

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB indisponível'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Erro IndexedDB'));
  });
}

export async function idbSet(key: string, value: unknown): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Erro de escrita IndexedDB'));
    });
    db.close();
  } catch {
    // IndexedDB pode estar bloqueado (modo privado) — falha silenciosa,
    // o Service Worker e o localStorage mantêm a resiliência offline.
  }
}

export async function idbGet<T>(key: string): Promise<T | null> {
  try {
    const db = await openDatabase();
    const result = await new Promise<T | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(key);
      req.onsuccess = () => resolve((req.result as T | undefined) ?? null);
      req.onerror = () => reject(req.error ?? new Error('Erro de leitura IndexedDB'));
    });
    db.close();
    return result;
  } catch {
    return null;
  }
}
