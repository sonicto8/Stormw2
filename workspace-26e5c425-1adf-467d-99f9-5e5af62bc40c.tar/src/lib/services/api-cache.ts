/** Instâncias partilhadas de cache de servidor por fonte externa. */
import { ServerCache } from '@/lib/services/server-cache';
import type {
  AirQualityBundle,
  ForecastBundle,
  GridPoint,
  IpmaWarning,
  RadarBundle,
} from '@/lib/types';

export const forecastCache = new ServerCache<ForecastBundle>();
export const airQualityCache = new ServerCache<AirQualityBundle>();
export const ipmaCache = new ServerCache<IpmaWarning[]>();
export const radarCache = new ServerCache<RadarBundle>();
export const gridCache = new ServerCache<GridPoint[]>();

/** Distritos IPMA normalizados (id + nome). */
export interface IpmaDistrictItem {
  id: string;
  name: string;
}
export const districtsCache = new ServerCache<IpmaDistrictItem[]>();

const CACHE_KEY_PREFIX = 'stormwatch:';

export async function persistCache(key: string, payload: unknown, fetchedAt: number): Promise<void> {
  try {
    const { db } = await import('@/lib/db');
    await db.weatherCache.upsert({
      where: { key: CACHE_KEY_PREFIX + key },
      update: { payload: JSON.stringify(payload), fetchedAt: new Date(fetchedAt) },
      create: { key: CACHE_KEY_PREFIX + key, payload: JSON.stringify(payload), fetchedAt: new Date(fetchedAt) },
    });
  } catch {
    // A base de dados pode não estar disponível em dev — a cache de memória mantém-se.
  }
}

export async function loadPersistedCache<T>(key: string): Promise<T | null> {
  try {
    const { db } = await import('@/lib/db');
    const row = await db.weatherCache.findUnique({ where: { key: CACHE_KEY_PREFIX + key } });
    return row ? (JSON.parse(row.payload) as T) : null;
  } catch {
    return null;
  }
}

export async function loadPersistedFetchedAt(key: string): Promise<number | null> {
  try {
    const { db } = await import('@/lib/db');
    const row = await db.weatherCache.findUnique({ where: { key: CACHE_KEY_PREFIX + key } });
    return row ? row.fetchedAt.getTime() : null;
  } catch {
    return null;
  }
}
