/**
 * Cliente HTTP do alerts-service (porta 3003) — pedidos sempre relativos,
 * encaminhados pelo gateway com `XTransformPort=3003`. Respostas sempre
 * validadas com Zod antes de entrar na aplicação.
 */
import { z } from 'zod';
import { ApiClientError } from '@/lib/services/api-client';

export const ALERTS_SERVICE_PORT = 3003;

/** Acrescenta `XTransformPort` a um caminho relativo (mantém query existente). */
export function serviceUrl(path: string, port: number = ALERTS_SERVICE_PORT): string {
  const sep = path.includes('?') ? '&' : '?';
  return `${path}${sep}XTransformPort=${port}`;
}

async function requestService<T>(
  method: 'GET' | 'POST',
  path: string,
  schema: z.ZodType<T>,
  body?: unknown,
  options: { timeoutMs?: number; signal?: AbortSignal } = {},
): Promise<T> {
  const { timeoutMs = 8000, signal } = options;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const onAbort = () => controller.abort();
  signal?.addEventListener('abort', onAbort);

  try {
    const res = await fetch(serviceUrl(path), {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json', Accept: 'application/json' } : { Accept: 'application/json' },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const json: unknown = await res.json().catch(() => null);
    if (!res.ok) {
      const message =
        json !== null &&
        typeof json === 'object' &&
        'error' in json &&
        typeof (json as { error?: unknown }).error === 'string'
          ? (json as { error: string }).error
          : `Serviço de alertas indisponível (erro ${res.status})`;
      throw new ApiClientError(message, res.status, json);
    }
    return schema.parse(json);
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', onAbort);
  }
}

export function fetchService<T>(path: string, schema: z.ZodType<T>, options?: { timeoutMs?: number; signal?: AbortSignal }): Promise<T> {
  return requestService('GET', path, schema, undefined, options);
}

export function postService<T>(path: string, body: unknown, schema: z.ZodType<T>, options?: { timeoutMs?: number; signal?: AbortSignal }): Promise<T> {
  return requestService('POST', path, schema, body, options);
}
