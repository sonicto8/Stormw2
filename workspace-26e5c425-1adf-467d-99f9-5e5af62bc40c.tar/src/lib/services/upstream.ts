/**
 * Fetch server-side para APIs externas com timeout, erro tipado,
 * disjuntor de quota (429) e suporte opcional de chave Open-Meteo.
 *
 * Disjuntor (circuit breaker) por anfitrião: quando uma fonte devolve
 * «Daily/Hourly API request limit exceeded», as chamadas seguintes falham
 * instantaneamente durante uma janela de pausa — em vez de martelar a fonte
 * e tornar cada pedido lento. Durante a pausa, as rotas servem a cache
 * persistida de imediato (com aviso claro na interface).
 */
export class UpstreamError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    public readonly reason?: string,
  ) {
    super(message);
    this.name = 'UpstreamError';
  }
}

const DEFAULT_TIMEOUT = 12000;

/* ─────────────── Chave opcional Open-Meteo (quota própria) ─────────────── */

const OPEN_METEO_HOST = 'api.open-meteo.com';
const OPEN_METEO_API_KEY = process.env.OPEN_METEO_API_KEY?.trim() ?? '';

/** true quando a variável de ambiente OPEN_METEO_API_KEY está definida. */
export function openMeteoKeyConfigured(): boolean {
  return OPEN_METEO_API_KEY.length > 0;
}

/** Acrescenta a chave de API aos pedidos aos domínios Open-Meteo (se configurada). */
function withOpenMeteoKey(url: string): string {
  if (!OPEN_METEO_API_KEY) return url;
  try {
    const parsed = new URL(url);
    if (parsed.hostname.endsWith('open-meteo.com') && !parsed.searchParams.has('apikey')) {
      parsed.searchParams.set('apikey', OPEN_METEO_API_KEY);
    }
    return parsed.toString();
  } catch {
    return url;
  }
}

/* ───────────────────────── Disjuntor de quota por anfitrião ───────────────────────── */

interface BreakerState {
  /** Momento (epoch ms) até ao qual as chamadas falham instantaneamente. */
  openUntil: number;
  reason: string;
}

const breakers = new Map<string, BreakerState>();

/** Pausa quando a quota diária está esgotada (reinicia à meia-noite UTC). */
const DAILY_COOLDOWN_MS = 15 * 60_000;
/** Pausa mais curta para limites horários ou sobrecarga temporária. */
const HOURLY_COOLDOWN_MS = 5 * 60_000;

const COOLDOWN_MESSAGE =
  'Fonte externa em pausa temporária: limite de utilização atingido. A mostrar os últimos dados válidos em cache.';

function hostOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

function isQuotaError(status: number, reason: string): boolean {
  return status === 429 || /limit exceeded|rate limit|too many requests/i.test(reason);
}

function isHourlyLimit(reason: string): boolean {
  return /hourly|hour/i.test(reason);
}

/** ms restantes de pausa para um anfitrião (0 = disjuntor fechado). */
export function upstreamCooldownMs(url: string): number {
  const state = breakers.get(hostOf(url));
  if (!state) return 0;
  return Math.max(0, state.openUntil - Date.now());
}

/* ───────────────────────────────── fetch externo ───────────────────────────────── */

export async function fetchExternal(url: string, timeoutMs: number = DEFAULT_TIMEOUT): Promise<unknown> {
  const host = hostOf(url);

  // Disjuntor aberto: falha instantânea — as rotas seguem para a cache.
  const cooldown = upstreamCooldownMs(url);
  if (cooldown > 0) {
    throw new UpstreamError(COOLDOWN_MESSAGE, 429, 'quota-cooldown');
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(withOpenMeteoKey(url), {
      signal: controller.signal,
      headers: { Accept: 'application/json', 'User-Agent': 'StormWatch/1.0' },
      cache: 'no-store',
    });
    const text = await res.text();
    let json: unknown = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    if (!res.ok) {
      const reason =
        json !== null && typeof json === 'object' && 'reason' in json
          ? String((json as { reason?: unknown }).reason)
          : `HTTP ${res.status}`;
      maybeOpenBreaker(host, res.status, reason);
      throw new UpstreamError(reason, res.status, reason);
    }
    if (json === null) {
      throw new UpstreamError('Resposta não-JSON da fonte externa', 502);
    }
    // Alguns serviços devolvem 200 com error:true no corpo.
    if (typeof json === 'object' && 'error' in json && (json as { error?: unknown }).error === true) {
      const reason =
        'reason' in json ? String((json as { reason?: unknown }).reason) : 'Erro a montante';
      maybeOpenBreaker(host, 429, reason);
      throw new UpstreamError(reason, 502, reason);
    }
    // Sucesso: fecha o disjuntor.
    breakers.delete(host);
    return json;
  } catch (err) {
    if (err instanceof UpstreamError) throw err;
    if (err instanceof Error && err.name === 'AbortError') {
      throw new UpstreamError('Timeout da fonte externa', 504, 'timeout');
    }
    throw new UpstreamError(err instanceof Error ? err.message : 'Erro de rede', 502);
  } finally {
    clearTimeout(timer);
  }
}

/** Abre o disjuntor quando o erro é de quota (com pausa proporcional). */
function maybeOpenBreaker(host: string, status: number, reason: string): void {
  if (!isQuotaError(status, reason)) return;
  const cooldown = isHourlyLimit(reason) ? HOURLY_COOLDOWN_MS : DAILY_COOLDOWN_MS;
  const existing = breakers.get(host);
  // Nunca encurtar uma pausa já em curso.
  const openUntil = Math.max(Date.now() + cooldown, existing?.openUntil ?? 0);
  breakers.set(host, { openUntil, reason: COOLDOWN_MESSAGE });
}

/**
 * Aviso amigável (pt-PT) para dados servidos de cache após falha a montante.
 * Distingue limite de utilização de falha temporária, sem jargão técnico.
 */
export function upstreamStaleNotice(err: unknown, subject: string): string {
  if (err instanceof UpstreamError) {
    if (err.reason === 'quota-cooldown' || err.status === 429) {
      return `${subject} servidos de cache — a fonte externa atingiu o limite de utilização e a app volta a tentar daqui a pouco, automaticamente.`;
    }
    if (err.reason === 'timeout') {
      return `${subject} servidos de cache — a fonte externa não respondeu dentro do tempo limite.`;
    }
  }
  return `${subject} servidos de cache — falha temporária da fonte externa.`;
}
