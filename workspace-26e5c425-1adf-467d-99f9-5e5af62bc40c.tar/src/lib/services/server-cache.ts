/**
 * Cache do lado do servidor: TTL de 10 minutos + "última resposta boa"
 * para degradação elegante quando uma fonte externa falha.
 */
interface CacheEntry<T> {
  data: T;
  /** Epoch ms em que o dado foi obtido a montante. */
  fetchedAt: number;
  /** Epoch ms até quando é considerado fresco (10 min). */
  freshUntil: number;
}

const TTL_MS = 10 * 60 * 1000;

export class ServerCache<T> {
  private cache = new Map<string, CacheEntry<T>>();
  private lastGood = new Map<string, CacheEntry<T>>();

  fresh(key: string): CacheEntry<T> | null {
    const e = this.cache.get(key);
    if (e && Date.now() < e.freshUntil) return e;
    return null;
  }

  /** Devolve a última resposta boa conhecida (qualquer chave mais recente). */
  stale(): T | null {
    const entries = [...this.lastGood.values()].sort((a, b) => b.fetchedAt - a.fetchedAt);
    return entries[0]?.data ?? null;
  }

  staleFor(key: string): T | null {
    return this.lastGood.get(key)?.data ?? null;
  }

  set(key: string, data: T, fetchedAt: number): void {
    const entry: CacheEntry<T> = { data, fetchedAt, freshUntil: fetchedAt + TTL_MS };
    this.cache.set(key, entry);
    this.lastGood.set(key, entry);
  }
}

export const CACHE_TTL_MS = TTL_MS;
