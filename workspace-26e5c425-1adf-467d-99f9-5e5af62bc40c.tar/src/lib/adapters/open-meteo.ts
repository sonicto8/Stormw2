/**
 * Adaptador Open-Meteo — converte a resposta original (com arrays paralelos)
 * nos modelos internos tipados. Nunca assume que a API respondeu corretamente:
 * valida com Zod, cruza comprimentos e preserva valores nulos.
 */
import {
  openMeteoForecastSchema,
  openMeteoGeocodingSchema,
  openMeteoGridSchema,
  type OpenMeteoForecastResponse,
} from '@/lib/schemas/open-meteo.schema';
import type {
  CurrentWeather,
  DailyPoint,
  ForecastBundle,
  GeocodingPlace,
  GridPoint,
  HourlyPoint,
  MinutelyPoint,
} from '@/lib/types';
import { weatherLabel, weatherMeteocon } from '@/lib/weather-codes';
import type { QuickLocation } from '@/lib/locations';

export class AdapterError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AdapterError';
  }
}

/** Cruza um array paralelo com o array de tempos; devolve null quando em falta. */
function zipSeries(times: string[], series: (number | null)[] | undefined): Array<number | null> {
  if (!series) return times.map(() => null);
  return times.map((_, i) => series[i] ?? null);
}

export function adaptForecast(
  raw: unknown,
  fetchedAt: number,
  source: ForecastBundle['source'],
): ForecastBundle {
  const data: OpenMeteoForecastResponse = openMeteoForecastSchema.parse(raw);

  const c = data.current;
  const hourlyRaw = data.hourly;
  const hourlyTimes = hourlyRaw?.time ?? [];

  /** Visibilidade da hora mais próxima do instante atual (a fonte só fornece valores horários). */
  const visibilityNow = (() => {
    const series = zipSeries(hourlyTimes, hourlyRaw?.visibility);
    const hourKey = c.time.slice(0, 13);
    const idx = hourlyTimes.findIndex((t) => t.slice(0, 13) === hourKey);
    return idx >= 0 ? series[idx] : null;
  })();

  const current: CurrentWeather = {
    time: c.time,
    temperature: c.temperature_2m,
    apparentTemperature: c.apparent_temperature,
    humidity: c.relative_humidity_2m ?? null,
    isDay: c.is_day === 1,
    precipitation: c.precipitation,
    weatherCode: c.weather_code,
    weatherLabel: weatherLabel(c.weather_code),
    meteocon: weatherMeteocon(c.weather_code, c.is_day === 1),
    cloudCover: c.cloud_cover ?? null,
    pressureMsl: c.pressure_msl ?? null,
    visibility: visibilityNow,
    windSpeed: c.wind_speed_10m,
    windDirection: c.wind_direction_10m ?? null,
    windGusts: c.wind_gusts_10m,
    uvIndex: c.uv_index ?? null,
  };

  const hourly: HourlyPoint[] = hourlyTimes.map((time, i) => {
    const values = {
      temperature: zipSeries(hourlyTimes, hourlyRaw?.temperature_2m)[i],
      apparentTemperature: zipSeries(hourlyTimes, hourlyRaw?.apparent_temperature)[i],
      precipitationProbability: zipSeries(hourlyTimes, hourlyRaw?.precipitation_probability)[i],
      precipitation: zipSeries(hourlyTimes, hourlyRaw?.precipitation)[i],
      weatherCode: zipSeries(hourlyTimes, hourlyRaw?.weather_code)[i],
      humidity: zipSeries(hourlyTimes, hourlyRaw?.relative_humidity_2m)[i],
      visibility: zipSeries(hourlyTimes, hourlyRaw?.visibility)[i],
      windSpeed: zipSeries(hourlyTimes, hourlyRaw?.wind_speed_10m)[i],
      windGusts: zipSeries(hourlyTimes, hourlyRaw?.wind_gusts_10m)[i],
      cloudCover: zipSeries(hourlyTimes, hourlyRaw?.cloud_cover)[i],
      uvIndex: zipSeries(hourlyTimes, hourlyRaw?.uv_index)[i],
      isDay: zipSeries(hourlyTimes, hourlyRaw?.is_day)[i],
    };
    const isDay = values.isDay === null ? true : values.isDay === 1;
    const code = values.weatherCode === null ? null : values.weatherCode;
    return {
      time,
      temperature: values.temperature ?? 0,
      apparentTemperature: values.apparentTemperature ?? values.temperature ?? 0,
      precipitationProbability: values.precipitationProbability,
      precipitation: values.precipitation ?? 0,
      weatherCode: code === null ? 0 : code,
      weatherLabel: weatherLabel(code),
      meteocon: weatherMeteocon(code, isDay),
      humidity: values.humidity,
      visibility: values.visibility,
      windSpeed: values.windSpeed ?? 0,
      windGusts: values.windGusts ?? 0,
      cloudCover: values.cloudCover,
      uvIndex: values.uvIndex,
      isDay,
    };
  });

  const minutelyRaw = data.minutely_15;
  const minutelyTimes = minutelyRaw?.time ?? [];
  const minutely15: MinutelyPoint[] = minutelyTimes.map((time, i) => ({
    time,
    precipitation: zipSeries(minutelyTimes, minutelyRaw?.precipitation)[i],
    weatherCode: zipSeries(minutelyTimes, minutelyRaw?.weather_code)[i],
  }));

  const dailyRaw = data.daily;
  const dailyTimes = dailyRaw?.time ?? [];
  const dailyAll: DailyPoint[] = dailyTimes.map((date, i) => {
    const pick = (arr: (number | null)[] | undefined) => zipSeries(dailyTimes, arr)[i];
    const code = pick(dailyRaw?.weather_code);
    return {
      date,
      weatherCode: code === null ? 0 : code,
      weatherLabel: weatherLabel(code),
      meteocon: weatherMeteocon(code, true),
      tempMax: pick(dailyRaw?.temperature_2m_max) ?? 0,
      tempMin: pick(dailyRaw?.temperature_2m_min) ?? 0,
      tempMean: pick(dailyRaw?.temperature_2m_mean),
      apparentMax: pick(dailyRaw?.apparent_temperature_max),
      apparentMin: pick(dailyRaw?.apparent_temperature_min),
      precipitationSum: pick(dailyRaw?.precipitation_sum) ?? 0,
      precipitationHours: pick(dailyRaw?.precipitation_hours),
      precipitationProbabilityMax: pick(dailyRaw?.precipitation_probability_max),
      windSpeedMax: pick(dailyRaw?.wind_speed_10m_max),
      windSpeedMean: pick(dailyRaw?.wind_speed_10m_mean),
      windGustsMax: pick(dailyRaw?.wind_gusts_10m_max),
      humidityMean: pick(dailyRaw?.relative_humidity_2m_mean),
      cloudCoverMean: pick(dailyRaw?.cloud_cover_mean),
      uvIndexMax: pick(dailyRaw?.uv_index_max),
      sunrise: dailyRaw?.sunrise?.[i] ?? null,
      sunset: dailyRaw?.sunset?.[i] ?? null,
    };
  });

  // Divisão histórico/previsão: os dias anteriores a hoje (data local do local)
  // são histórico; os restantes são previsão. Sem past_days o comportamento
  // mantém-se idêntico ao anterior (tudo é previsão).
  const utcOffsetSeconds = data.utc_offset_seconds ?? 0;
  const todayKey = new Date(fetchedAt + utcOffsetSeconds * 1000).toISOString().slice(0, 10);
  const splitIndex = Math.max(0, dailyAll.findIndex((d) => d.date >= todayKey));
  const historyDaily = dailyAll.slice(0, splitIndex);
  const daily = dailyAll.slice(splitIndex);

  // As horas anteriores a hoje não são necessárias para a UI (timeline/gráficos
  // começam «agora»); cortadas para manter o payload leve.
  const firstHourToday = hourlyTimes.findIndex((t) => t.slice(0, 10) >= todayKey);
  const hourlyTrimmed = firstHourToday > 0 ? hourly.slice(firstHourToday) : hourly;

  return {
    latitude: data.latitude,
    longitude: data.longitude,
    elevation: data.elevation ?? null,
    timezone: data.timezone,
    current,
    hourly: hourlyTrimmed,
    minutely15,
    daily,
    historyDaily,
    fetchedAt,
    source,
  };
}

export function adaptGeocoding(raw: unknown): GeocodingPlace[] {
  const data = openMeteoGeocodingSchema.parse(raw);
  return (data.results ?? []).map((r) => ({
    id: r.id,
    name: r.name,
    latitude: r.latitude,
    longitude: r.longitude,
    country: r.country ?? null,
    admin1: r.admin1 ?? null,
    timezone: r.timezone ?? null,
  }));
}

/**
 * Adaptador do pedido em lote para os mapas de variáveis. As respostas chegam
 * pela mesma ordem das coordenadas pedidas; o cruzamento é feito por índice e
 * qualquer desvio de comprimento é rejeitado.
 */
export function adaptGrid(raw: unknown, points: QuickLocation[], fetchedAt: number): GridPoint[] {
  const data = openMeteoGridSchema.parse(raw);
  if (data.length !== points.length) {
    throw new AdapterError(
      `Resposta do lote incompleta: esperados ${points.length}, recebidos ${data.length}`,
    );
  }
  return data.map((loc, i) => {
    const point = points[i];
    const cur = loc.current;
    const isDay = cur.is_day === undefined ? true : cur.is_day === 1;
    return {
      id: point.id,
      name: point.name,
      admin: point.admin,
      latitude: loc.latitude,
      longitude: loc.longitude,
      temperature: cur.temperature_2m,
      weatherCode: cur.weather_code,
      weatherLabel: weatherLabel(cur.weather_code),
      meteocon: weatherMeteocon(cur.weather_code, isDay),
      cloudCover: cur.cloud_cover ?? null,
      windSpeed: cur.wind_speed_10m,
      windDirection: cur.wind_direction_10m ?? null,
      windGusts: cur.wind_gusts_10m,
      fetchedAt,
    };
  });
}
