/**
 * Adaptador dos avisos oficiais do IPMA (warnings_www.json).
 * Normaliza o formato cru (awarenessLevelId y/o/r, awarenessTypeId) para o
 * modelo interno, com IDs determinísticos (areaId + início + nível).
 */
import { ipmaWarningsSchema, type IpmaRawWarning } from '@/lib/schemas/ipma.schema';
import type { IpmaLevel, IpmaWarning } from '@/lib/types';

const PHENOMEN_LABELS: Record<string, string> = {
  rain: 'Chuva',
  thunderstorm: 'Trovoada',
  wind: 'Vento',
  snow: 'Neve',
  ice: 'Gelo',
  fog: 'Nevoeiro',
  heat: 'Calor',
  cold: 'Frio',
  coastal: 'Ondas de mar',
  fire: 'Risco de incêndio',
  air: 'Qualidade do ar',
  uv: 'Radiação UV',
};

/** awarenessTypeId (código oficial IPMA) → fenómeno interno. */
const AWARENESS_TYPE_TO_PHENOMEN: Record<number, string> = {
  1: 'wind',
  2: 'snow',
  3: 'thunderstorm',
  4: 'fog',
  5: 'heat',
  6: 'cold',
  7: 'coastal',
  8: 'fire',
  10: 'rain',
  11: 'rain',
};

/** awarenessLevelId do IPMA → nível interno (cor oficial preservada). */
const LEVEL_MAP: Record<string, IpmaLevel> = {
  y: 'yellow',
  o: 'orange',
  r: 'red',
  yellow: 'yellow',
  orange: 'orange',
  red: 'red',
};

/** Descrição PT do tipo → fenómeno interno (fallback quando não há id numérico). */
const DESCRIPTION_TO_PHENOMEN: Record<string, string> = {
  precipitacao: 'rain',
  chuva: 'rain',
  trovoada: 'thunderstorm',
  vento: 'wind',
  ventos: 'wind',
  neve: 'snow',
  gelo: 'ice',
  nevoeiro: 'fog',
  calor: 'heat',
  'temperaturas extremas': 'heat',
  frio: 'cold',
  'ondas de mar': 'coastal',
  'ondas de mar agitadas': 'coastal',
  'risco de incendio': 'fire',
};

function normalizeText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim();
}

function resolveLevel(raw: IpmaRawWarning): IpmaLevel | null {
  const levelId = raw.awarenessLevelId ?? raw.level;
  if (!levelId) return null;
  return LEVEL_MAP[normalizeText(levelId)] ?? null;
}

function resolvePhenomen(raw: IpmaRawWarning): string | null {
  if (raw.phenomen) return raw.phenomen;
  if (raw.awarenessTypeId !== undefined && AWARENESS_TYPE_TO_PHENOMEN[raw.awarenessTypeId]) {
    return AWARENESS_TYPE_TO_PHENOMEN[raw.awarenessTypeId];
  }
  const description = raw.awarenessTypeDescriptionPT ?? raw.awarenessTypeDescription;
  if (description) {
    const mapped = DESCRIPTION_TO_PHENOMEN[normalizeText(description)];
    if (mapped) return mapped;
  }
  return null;
}

function resolveArea(raw: IpmaRawWarning): string {
  return (raw.area ?? raw.areaID ?? raw.areaId ?? '').trim();
}

export function adaptIpmaWarnings(raw: unknown): IpmaWarning[] {
  const data = ipmaWarningsSchema.parse(raw);
  const entries: IpmaRawWarning[] = data.forecast ?? [];

  const warnings: IpmaWarning[] = [];
  for (const raw of entries) {
    const level = resolveLevel(raw);
    if (!level) continue; // Sem nível reconhecível → ignorar (não inventar cor).
    const area = resolveArea(raw);
    if (area.length === 0) continue;
    const start = raw.startTime ?? raw.start ?? '';
    const end = raw.endTime ?? raw.end ?? '';
    if (start.length === 0 || end.length === 0) continue;
    const phenomen = resolvePhenomen(raw);
    warnings.push({
      id: raw.id !== undefined ? String(raw.id) : `${raw.areaId ?? area}-${start}-${level}`,
      level,
      area,
      phenomen: phenomen ?? 'desconhecido',
      phenomenLabel: (phenomen && PHENOMEN_LABELS[phenomen]) || raw.awarenessTypeDescriptionPT || 'Condição adversa',
      description: raw.textPT ?? raw.text ?? raw.description ?? '',
      start,
      end,
    });
  }
  return warnings;
}
