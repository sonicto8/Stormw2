/** Adaptador do RainViewer (frames de radar). */
import { rainViewerSchema } from '@/lib/schemas/rainviewer.schema';
import type { RadarBundle, RadarFrame } from '@/lib/types';

export function adaptRainViewer(raw: unknown, fetchedAt: number): RadarBundle {
  const data = rainViewerSchema.parse(raw);
  const past = (data.radar?.past ?? []).map<RadarFrame>((f) => ({
    time: f.time,
    path: f.path,
    kind: 'past',
  }));
  const nowcast = (data.radar?.nowcast ?? []).map<RadarFrame>((f) => ({
    time: f.time,
    path: f.path,
    kind: 'nowcast',
  }));
  const host = data.host ?? 'https://tilecache.rainviewer.com';
  return {
    host,
    generated: data.generated ?? Math.floor(fetchedAt / 1000),
    frames: [...past, ...nowcast],
    fetchedAt,
  };
}

/**
 * URL do tile de radar. A imagem vem do CDN do RainViewer (tilecache),
 * construída a partir dos paths validados pelo adaptador.
 */
export function radarTileUrl(
  host: string,
  frame: RadarFrame,
  z: number,
  x: number,
  y: number,
): string {
  return `${host}${frame.path}/256/${z}/${x}/${y}/6/1_1.png`;
}
