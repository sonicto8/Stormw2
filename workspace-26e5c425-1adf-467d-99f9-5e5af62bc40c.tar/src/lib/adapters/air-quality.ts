/** Adaptador da API de qualidade do ar Open-Meteo. */
import { airQualitySchema } from '@/lib/schemas/air-quality.schema';
import type { AirQualityBundle } from '@/lib/types';

export function adaptAirQuality(
  raw: unknown,
  fetchedAt: number,
  source: AirQualityBundle['source'],
): AirQualityBundle {
  const data = airQualitySchema.parse(raw);
  const c = data.current;
  return {
    time: c?.time ?? data.time ?? new Date(fetchedAt).toISOString(),
    europeanAqi: c?.european_aqi ?? null,
    pm10: c?.pm10 ?? null,
    pm25: c?.pm2_5 ?? null,
    ozone: c?.ozone ?? null,
    no2: c?.nitrogen_dioxide ?? null,
    so2: c?.sulphur_dioxide ?? null,
    fetchedAt,
    source,
  };
}
