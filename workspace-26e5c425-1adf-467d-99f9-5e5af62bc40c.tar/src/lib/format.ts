/**
 * Formatação em português europeu (pt-PT).
 * Os tempos do Open-Meteo chegam como ISO *local* ("2026-11-26T14:00").
 * Convenção: tratar como UTC e formatar em UTC — preserva o relógio local do
 * local sem dupla conversão de fuso.
 */
import type { Profile } from '@/lib/schemas/report.schema';

const UTC = 'UTC';
const LISBON = 'Europe/Lisbon';

export function parseLocalIso(iso: string): Date {
  if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return new Date(`${iso}T00:00:00Z`);
  const normalized = iso.endsWith('Z') || iso.includes('+') ? iso : `${iso}Z`;
  const withSeconds = /:\d{2}$/.test(normalized) ? normalized : `${normalized.slice(0, 16)}:00Z`;
  return new Date(withSeconds);
}

export function formatHour(iso: string): string {
  const h = parseLocalIso(iso);
  const formatted = new Intl.DateTimeFormat('pt-PT', { hour: '2-digit', timeZone: UTC }).format(h);
  // pt-PT omite os minutos («14»); garantir o sufixo «h» nas horas certas.
  return formatted.includes(':') ? formatted.replace(':00', 'h') : `${formatted}h`;
}

export function formatTime(iso: string, zone: string = LISBON): string {
  const d = parseLocalIso(iso);
  const tz = iso.endsWith('Z') || iso.includes('+') ? zone : UTC;
  return new Intl.DateTimeFormat('pt-PT', { hour: '2-digit', minute: '2-digit', timeZone: tz }).format(d);
}

export function formatWeekday(iso: string, style: 'short' | 'long' = 'short'): string {
  const d = parseLocalIso(iso);
  return new Intl.DateTimeFormat('pt-PT', { weekday: style, timeZone: UTC }).format(d);
}

export function formatDayMonth(iso: string): string {
  const d = parseLocalIso(iso);
  return new Intl.DateTimeFormat('pt-PT', { day: 'numeric', month: 'short', timeZone: UTC }).format(d);
}

export function formatDayLabel(dateIso: string): string {
  return `${formatWeekday(dateIso, 'long')}, ${formatDayMonth(dateIso)}`;
}

export function formatShortDayLabel(dateIso: string): string {
  return `${formatWeekday(dateIso)}, ${formatDayMonth(dateIso)}`;
}

export function formatClockTime(ms: number, zone: string = LISBON): string {
  return new Intl.DateTimeFormat('pt-PT', { hour: '2-digit', minute: '2-digit', timeZone: zone }).format(new Date(ms));
}

export function formatDateTimeMs(ms: number, zone: string = LISBON): string {
  return new Intl.DateTimeFormat('pt-PT', {
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: zone,
  }).format(new Date(ms));
}

export function formatRelative(ms: number, now: number): string {
  const diff = Math.round((now - ms) / 1000);
  if (diff < 60) return 'agora mesmo';
  if (diff < 3600) return `há ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `há ${Math.floor(diff / 3600)} h`;
  return `há ${Math.floor(diff / 86400)} d`;
}

export function formatTemp(celsius: number, unit: Profile['temperatureUnit'] = 'celsius'): string {
  const value = unit === 'fahrenheit' ? celsius * 1.8 + 32 : celsius;
  return `${new Intl.NumberFormat('pt-PT', { maximumFractionDigits: 0 }).format(value)}°`;
}

export function formatTempValue(celsius: number, unit: Profile['temperatureUnit'] = 'celsius'): string {
  const value = unit === 'fahrenheit' ? celsius * 1.8 + 32 : celsius;
  return `${new Intl.NumberFormat('pt-PT', { maximumFractionDigits: 1 }).format(value)} °${unit === 'fahrenheit' ? 'F' : 'C'}`;
}

export function formatNumber(value: number, digits = 0): string {
  return new Intl.NumberFormat('pt-PT', { maximumFractionDigits: digits }).format(value);
}

export function formatWind(kmh: number, unit: Profile['windUnit'] = 'kmh'): string {
  if (unit === 'ms') {
    return `${formatNumber(kmh / 3.6, 1)} m/s`;
  }
  return `${formatNumber(kmh, 0)} km/h`;
}

const WIND_DIRECTIONS = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'] as const;

export function windDirectionLabel(deg: number | null): string {
  if (deg === null) return '—';
  const idx = Math.round(((deg % 360) + 360) % 360 / 45) % 8;
  return WIND_DIRECTIONS[idx];
}

export function uvLabel(uv: number | null): string {
  if (uv === null) return '—';
  if (uv < 3) return 'Baixo';
  if (uv < 6) return 'Moderado';
  if (uv < 8) return 'Alto';
  if (uv < 11) return 'Muito alto';
  return 'Extremo';
}

export function aqiLabel(aqi: number | null): { label: string; tone: 'good' | 'fair' | 'moderate' | 'poor' | 'very-poor' | 'unknown' } {
  if (aqi === null) return { label: '—', tone: 'unknown' };
  if (aqi <= 20) return { label: 'Muito boa', tone: 'good' };
  if (aqi <= 40) return { label: 'Boa', tone: 'fair' };
  if (aqi <= 60) return { label: 'Moderada', tone: 'moderate' };
  if (aqi <= 80) return { label: 'Fraca', tone: 'poor' };
  if (aqi <= 100) return { label: 'Má', tone: 'poor' };
  return { label: 'Muito má', tone: 'very-poor' };
}

/** Distância em km entre dois pontos (Haversine). */
export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`;
  if (km < 10) return `${formatNumber(km, 1)} km`;
  return `${formatNumber(km, 0)} km`;
}

/** Minutos desde o início do dia de um ISO local. */
export function minutesOfDay(iso: string): number {
  const d = parseLocalIso(iso);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
}
