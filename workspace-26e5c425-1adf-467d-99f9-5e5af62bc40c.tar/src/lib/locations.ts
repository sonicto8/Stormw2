/** Localidades portuguesas de referência (coordenadas públicas conhecidas). */
export interface QuickLocation {
  id: string;
  name: string;
  admin: string;
  latitude: number;
  longitude: number;
}

export const QUICK_LOCATIONS: QuickLocation[] = [
  { id: 'lisboa', name: 'Lisboa', admin: 'Grande Lisboa', latitude: 38.7223, longitude: -9.1393 },
  { id: 'porto', name: 'Porto', admin: 'Grande Porto', latitude: 41.1496, longitude: -8.6109 },
  { id: 'coimbra', name: 'Coimbra', admin: 'Baixo Mondego', latitude: 40.2033, longitude: -8.4103 },
  { id: 'braga', name: 'Braga', admin: 'Cávado', latitude: 41.5454, longitude: -8.4265 },
  { id: 'faro', name: 'Faro', admin: 'Algarve', latitude: 37.0194, longitude: -7.9304 },
  { id: 'aveiro', name: 'Aveiro', admin: 'Baixo Vouga', latitude: 40.6405, longitude: -8.6538 },
  { id: 'setubal', name: 'Setúbal', admin: 'Península de Setúbal', latitude: 38.5244, longitude: -8.8882 },
  { id: 'evora', name: 'Évora', admin: 'Alentejo Central', latitude: 38.5714, longitude: -7.9135 },
  { id: 'viseu', name: 'Viseu', admin: 'Dão-Lafões', latitude: 40.6566, longitude: -7.9125 },
  { id: 'leiria', name: 'Leiria', admin: 'Pinhal Litoral', latitude: 39.7436, longitude: -8.8071 },
  { id: 'santarem', name: 'Santarém', admin: 'Lezíria', latitude: 39.3346, longitude: -8.8555 },
  { id: 'vila-real', name: 'Vila Real', admin: 'Trás-os-Montes', latitude: 41.3006, longitude: -7.7441 },
  { id: 'beja', name: 'Beja', admin: 'Baixo Alentejo', latitude: 38.0151, longitude: -7.8631 },
  { id: 'castelo-branco', name: 'Castelo Branco', admin: 'Beira Interior', latitude: 39.8222, longitude: -7.4908 },
  { id: 'guarda', name: 'Guarda', admin: 'Beira Interior Norte', latitude: 40.5378, longitude: -7.2658 },
  { id: 'portalegre', name: 'Portalegre', admin: 'Alto Alentejo', latitude: 39.2938, longitude: -7.4308 },
  { id: 'braganca', name: 'Bragança', admin: 'Trás-os-Montes', latitude: 41.8061, longitude: -6.7569 },
  { id: 'viana', name: 'Viana do Castelo', admin: 'Minho-Lima', latitude: 41.6946, longitude: -8.8317 },
  { id: 'funchal', name: 'Funchal', admin: 'Madeira', latitude: 32.6538, longitude: -16.9172 },
  { id: 'ponta-delgada', name: 'Ponta Delgada', admin: 'Açores', latitude: 37.7412, longitude: -25.6756 },
  { id: 'angra', name: 'Angra do Heroísmo', admin: 'Açores', latitude: 38.6539, longitude: -27.2196 },
  { id: 'horta', name: 'Horta', admin: 'Açores', latitude: 38.5899, longitude: -28.6285 },
];
