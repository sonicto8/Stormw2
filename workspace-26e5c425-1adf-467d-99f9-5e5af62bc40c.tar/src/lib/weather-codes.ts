import type { MeteoconKey } from '@/lib/types';

export interface WeatherCodeInfo {
  label: string;
  /** Meteocon de dia. */
  day: MeteoconKey;
  /** Meteocon de noite. */
  night: MeteoconKey;
  /** Grupo para lógica de atmosfera/índices. */
  group:
    | 'clear'
    | 'partly'
    | 'cloudy'
    | 'fog'
    | 'drizzle'
    | 'rain'
    | 'heavy-rain'
    | 'freezing'
    | 'snow'
    | 'thunder';
}

/**
 * Códigos WMO 4677 (usados pelo Open-Meteo) com descrição em português europeu.
 */
const CODES: Record<number, WeatherCodeInfo> = {
  0: { label: 'Céu limpo', day: 'clear-day', night: 'clear-night', group: 'clear' },
  1: { label: 'Geralmente limpo', day: 'partly-day', night: 'partly-night', group: 'partly' },
  2: { label: 'Parcialmente nublado', day: 'partly-day', night: 'partly-night', group: 'partly' },
  3: { label: 'Encoberto', day: 'overcast', night: 'overcast', group: 'cloudy' },
  45: { label: 'Nevoeiro', day: 'fog', night: 'fog', group: 'fog' },
  48: { label: 'Nevoeiro gelado', day: 'fog', night: 'fog', group: 'fog' },
  51: { label: 'Chuvisco fraco', day: 'drizzle', night: 'drizzle', group: 'drizzle' },
  53: { label: 'Chuvisco moderado', day: 'drizzle', night: 'drizzle', group: 'drizzle' },
  55: { label: 'Chuvisco intenso', day: 'drizzle', night: 'drizzle', group: 'drizzle' },
  56: { label: 'Chuvisco gelado fraco', day: 'freezing-rain', night: 'freezing-rain', group: 'freezing' },
  57: { label: 'Chuvisco gelado intenso', day: 'freezing-rain', night: 'freezing-rain', group: 'freezing' },
  61: { label: 'Chuva fraca', day: 'rain', night: 'rain', group: 'rain' },
  63: { label: 'Chuva moderada', day: 'rain', night: 'rain', group: 'rain' },
  65: { label: 'Chuva forte', day: 'heavy-rain', night: 'heavy-rain', group: 'heavy-rain' },
  66: { label: 'Chuva gelada fraca', day: 'freezing-rain', night: 'freezing-rain', group: 'freezing' },
  67: { label: 'Chuva gelada forte', day: 'freezing-rain', night: 'freezing-rain', group: 'freezing' },
  71: { label: 'Neve fraca', day: 'snow', night: 'snow', group: 'snow' },
  73: { label: 'Neve moderada', day: 'snow', night: 'snow', group: 'snow' },
  75: { label: 'Neve forte', day: 'snow', night: 'snow', group: 'snow' },
  77: { label: 'Grãos de neve', day: 'snow', night: 'snow', group: 'snow' },
  80: { label: 'Aguaceiros fracos', day: 'rain', night: 'rain', group: 'rain' },
  81: { label: 'Aguaceiros moderados', day: 'rain', night: 'rain', group: 'rain' },
  82: { label: 'Aguaceiros violentos', day: 'heavy-rain', night: 'heavy-rain', group: 'heavy-rain' },
  85: { label: 'Aguaceiros de neve fracos', day: 'snow', night: 'snow', group: 'snow' },
  86: { label: 'Aguaceiros de neve fortes', day: 'snow', night: 'snow', group: 'snow' },
  95: { label: 'Trovoada', day: 'thunder', night: 'thunder', group: 'thunder' },
  96: { label: 'Trovoada com granizo', day: 'thunder-hail', night: 'thunder-hail', group: 'thunder' },
  99: { label: 'Trovoada forte com granizo', day: 'thunder-hail', night: 'thunder-hail', group: 'thunder' },
};

const FALLBACK: WeatherCodeInfo = {
  label: 'Condição desconhecida',
  day: 'overcast',
  night: 'overcast',
  group: 'cloudy',
};

/** Devolve a descrição pt-PT e o meteocon de um código WMO. */
export function weatherCodeInfo(code: number | null | undefined, isDay: boolean): WeatherCodeInfo {
  if (code === null || code === undefined) return FALLBACK;
  const info = CODES[code] ?? FALLBACK;
  return { ...info, label: info.label };
}

export function weatherLabel(code: number | null | undefined): string {
  if (code === null || code === undefined) return FALLBACK.label;
  return (CODES[code] ?? FALLBACK).label;
}

export function weatherMeteocon(code: number | null | undefined, isDay: boolean): MeteoconKey {
  if (code === null || code === undefined) return isDay ? 'clear-day' : 'clear-night';
  const info = CODES[code] ?? FALLBACK;
  return isDay ? info.day : info.night;
}

export function weatherGroup(code: number | null | undefined): WeatherCodeInfo['group'] {
  if (code === null || code === undefined) return FALLBACK.group;
  return (CODES[code] ?? FALLBACK).group;
}
