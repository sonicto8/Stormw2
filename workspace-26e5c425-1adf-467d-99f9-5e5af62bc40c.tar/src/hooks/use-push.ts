'use client';

/**
 * Web Push (VAPID) para STORMWATCH — subscreve o dispositivo no
 * alerts-service (porta 3003) e envia a notificação de teste
 * «STORMWATCH — Notificações ativadas».
 *
 * Estados tratados explicitamente (nunca falha em silêncio):
 *  · navegador sem suporte (PushManager/Notification ausentes);
 *  · serviço sem chaves VAPID configuradas → `pushConfigured: false`;
 *  · iOS sem PWA instalada no ecrã principal (limitação do iOS 16.4+);
 *  · permissão recusada pelo utilizador.
 */
import { useCallback, useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import {
  pushSubscribeResponseSchema,
  pushTestResponseSchema,
  pushUnsubscribeResponseSchema,
  serviceStatusSchema,
  type ServiceStatus,
} from '@/lib/schemas/alerts-service.schema';
import { fetchService, postService } from '@/lib/services/alerts-service-client';

const ENDPOINT_KEY = 'stormwatch-push-endpoint';

function base64UrlToUint8Array(base64Url: string): Uint8Array {
  const padding = '='.repeat((4 - (base64Url.length % 4)) % 4);
  const base64 = `${base64Url.replace(/-/g, '+').replace(/_/g, '/')}${padding}`;
  const raw = atob(base64);
  const output = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i += 1) {
    output[i] = raw.charCodeAt(i);
  }
  return output;
}

function isIos(): boolean {
  if (typeof navigator === 'undefined') return false;
  return (
    /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
  );
}

function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

export function useServiceStatus() {
  return useQuery<ServiceStatus, Error>({
    queryKey: ['push-status'],
    queryFn: ({ signal }) => fetchService('/api/status', serviceStatusSchema, { signal, timeoutMs: 5000 }),
    staleTime: 30 * 1000,
    refetchInterval: 2 * 60 * 1000,
    retry: 0,
  });
}

export function usePushNotifications() {
  const qc = useQueryClient();
  const status = useServiceStatus();
  const [subscribed, setSubscribed] = useState(false);
  const [checking, setChecking] = useState(true);
  const [permission, setPermission] = useState<NotificationPermission | 'unsupported'>('default');
  const [supported, setSupported] = useState(true);
  const [standalone, setStandalone] = useState(true);

  // Estado atual da subscrição (sobrevive a recarregamentos — vive no browser).
  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      const pushSupported =
        typeof window !== 'undefined' && 'serviceWorker' in navigator && 'PushManager' in window && typeof Notification !== 'undefined';
      setSupported(pushSupported);
      setStandalone(isStandalone());
      setPermission(pushSupported ? Notification.permission : 'unsupported');
      if (!pushSupported) {
        setSubscribed(false);
        setChecking(false);
        return;
      }
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        const existing = await registration?.pushManager.getSubscription();
        if (!cancelled) setSubscribed(Boolean(existing));
      } catch {
        if (!cancelled) setSubscribed(false);
      } finally {
        if (!cancelled) setChecking(false);
      }
    };
    void check();
    return () => {
      cancelled = true;
    };
  }, []);

  const refresh = useCallback(() => {
    void qc.invalidateQueries({ queryKey: ['push-status'] });
    if (typeof Notification !== 'undefined') setPermission(Notification.permission);
  }, [qc]);

  const enableMutation = useMutation<void, Error, void>({
    mutationFn: async () => {
      if (!status.data?.pushConfigured || status.data.vapidPublicKey === null) {
        throw new Error('Serviço de alertas sem chaves VAPID configuradas — vê o README do alerts-service.');
      }
      if (isIos() && !isStandalone()) {
        throw new Error('No iPhone, instala primeiro a app no ecrã principal (Safari → Partilhar → Adicionar ao Ecrã Inicial) e abre-a pelo ícone.');
      }

      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== 'granted') {
        throw new Error('Autorização de notificações recusada pelo navegador.');
      }

      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;

      const applicationServerKey = base64UrlToUint8Array(status.data.vapidPublicKey) as BufferSource;
      const subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey });

      const payload = subscription.toJSON() as { endpoint: string };
      await postService('/api/subscribe', { subscription: subscription.toJSON() }, pushSubscribeResponseSchema, { timeoutMs: 8000 });

      try {
        localStorage.setItem(ENDPOINT_KEY, payload.endpoint);
      } catch {
        // Sem localStorage (modo privado) — a subscrição continua válida.
      }

      // Notificação de teste imediata (guia: «STORMWATCH — Notificações ativadas»).
      await postService('/api/test', { subscription: subscription.toJSON() }, pushTestResponseSchema, { timeoutMs: 10000 });
    },
    onSuccess: () => {
      setSubscribed(true);
      toast.success('Notificações ativadas — enviamos uma notificação de teste.');
      refresh();
    },
    onError: (err) => {
      toast.error(err.message);
      refresh();
    },
  });

  const disableMutation = useMutation<void, Error, void>({
    mutationFn: async () => {
      const registration = await navigator.serviceWorker.getRegistration();
      const existing = await registration?.pushManager.getSubscription();
      if (existing) {
        await postService('/api/unsubscribe', { endpoint: existing.endpoint }, pushUnsubscribeResponseSchema, { timeoutMs: 8000 });
        await existing.unsubscribe();
        try {
          localStorage.removeItem(ENDPOINT_KEY);
        } catch {
          // ignore
        }
      }
    },
    onSuccess: () => {
      setSubscribed(false);
      toast.success('Notificações push desativadas neste dispositivo.');
      refresh();
    },
    onError: (err) => {
      toast.error(err.message);
      refresh();
    },
  });

  const sendTest = useCallback(async () => {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      const existing = await registration?.pushManager.getSubscription();
      if (!existing) {
        toast.error('Este dispositivo ainda não está subscrito — ativa as notificações primeiro.');
        return;
      }
      await postService('/api/test', { subscription: existing.toJSON() }, pushTestResponseSchema, { timeoutMs: 10000 });
      toast.success('Notificação de teste enviada.');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Falha ao enviar a notificação de teste.');
    }
  }, []);

  return {
    status: status.data ?? null,
    serviceOnline: status.isSuccess,
    serviceLoading: status.isPending,
    supported,
    standalone,
    iosNeedsInstall: isIos() && !standalone,
    permission,
    subscribed,
    checking,
    busy: enableMutation.isPending || disableMutation.isPending,
    enable: () => enableMutation.mutateAsync(),
    disable: () => disableMutation.mutateAsync(),
    sendTest,
  };
}
