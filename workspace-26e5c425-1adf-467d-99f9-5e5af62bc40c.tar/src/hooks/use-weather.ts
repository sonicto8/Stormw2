'use client';

/**
 * Hooks TanStack Query para todas as fontes de dados internas.
 * Offline: snapshots persistidos em IndexedDB servidos quando a rede falha.
 */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  airQualityApiEnvelopeSchema,
  forecastApiEnvelopeSchema,
  geocodingPlaceSchema,
  gridApiEnvelopeSchema,
  ipmaApiEnvelopeSchema,
  radarApiEnvelopeSchema,
  reportsApiEnvelopeSchema,
  reportPostResponseSchema,
} from '@/lib/schemas/internal.schema';
import { z } from 'zod';
import { ApiClientError, fetchInternal, postInternal } from '@/lib/services/api-client';
import { idbGet, idbSet } from '@/lib/services/idb';
import { getDeviceId } from '@/lib/services/device';
import type {
  ActivityReport,
  AirQualityBundle,
  ForecastBundle,
  GeocodingPlace,
  GridPoint,
  IpmaWarning,
  RadarBundle,
} from '@/lib/types';

export interface Envelope<T> {
  data: T;
  notice: string | null;
}

const OFFLINE_TTL = 24 * 60 * 60 * 1000;

/** Envelope com snapshot IndexedDB + sinalização de dados em cache. */
async function withOfflineFallback<T>(
  url: string,
  schema: z.ZodType<Envelope<T>>,
  idbKey: string,
  signal?: AbortSignal,
): Promise<Envelope<T> & { offline?: boolean }> {
  try {
    const res = await fetchInternal(url, schema, { signal, timeoutMs: 12000 });
    void idbSet(idbKey, res);
    return res;
  } catch (err) {
    if (signal?.aborted) throw err;
    const snapshot = await idbGet<Envelope<T> & { savedAt?: number }>(idbKey);
    if (snapshot && Date.now() - (snapshot.savedAt ?? 0) < OFFLINE_TTL) {
      return { ...snapshot, notice: snapshot.notice ?? 'Sem ligação — dados em cache no dispositivo.', offline: true };
    }
    throw err;
  }
}

const forecastEnvelope = z.object({
  data: forecastApiEnvelopeSchema.shape.data,
  notice: z.string().nullable(),
});

export interface WeatherResult {
  bundle: ForecastBundle;
  notice: string | null;
  offline: boolean;
}

function forecastKey(lat: number, lon: number): string {
  return `forecast:${lat.toFixed(3)},${lon.toFixed(3)}`;
}

export function useWeather(lat: number, lon: number) {
  return useQuery<WeatherResult, Error>({
    queryKey: ['forecast', lat.toFixed(3), lon.toFixed(3)],
    queryFn: async ({ signal }) => {
      const res = await withOfflineFallback(
        `/api/weather/forecast?lat=${lat}&lon=${lon}`,
        forecastEnvelope,
        forecastKey(lat, lon),
        signal,
      );
      return { bundle: res.data, notice: res.notice, offline: Boolean(res.offline) };
    },
    staleTime: 10 * 60 * 1000,
    refetchInterval: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useAirQuality(lat: number, lon: number) {
  return useQuery<{ bundle: AirQualityBundle; notice: string | null; offline: boolean }, Error>({
    queryKey: ['air', lat.toFixed(3), lon.toFixed(3)],
    queryFn: async ({ signal }) => {
      const res = await withOfflineFallback(
        `/api/weather/air-quality?lat=${lat}&lon=${lon}`,
        z.object({ data: airQualityApiEnvelopeSchema.shape.data, notice: z.string().nullable() }),
        `air:${lat.toFixed(3)},${lon.toFixed(3)}`,
        signal,
      );
      return { bundle: res.data, notice: res.notice, offline: Boolean(res.offline) };
    },
    staleTime: 10 * 60 * 1000,
    refetchInterval: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useIpmaWarnings() {
  return useQuery<{ warnings: IpmaWarning[]; notice: string | null; offline: boolean }, Error>({
    queryKey: ['ipma'],
    queryFn: async ({ signal }) => {
      const res = await withOfflineFallback(
        '/api/ipma/warnings',
        ipmaApiEnvelopeSchema,
        'ipma:warnings',
        signal,
      );
      return { warnings: res.data, notice: res.notice, offline: Boolean(res.offline) };
    },
    staleTime: 10 * 60 * 1000,
    refetchInterval: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useRadar() {
  return useQuery<{ radar: RadarBundle; notice: string | null; offline: boolean }, Error>({
    queryKey: ['radar'],
    queryFn: async ({ signal }) => {
      const res = await withOfflineFallback('/api/radar', radarApiEnvelopeSchema, 'radar:maps', signal);
      return { radar: res.data, notice: res.notice, offline: Boolean(res.offline) };
    },
    staleTime: 5 * 60 * 1000,
    refetchInterval: 5 * 60 * 1000,
    retry: 1,
  });
}

/** Grelha de pontos de referência para os mapas de temperatura, vento e nuvens. */
export function useGrid() {
  return useQuery<{ points: GridPoint[]; notice: string | null }, Error>({
    queryKey: ['grid'],
    queryFn: async ({ signal }) => {
      const res = await withOfflineFallback('/api/weather/grid', gridApiEnvelopeSchema, 'grid:points', signal);
      return { points: res.data, notice: res.notice };
    },
    staleTime: 10 * 60 * 1000,
    refetchInterval: 10 * 60 * 1000,
    retry: 1,
  });
}

const geocodingResponseSchema = z.object({ data: z.array(geocodingPlaceSchema) });

export function useGeocodingSearch(query: string) {
  return useQuery<GeocodingPlace[], Error>({
    queryKey: ['geocoding', query],
    queryFn: async ({ signal }) => {
      const res = await fetchInternal(`/api/geocoding?q=${encodeURIComponent(query)}`, geocodingResponseSchema, {
        signal,
        timeoutMs: 8000,
      });
      return res.data;
    },
    enabled: query.trim().length >= 2,
    staleTime: 5 * 60 * 1000,
    retry: 0,
  });
}

const reportsResponseSchema = z.object({
  data: reportsApiEnvelopeSchema.shape.data,
  notice: z.string().nullable().optional(),
  serverTime: z.string().optional(),
});

export function useReports() {
  return useQuery<{ reports: ActivityReport[]; notice: string | null }, Error>({
    queryKey: ['reports'],
    queryFn: async ({ signal }) => {
      const res = await fetchInternal('/api/reports', reportsResponseSchema, { signal, timeoutMs: 8000 });
      return { reports: res.data, notice: res.notice ?? null };
    },
    staleTime: 30 * 1000,
    refetchInterval: 60 * 1000,
    retry: 1,
  });
}

export interface CreateReportInput {
  type: string;
  note: string | null;
  lat: number;
  lon: number;
  placeName: string | null;
}

const reportMutationResponseSchema = z.object({ data: reportPostResponseSchema.shape.data });

export function useCreateReport() {
  const qc = useQueryClient();
  return useMutation<ActivityReport, Error, CreateReportInput>({
    mutationFn: async (input) => {
      const res = await postInternal(
        '/api/reports',
        { ...input, deviceId: getDeviceId() },
        reportMutationResponseSchema,
        { timeoutMs: 8000 },
      );
      return res.data;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['reports'] });
    },
  });
}

export function useConfirmReport() {
  const qc = useQueryClient();
  return useMutation<ActivityReport, Error, string>({
    mutationFn: async (reportId) => {
      const res = await postInternal(
        `/api/reports/confirm?id=${encodeURIComponent(reportId)}`,
        { deviceId: getDeviceId() },
        reportMutationResponseSchema,
        { timeoutMs: 8000 },
      );
      return res.data;
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['reports'] });
    },
  });
}
