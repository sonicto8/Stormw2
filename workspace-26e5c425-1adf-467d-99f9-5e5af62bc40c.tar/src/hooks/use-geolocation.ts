'use client';

/** Geolocalização do dispositivo com estados claros (negado, indisponível, erro). */
import { useCallback, useState } from 'react';

export type GeolocationStatus = 'idle' | 'prompting' | 'granted' | 'denied' | 'error' | 'unsupported';

export function useGeolocation() {
  const [status, setStatus] = useState<GeolocationStatus>('idle');

  const request = useCallback(
    (
      onResolved: (coords: { latitude: number; longitude: number }) => void,
      onError?: (message: string) => void,
    ) => {
      if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
        setStatus('unsupported');
        onError?.('Geolocalização não suportada neste dispositivo.');
        return;
      }
      setStatus('prompting');
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setStatus('granted');
          onResolved({ latitude: pos.coords.latitude, longitude: pos.coords.longitude });
        },
        (err) => {
          if (err.code === err.PERMISSION_DENIED) {
            setStatus('denied');
            onError?.('Permissão de localização negada. Podes escolher uma localidade manualmente.');
          } else {
            setStatus('error');
            onError?.('Não foi possível obter a localização.');
          }
        },
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 10 * 60 * 1000 },
      );
    },
    [],
  );

  return { status, request };
}
