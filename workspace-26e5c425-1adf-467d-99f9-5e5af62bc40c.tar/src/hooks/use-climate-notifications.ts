'use client';

/**
 * Vigia alterações climáticas entre atualizações e notifica o utilizador
 * dentro da aplicação (toast) e, quando autorizado, no navegador (Notification
 * API local — sem servidor push). Comparações sempre entre valores reais de
 * estados sucessivos; trocas de localização não geram avisos.
 */
import { useEffect, useRef } from 'react';
import { toast } from 'sonner';
import type { ForecastBundle, WeatherAlert } from '@/lib/types';
import { useProfileContext } from '@/hooks/profile-context';

interface ClimateSnapshot {
  /** Assinatura do último estado processado. */
  sig: string;
  locationName: string;
  temperature: number | null;
  gusts: number | null;
  /** Probabilidade máxima de precipitação nas próximas 3 h. */
  rainProbNext: number | null;
  alertIds: string[];
}

const SNAPSHOT_KEY = 'stormwatch-climate-snap';

function readSnapshot(): ClimateSnapshot | null {
  try {
    const raw = localStorage.getItem(SNAPSHOT_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (typeof parsed === 'object' && parsed !== null && 'sig' in parsed) {
      return parsed as ClimateSnapshot;
    }
    return null;
  } catch {
    return null;
  }
}

function writeSnapshot(snap: ClimateSnapshot): void {
  try {
    localStorage.setItem(SNAPSHOT_KEY, JSON.stringify(snap));
  } catch {
    // ignore
  }
}

/** Probabilidade máxima de chuva nas próximas 3 horas a partir de agora. */
function rainProbNext3h(bundle: ForecastBundle, nowMs: number): number | null {
  const window = bundle.hourly.filter((h) => {
    const t = Date.parse(`${h.time}:00Z`);
    return t >= nowMs - 30 * 60000 && t <= nowMs + 3 * 60 * 60000;
  });
  if (window.length === 0) return null;
  const values = window.map((h) => h.precipitationProbability).filter((v): v is number => v !== null);
  return values.length > 0 ? Math.max(...values) : null;
}

function showBrowserNotification(title: string, body: string): void {
  try {
    if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
    const n = new Notification(title, { body, tag: `stormwatch-${title}` });
    setTimeout(() => n.close(), 10000);
  } catch {
    // Notificações indisponíveis — o toast in-app continua.
  }
}

/**
 * Deteta e anuncia alterações significativas: avisos novos, salto de
 * temperatura ≥ 3°C, chuva a cruzar 50% nas próximas 3 h e rajadas a cruzar
 * o limiar de aviso. Executa no máximo uma vez por assinatura de estado.
 */
export function useClimateNotifications(
  bundle: ForecastBundle | null,
  alerts: WeatherAlert[],
  nowMs: number,
): void {
  const { profile } = useProfileContext();

  // Assinatura do estado: dados + avisos ativos + localização.
  const alertSig = alerts.map((a) => a.id).join(',');
  const sig = bundle
    ? `${bundle.fetchedAt}|${locationSig(bundle)}|${alertSig}`
    : 'no-bundle';
  const sigRef = useRef<string>('');

  useEffect(() => {
    if (!bundle || sigRef.current === sig) return;
    sigRef.current = sig;

    const previous = readSnapshot();
    const current: ClimateSnapshot = {
      sig,
      locationName: locationSig(bundle),
      temperature: bundle.current.temperature,
      gusts: bundle.current.windGusts,
      rainProbNext: rainProbNext3h(bundle, nowMs),
      alertIds: alerts.map((a) => a.id),
    };

    if (previous && previous.locationName !== current.locationName) {
      // Troca de localização: só reancorar a referência, sem avisos.
      writeSnapshot(current);
      return;
    }

    const notices: Array<{ title: string; body: string; tone: 'info' | 'warning' | 'critical' }> = [];

    // 1. Avisos novos (não presentes na última atualização processada).
    if (previous) {
      const newAlerts = alerts.filter((a) => !previous.alertIds.includes(a.id));
      for (const a of newAlerts) {
        notices.push({
          title: a.origin === 'ipma' ? `Aviso oficial · ${a.title}` : a.title,
          body: a.description,
          tone: a.severity === 'critical' ? 'critical' : a.severity === 'warning' ? 'warning' : 'info',
        });
      }
    }

    if (previous) {
      // 2. Alteração de temperatura ≥ 3°C entre estados processados.
      if (previous.temperature !== null && bundle.current.temperature !== null) {
        const delta = bundle.current.temperature - previous.temperature;
        if (Math.abs(delta) >= 3) {
          notices.push({
            title: delta > 0 ? 'Temperatura a subir rapidamente' : 'Temperatura a descer rapidamente',
            body: `Passou de ${previous.temperature.toFixed(1)}°C para ${bundle.current.temperature.toFixed(1)}°C.`,
            tone: 'info',
          });
        }
      }

      // 3. Chuva a chegar: probabilidade cruzou 50% nas próximas 3 h.
      if (current.rainProbNext !== null && (previous.rainProbNext ?? 0) < 50 && current.rainProbNext >= 50) {
        notices.push({
          title: 'Chuva a caminho',
          body: `Probabilidade de precipitação nas próximas 3 horas: ${Math.round(current.rainProbNext)}%. Considera levar guarda-chuva.`,
          tone: 'warning',
        });
      }

      // 4. Rajadas a cruzar o limiar de aviso (60 km/h).
      if ((previous.gusts ?? 0) < 60 && bundle.current.windGusts >= 60) {
        notices.push({
          title: 'Vento forte a intensificar-se',
          body: `Rajadas agora a ${Math.round(bundle.current.windGusts)} km/h.`,
          tone: 'warning',
        });
      }
    }

    for (const n of notices.slice(0, 4)) {
      if (n.tone === 'critical') {
        toast.error(n.title, { description: n.body, duration: 8000 });
      } else if (n.tone === 'warning') {
        toast.warning(n.title, { description: n.body, duration: 8000 });
      } else {
        toast.message(n.title, { description: n.body, duration: 6000 });
      }
      if (profile.browserNotifications) {
        showBrowserNotification(`STORMWATCH · ${n.title}`, n.body);
      }
    }

    writeSnapshot(current);
  }, [sig, profile.browserNotifications]);
}

/** Chave de localização a partir da resposta da fonte (lat/lon arredondados). */
function locationSig(bundle: ForecastBundle): string {
  return `${bundle.latitude.toFixed(2)},${bundle.longitude.toFixed(2)}`;
}
