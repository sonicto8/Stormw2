'use client';

import { createContext, useContext, type ReactNode } from 'react';
import { useProfile } from '@/hooks/use-profile';
import type { Profile } from '@/lib/schemas/report.schema';

interface ProfileContextValue {
  profile: Profile;
  setProfile: (next: Partial<Profile>) => void;
  resetProfile: () => void;
}

const ProfileContext = createContext<ProfileContextValue | null>(null);

export function ProfileProvider({ children }: { children: ReactNode }) {
  const value = useProfile();
  return <ProfileContext.Provider value={value}>{children}</ProfileContext.Provider>;
}

export function useProfileContext(): ProfileContextValue {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error('useProfileContext deve ser usado dentro de ProfileProvider');
  return ctx;
}
