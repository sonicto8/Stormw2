'use client';

/**
 * Ligação SSE ao alerts-service (porta 3003, via gateway XTransformPort).
 * Mantém um feed dos avisos IPMA novos difundidos em tempo real, mostra um
 * toast no momento em que chegam e invalida a query do IPMA para o resto da
 * app refrescar. Sem serviço (ou com o túnel caído), degrada para 'offline'
 * — a app continua a funcionar com polling normal das rotas internas.
 */
import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import { useQueryClient } from '@tanstack/react-query';
import { serviceWarningSchema, type ServiceWarning } from '@/lib/schemas/alerts-service.schema';
import { serviceUrl } from '@/lib/services/alerts-service-client';

const LEVEL_PT: Record<ServiceWarning['level'], string> = {
  yellow: 'Aviso amarelo',
  orange: 'Aviso laranja',
  red: 'Aviso vermelho',
};

export type StreamStatus = 'connecting' | 'live' | 'offline';

export interface StreamFeedItem extends ServiceWarning {
  /** Momento (ms) em que o aviso chegou ao cliente. */
  receivedAt: number;
}

const MAX_FEED = 20;

export function useAlertsStream(): { status: StreamStatus; feed: StreamFeedItem[] } {
  const [status, setStatus] = useState<StreamStatus>('connecting');
  const [feed, setFeed] = useState<StreamFeedItem[]>([]);
  const qc = useQueryClient();
  const sourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    // EventSource segue o mesmo caminho do gateway: porta só na query.
    const source = new EventSource(serviceUrl('/api/stream'));
    sourceRef.current = source;

    source.onopen = () => setStatus('live');
    source.onerror = () => setStatus('offline');
    source.addEventListener('poll', () => setStatus('live'));

    source.addEventListener('alert:new', (event) => {
      setStatus('live');
      try {
        const parsed = serviceWarningSchema.safeParse(JSON.parse((event as MessageEvent<string>).data));
        if (!parsed.success) return;
        const warning = parsed.data;
        setFeed((old) =>
          old.some((w) => w.id === warning.id) ? old : [{ ...warning, receivedAt: Date.now() }, ...old].slice(0, MAX_FEED),
        );

        const title = `${LEVEL_PT[warning.level]} · IPMA`;
        const description = `${warning.phenomenLabel} — área ${warning.area}`;
        if (warning.level === 'red') toast.error(title, { description, duration: 9000 });
        else if (warning.level === 'orange') toast.warning(title, { description, duration: 9000 });
        else toast.message(title, { description, duration: 7000 });

        // O resto da app (banner, separador Alertas) refresca de imediato.
        void qc.invalidateQueries({ queryKey: ['ipma'] });
      } catch {
        // Frame malformado — ignorado, a ligação continua.
      }
    });

    return () => {
      source.close();
      sourceRef.current = null;
    };
  }, [qc]);

  return { status, feed };
}
