'use client';

import { useCallback, useState } from 'react';
import { defaultProfile, profileSchema, type Profile } from '@/lib/schemas/report.schema';

const STORAGE_KEY = 'stormwatch-profile';

function loadProfile(): Profile {
  if (typeof window === 'undefined') return defaultProfile;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProfile;
    const parsed = profileSchema.safeParse(JSON.parse(raw));
    return parsed.success ? parsed.data : defaultProfile;
  } catch {
    return defaultProfile;
  }
}

export function useProfile() {
  const [profile, setProfileState] = useState<Profile>(loadProfile);

  const setProfile = useCallback((next: Partial<Profile>) => {
    setProfileState((prev) => {
      const merged = { ...prev, ...next };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
      } catch {
        // localStorage pode estar indisponível (modo privado).
      }
      return merged;
    });
  }, []);

  const resetProfile = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    setProfileState(defaultProfile);
  }, []);

  return { profile, setProfile, resetProfile };
}
