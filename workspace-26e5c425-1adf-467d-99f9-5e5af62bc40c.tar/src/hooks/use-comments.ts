'use client';

/**
 * Hooks da comunidade em tempo real: histórico via API interna + difusão
 * instantânea via socket.io (serviço dedicado na porta 3010). A porta 3003
 * pertence ao alerts-service (ver guia PWA).
 */
import { useEffect, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { commentResponseSchema, type CommentResponse } from '@/lib/schemas/comment.schema';
import { ApiClientError, fetchInternal, postInternal } from '@/lib/services/api-client';
import { getDeviceId } from '@/lib/services/device';

const commentsEnvelopeSchema = z.object({
  data: z.array(commentResponseSchema),
  serverTime: z.string().optional(),
  notice: z.string().nullable().optional(),
});

/** Lista de comentários (histórico das últimas 24 h), refrescada por polling. */
export function useComments() {
  return useQuery<CommentResponse[], Error>({
    queryKey: ['comments'],
    queryFn: async ({ signal }) => {
      const res = await fetchInternal(`/api/comments?deviceId=${encodeURIComponent(getDeviceId())}`, commentsEnvelopeSchema, {
        signal,
        timeoutMs: 8000,
      });
      return res.data;
    },
    staleTime: 15 * 1000,
    refetchInterval: 45 * 1000,
    retry: 1,
  });
}

/** Ligação socket.io ao serviço de comentários; injeta comentários novos ao vivo. */
export function useCommentSocket(enabled: boolean): 'connecting' | 'live' | 'polling' {
  const [status, setStatus] = useState<'connecting' | 'live' | 'polling'>('connecting');
  const qc = useQueryClient();
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    if (!enabled) return;

    // Nunca usar portas no URL: o gateway encaminha com XTransformPort.
    const socket = io('/?XTransformPort=3010', {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 12,
      reconnectionDelay: 1200,
      timeout: 8000,
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      setStatus('live');
      // Pequena tolerância: o histórico em memória chega logo após a ligação.
    });

    socket.on('disconnect', () => {
      setStatus('polling');
    });

    socket.on('connect_error', () => {
      setStatus('polling');
    });

    socket.on('comments:recent', (recent: unknown) => {
      const parsed = z.array(commentResponseSchema).safeParse(recent);
      if (!parsed.success) return;
      qc.setQueryData<CommentResponse[]>(['comments'], (old) => {
        const known = new Set((old ?? []).map((c) => c.id));
        const additions = parsed.data.filter((c) => !known.has(c.id) && !c.mine);
        if (additions.length === 0) return old ?? parsed.data;
        return [...additions, ...(old ?? [])].sort(
          (a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt),
        );
      });
    });

    socket.on('comment:new', (comment: unknown) => {
      const parsed = commentResponseSchema.safeParse(comment);
      if (!parsed.success) return;
      qc.setQueryData<CommentResponse[]>(['comments'], (old) => {
        const known = new Set((old ?? []).map((c) => c.id));
        if (known.has(parsed.data.id)) return old;
        // Não injetar o próprio comentário duas vezes (a mutação otimista já o mostrou).
        const mine = parsed.data.mine === true;
        const list = [{ ...parsed.data, mine }, ...(old ?? [])];
        return list;
      });
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [enabled, qc]);

  return status;
}

export interface CreateCommentInput {
  nickname: string | null;
  message: string;
  lat: number | null;
  lon: number | null;
  placeName: string | null;
  weatherLabel: string | null;
  temperature: number | null;
}

const commentMutationResponseSchema = z.object({ data: commentResponseSchema });

/** Publica um comentário (validado + limitado no servidor) e atualiza a lista. */
export function useCreateComment() {
  const qc = useQueryClient();
  return useMutation<CommentResponse, Error, CreateCommentInput>({
    mutationFn: async (input) => {
      const res = await postInternal(
        '/api/comments',
        { ...input, deviceId: getDeviceId() },
        commentMutationResponseSchema,
        { timeoutMs: 8000 },
      );
      return res.data;
    },
    onSuccess: (created) => {
      qc.setQueryData<CommentResponse[]>(['comments'], (old) => {
        const known = new Set((old ?? []).map((c) => c.id));
        if (known.has(created.id)) return old;
        return [{ ...created, mine: true }, ...(old ?? [])];
      });
      void qc.invalidateQueries({ queryKey: ['comments'], refetchType: 'none' });
    },
    onError: (err) => {
      if (err instanceof ApiClientError && err.status === 429) {
        // Mensagem do servidor é apresentada pelo chamador via toast.
      }
    },
  });
}
