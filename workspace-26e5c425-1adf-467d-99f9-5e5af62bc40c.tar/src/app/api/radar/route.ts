import { adaptRainViewer } from '@/lib/adapters/rainviewer';
import { loadPersistedCache, persistCache, radarCache } from '@/lib/services/api-cache';
import { fetchExternal, upstreamStaleNotice } from '@/lib/services/upstream';
import type { RadarBundle } from '@/lib/types';

export const dynamic = 'force-dynamic';

const API_URL = 'https://api.rainviewer.com/public/weather-maps.json';

export async function GET(): Promise<Response> {
  const fresh = radarCache.fresh('maps');
  if (fresh) return Response.json({ data: fresh.data, notice: null });

  try {
    const raw = await fetchExternal(API_URL, 10000);
    const now = Date.now();
    const bundle = adaptRainViewer(raw, now);
    if (bundle.frames.length === 0) {
      return Response.json({
        data: bundle,
        notice: 'Sem frames de radar disponíveis neste momento.',
      });
    }
    radarCache.set('maps', bundle, now);
    await persistCache('radar:maps', bundle, now);
    return Response.json({ data: bundle, notice: null });
  } catch (err) {
    const stale = radarCache.staleFor('maps') ?? (await loadPersistedCache<RadarBundle>('radar:maps'));
    if (stale) {
      return Response.json({
        data: stale,
        notice: upstreamStaleNotice(err, 'Cobertura de radar'),
      });
    }
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao obter o radar: ${message}` }, { status: 502 });
  }
}
