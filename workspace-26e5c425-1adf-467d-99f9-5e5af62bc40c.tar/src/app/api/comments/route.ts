import { createCommentSchema } from '@/lib/schemas/comment.schema';
import { db } from '@/lib/db';
import type { CommentResponse } from '@/lib/schemas/comment.schema';

export const dynamic = 'force-dynamic';

/** Limitação de taxa: 1 comentário por dispositivo a cada 30 segundos. */
const RATE_WINDOW_MS = 30 * 1000;
/** E ainda, no máximo 20 comentários por dispositivo por hora. */
const HOURLY_LIMIT = 20;
/** Retenção: comentários mais antigos que 24 horas são removidos. */
const RETENTION_MS = 24 * 60 * 60 * 1000;
/** Porta interna do serviço socket.io que difunde os comentários em tempo real. */
const SOCKET_SERVICE_URL = process.env.COMMENT_SERVICE_URL ?? 'http://127.0.0.1:3004';

const rateMemory = new Map<string, number[]>();

function serialize(row: {
  id: string;
  deviceId: string;
  nickname: string;
  message: string;
  lat: number | null;
  lon: number | null;
  placeName: string | null;
  weatherLabel: string | null;
  temperature: number | null;
  createdAt: Date;
}): CommentResponse {
  return {
    id: row.id,
    nickname: row.nickname,
    message: row.message,
    lat: row.lat,
    lon: row.lon,
    placeName: row.placeName,
    weatherLabel: row.weatherLabel,
    temperature: row.temperature,
    createdAt: row.createdAt.toISOString(),
  };
}

/** Notifica o serviço socket.io para difundir o novo comentário (best-effort). */
async function broadcast(comment: CommentResponse, deviceId: string): Promise<void> {
  try {
    await fetch(`${SOCKET_SERVICE_URL}/notify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment: { ...comment, mine: false }, deviceId }),
      signal: AbortSignal.timeout(2000),
    });
  } catch {
    // Serviço de tempo real indisponível: os clientes recolhem por polling.
  }
}

export async function GET(req: Request): Promise<Response> {
  try {
    const params = new URL(req.url).searchParams;
    const deviceId = params.get('deviceId') ?? '';
    const limitParam = Number(params.get('limit') ?? '100');
    const limit = Number.isFinite(limitParam) ? Math.min(Math.max(Math.trunc(limitParam), 1), 200) : 100;

    // Limpeza de comentários com mais de 24 h (mantém a base leve).
    await db.comment.deleteMany({ where: { createdAt: { lt: new Date(Date.now() - RETENTION_MS) } } });

    const rows = await db.comment.findMany({
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return Response.json({
      data: rows.map((r) => serialize(r)),
      serverTime: new Date().toISOString(),
      notice: null,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao listar comentários: ${message}` }, { status: 500 });
  }
}

export async function POST(req: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: 'Corpo inválido' }, { status: 400 });
  }

  const parsed = createCommentSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { error: parsed.error.issues[0]?.message ?? 'Comentário inválido' },
      { status: 400 },
    );
  }

  const { deviceId, nickname, message, lat, lon, placeName, weatherLabel, temperature } = parsed.data;
  const now = new Date();
  const displayName = (nickname && nickname.length > 0 ? nickname : 'Anónimo').slice(0, 24);

  try {
    // Limitação de taxa primária: base de dados (30 s entre comentários).
    const recent = await db.comment.findFirst({
      where: { deviceId, createdAt: { gt: new Date(now.getTime() - RATE_WINDOW_MS) } },
      select: { createdAt: true },
    });
    if (recent) {
      const nextAllowed = recent.createdAt.getTime() + RATE_WINDOW_MS;
      return Response.json(
        { error: 'Aguarda uns segundos antes do próximo comentário.', nextAllowedAt: new Date(nextAllowed).toISOString() },
        { status: 429 },
      );
    }

    // Limite horário: 20 comentários por dispositivo.
    const hourCount = await db.comment.count({
      where: { deviceId, createdAt: { gt: new Date(now.getTime() - 60 * 60 * 1000) } },
    });
    if (hourCount >= HOURLY_LIMIT) {
      return Response.json(
        { error: 'Limite horário de comentários atingido. Tenta mais tarde.' },
        { status: 429 },
      );
    }

    // Camada secundária em memória (proteção contra rajada).
    const memTimes = (rateMemory.get(deviceId) ?? []).filter((t) => now.getTime() - t < RATE_WINDOW_MS);
    if (memTimes.length > 0) {
      return Response.json(
        { error: 'Aguarda uns segundos antes do próximo comentário.' },
        { status: 429 },
      );
    }

    const created = await db.comment.create({
      data: {
        deviceId,
        nickname: displayName,
        message: message.slice(0, 280),
        lat: lat ?? null,
        lon: lon ?? null,
        placeName: placeName ?? null,
        weatherLabel: weatherLabel ?? null,
        temperature: temperature ?? null,
      },
    });

    memTimes.push(now.getTime());
    rateMemory.set(deviceId, memTimes);

    const serialized = serialize(created);
    void broadcast({ ...serialized }, deviceId);

    return Response.json({ data: { ...serialized, mine: true }, notice: null }, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao criar comentário: ${message}` }, { status: 500 });
  }
}
