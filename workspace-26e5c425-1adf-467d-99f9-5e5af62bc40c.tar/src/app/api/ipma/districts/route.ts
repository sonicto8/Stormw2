import { districtsCache } from '@/lib/services/api-cache';
import { fetchExternal } from '@/lib/services/upstream';

export const dynamic = 'force-dynamic';

const API_URL = 'https://api.ipma.pt/open-data/distrits-islands.json';

interface IpmaDistrict {
  globalIdLocal: string;
  local: string;
}

export async function GET(): Promise<Response> {
  const fresh = districtsCache.fresh('districts');
  if (fresh) {
    return Response.json({ data: fresh.data, notice: null });
  }

  try {
    const raw = await fetchExternal(API_URL, 10000);
    const parsed = raw as { data?: IpmaDistrict[] };
    const districts = (parsed.data ?? []).map((d) => ({
      id: d.globalIdLocal,
      name: d.local,
    }));
    districtsCache.set('districts', districts, Date.now());
    return Response.json({ data: districts, notice: null });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json(
      {
        data: [],
        notice: `Lista de distritos IPMA indisponível: ${message}. A integração funcionará em produção com acesso à api.ipma.pt.`,
      },
      { status: 200 },
    );
  }
}
