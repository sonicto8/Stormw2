import { adaptIpmaWarnings } from '@/lib/adapters/ipma';
import { ipmaCache, loadPersistedCache, persistCache } from '@/lib/services/api-cache';
import { fetchExternal, upstreamStaleNotice } from '@/lib/services/upstream';
import type { IpmaWarning } from '@/lib/types';

export const dynamic = 'force-dynamic';

const API_URL = 'https://api.ipma.pt/open-data/forecast/warnings/warnings_www.json';

export async function GET(): Promise<Response> {
  const fresh = ipmaCache.fresh('warnings');
  if (fresh) return Response.json({ data: fresh.data, notice: null, fetchedAt: fresh.fetchedAt });

  // A API pública do IPMA é frequentemente lenta: tentativa com timeout
  // prolongado e uma segunda tentativa rápida antes de degradar.
  let lastError: unknown = null;
  for (const timeoutMs of [20000, 10000]) {
    try {
      const raw = await fetchExternal(API_URL, timeoutMs);
      const now = Date.now();
      const warnings = adaptIpmaWarnings(raw);
      ipmaCache.set('warnings', warnings, now);
      await persistCache('ipma:warnings', warnings, now);
      return Response.json({ data: warnings, notice: null, fetchedAt: now });
    } catch (err) {
      lastError = err;
    }
  }

  const stale = ipmaCache.staleFor('warnings') ?? (await loadPersistedCache<IpmaWarning[]>('ipma:warnings'));
  if (stale) {
    return Response.json({
      data: stale,
      notice: upstreamStaleNotice(lastError, 'Avisos oficiais do IPMA'),
      fetchedAt: Date.now(),
    });
  }

  // Degradar sem avisos — o UI apresenta claramente a fonte oficial como
  // indisponível nesta infraestrutura (ex.: rede restrita).
  const message = lastError instanceof Error ? lastError.message : 'Erro desconhecido';
  return Response.json({
    data: [],
    notice: `Avisos IPMA indisponíveis: ${message}. A integração está preparada e funcionará em produção com acesso à api.ipma.pt.`,
    fetchedAt: Date.now(),
  });
}
