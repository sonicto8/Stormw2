import { adaptGrid } from '@/lib/adapters/open-meteo';
import { gridCache, loadPersistedCache } from '@/lib/services/api-cache';
import { fetchExternal, upstreamStaleNotice } from '@/lib/services/upstream';
import { QUICK_LOCATIONS } from '@/lib/locations';
import type { GridPoint } from '@/lib/types';

export const dynamic = 'force-dynamic';

const API_URL = 'https://api.open-meteo.com/v1/forecast';

/**
 * Grelha de pontos de referência de Portugal continental e ilhas (capitais de
 * distrito), usada para construir os mapas de temperatura, vento e nuvens a
 * partir de um único pedido em lote à fonte permitida (Open-Meteo).
 */
const GRID_POINTS = QUICK_LOCATIONS;

function buildUrl(): string {
  const url = new URL(API_URL);
  url.searchParams.set('latitude', GRID_POINTS.map((p) => p.latitude).join(','));
  url.searchParams.set('longitude', GRID_POINTS.map((p) => p.longitude).join(','));
  url.searchParams.set(
    'current',
    'temperature_2m,is_day,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m',
  );
  url.searchParams.set('timezone', 'auto');
  return url.toString();
}

export async function GET(): Promise<Response> {
  const key = 'grid';
  const fresh = gridCache.fresh(key);
  if (fresh) {
    return Response.json({ data: fresh.data, notice: null });
  }

  try {
    const raw = await fetchExternal(buildUrl());
    const now = Date.now();
    const points: GridPoint[] = adaptGrid(raw, GRID_POINTS, now);
    gridCache.set(key, points, now);
    return Response.json({ data: points, notice: null });
  } catch (err) {
    const stale = gridCache.staleFor(key) ?? (await loadPersistedCache<GridPoint[]>('grid'));
    if (stale) {
      return Response.json({
        data: stale,
        notice: upstreamStaleNotice(err, 'Mapas meteorológicos'),
      });
    }
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao obter a grelha meteorológica: ${message}` }, { status: 502 });
  }
}
