import { adaptForecast } from '@/lib/adapters/open-meteo';
import { forecastCache, loadPersistedCache, persistCache } from '@/lib/services/api-cache';
import { fetchExternal, upstreamStaleNotice } from '@/lib/services/upstream';
import type { ForecastBundle } from '@/lib/types';

export const dynamic = 'force-dynamic';

const API_URL = 'https://api.open-meteo.com/v1/forecast';

function buildUrl(lat: number, lon: number): string {
  const url = new URL(API_URL);
  url.searchParams.set('latitude', lat.toString());
  url.searchParams.set('longitude', lon.toString());
  url.searchParams.set(
    'current',
    'temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,uv_index',
  );
  url.searchParams.set('minutely_15', 'precipitation,weather_code');
  url.searchParams.set('forecast_minutely_15', '48');
  url.searchParams.set(
    'hourly',
    'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation_probability,precipitation,weather_code,cloud_cover,visibility,wind_speed_10m,wind_gusts_10m,uv_index,is_day',
  );
  url.searchParams.set(
    'daily',
    'weather_code,temperature_2m_max,temperature_2m_min,temperature_2m_mean,apparent_temperature_max,apparent_temperature_min,precipitation_sum,precipitation_hours,precipitation_probability_max,wind_speed_10m_max,wind_speed_10m_mean,wind_gusts_10m_max,relative_humidity_2m_mean,cloud_cover_mean,uv_index_max,sunrise,sunset',
  );
  url.searchParams.set('forecast_days', '7');
  url.searchParams.set('past_days', '7');
  url.searchParams.set('timezone', 'auto');
  return url.toString();
}

export async function GET(req: Request): Promise<Response> {
  const params = new URL(req.url).searchParams;
  const lat = Number(params.get('lat'));
  const lon = Number(params.get('lon'));

  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return Response.json({ error: 'Coordenadas inválidas' }, { status: 400 });
  }

  const key = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const fresh = forecastCache.fresh(key);
  if (fresh) {
    return Response.json({ data: fresh.data, notice: null });
  }

  try {
    const raw = await fetchExternal(buildUrl(lat, lon));
    const now = Date.now();
    const bundle = adaptForecast(raw, now, 'network');
    forecastCache.set(key, bundle, now);
    await persistCache(`forecast:${key}`, bundle, now);
    return Response.json({ data: bundle, notice: null });
  } catch (err) {
    const stale =
      forecastCache.staleFor(key) ?? (await loadPersistedCache<ForecastBundle>(`forecast:${key}`));
    if (stale) {
      return Response.json({
        data: { ...stale, source: 'cache-server' as const },
        notice: upstreamStaleNotice(err, 'Previsão'),
      });
    }
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao obter a previsão: ${message}` }, { status: 502 });
  }
}
