import { adaptAirQuality } from '@/lib/adapters/air-quality';
import { airQualityCache, loadPersistedCache, persistCache } from '@/lib/services/api-cache';
import { fetchExternal, upstreamStaleNotice } from '@/lib/services/upstream';
import type { AirQualityBundle } from '@/lib/types';

export const dynamic = 'force-dynamic';

function buildUrl(lat: number, lon: number): string {
  const url = new URL('https://air-quality-api.open-meteo.com/v1/air-quality');
  url.searchParams.set('latitude', lat.toString());
  url.searchParams.set('longitude', lon.toString());
  url.searchParams.set('current', 'european_aqi,pm10,pm2_5,ozone,nitrogen_dioxide,sulphur_dioxide');
  url.searchParams.set('timezone', 'auto');
  return url.toString();
}

export async function GET(req: Request): Promise<Response> {
  const params = new URL(req.url).searchParams;
  const lat = Number(params.get('lat'));
  const lon = Number(params.get('lon'));

  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    return Response.json({ error: 'Coordenadas inválidas' }, { status: 400 });
  }

  const key = `${lat.toFixed(3)},${lon.toFixed(3)}`;
  const fresh = airQualityCache.fresh(key);
  if (fresh) return Response.json({ data: fresh.data, notice: null });

  try {
    const raw = await fetchExternal(buildUrl(lat, lon));
    const now = Date.now();
    const bundle = adaptAirQuality(raw, now, 'network');
    airQualityCache.set(key, bundle, now);
    await persistCache(`air:${key}`, bundle, now);
    return Response.json({ data: bundle, notice: null });
  } catch (err) {
    const stale =
      airQualityCache.staleFor(key) ?? (await loadPersistedCache<AirQualityBundle>(`air:${key}`));
    if (stale) {
      return Response.json({
        data: { ...stale, source: 'cache-server' as const },
        notice: upstreamStaleNotice(err, 'Qualidade do ar'),
      });
    }
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao obter a qualidade do ar: ${message}` }, { status: 502 });
  }
}
