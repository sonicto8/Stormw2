import { confirmReportSchema } from '@/lib/schemas/report.schema';
import { db } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function POST(req: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: 'Corpo inválido' }, { status: 400 });
  }

  const parsed = confirmReportSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json({ error: 'Confirmação inválida' }, { status: 400 });
  }

  const { deviceId } = parsed.data;
  const url = new URL(req.url);
  const reportId = url.searchParams.get('id');

  if (!reportId) {
    return Response.json({ error: 'ID do reporte em falta' }, { status: 400 });
  }

  try {
    const report = await db.report.findUnique({ where: { id: reportId } });
    if (!report || report.expiresAt.getTime() < Date.now()) {
      return Response.json({ error: 'Reporte expirado ou inexistente' }, { status: 404 });
    }

    let confirmedBy: string[] = [];
    try {
      const parsedList: unknown = JSON.parse(report.confirmedBy);
      if (Array.isArray(parsedList)) confirmedBy = parsedList.filter((v): v is string => typeof v === 'string');
    } catch {
      confirmedBy = [];
    }

    if (report.deviceId === deviceId) {
      return Response.json({ error: 'Não podes confirmar o teu próprio reporte' }, { status: 403 });
    }

    if (confirmedBy.includes(deviceId)) {
      return Response.json({ error: 'Já confirmaste este reporte' }, { status: 409 });
    }

    confirmedBy.push(deviceId);
    const updated = await db.report.update({
      where: { id: reportId },
      data: { confirmations: report.confirmations + 1, confirmedBy: JSON.stringify(confirmedBy) },
    });

    return Response.json({
      data: {
        id: updated.id,
        type: updated.type,
        note: updated.note,
        lat: updated.lat,
        lon: updated.lon,
        placeName: updated.placeName,
        createdAt: updated.createdAt.toISOString(),
        confirmations: updated.confirmations,
        confirmedBy,
      },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao confirmar: ${message}` }, { status: 500 });
  }
}
