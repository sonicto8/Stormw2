import { createReportSchema } from '@/lib/schemas/report.schema';
import { db } from '@/lib/db';
import type { ActivityReport } from '@/lib/types';

export const dynamic = 'force-dynamic';

/** Janela de limitação de taxa: 1 reporte por dispositivo a cada 10 minutos. */
const RATE_WINDOW_MS = 10 * 60 * 1000;
/** Expiração automática dos reportes: 2 horas. */
const EXPIRY_MS = 2 * 60 * 60 * 1000;

// Limitação de taxa em memória (segunda camada; a principal é a base de dados).
const rateMemory = new Map<string, number>();

function serialize(row: {
  id: string;
  type: string;
  note: string | null;
  lat: number;
  lon: number;
  placeName: string | null;
  createdAt: Date;
  confirmations: number;
  confirmedBy: string;
}): ActivityReport {
  let confirmedBy: string[] = [];
  try {
    const parsed: unknown = JSON.parse(row.confirmedBy);
    if (Array.isArray(parsed)) confirmedBy = parsed.filter((v): v is string => typeof v === 'string');
  } catch {
    confirmedBy = [];
  }
  return {
    id: row.id,
    type: row.type as ActivityReport['type'],
    note: row.note,
    lat: row.lat,
    lon: row.lon,
    placeName: row.placeName,
    createdAt: row.createdAt.toISOString(),
    confirmations: row.confirmations,
    confirmedBy,
  };
}

export async function GET(): Promise<Response> {
  try {
    const now = new Date();

    // Limpeza de reportes expirados (mantém a base leve).
    await db.report.deleteMany({ where: { expiresAt: { lt: now } } });

    const rows = await db.report.findMany({
      where: { expiresAt: { gt: now } },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });

    return Response.json({
      data: rows.map(serialize),
      notice: null,
      serverTime: now.toISOString(),
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao listar reportes: ${message}` }, { status: 500 });
  }
}

export async function POST(req: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: 'Corpo inválido' }, { status: 400 });
  }

  const parsed = createReportSchema.safeParse(body);
  if (!parsed.success) {
    return Response.json(
      { error: 'Reporte inválido', details: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) },
      { status: 400 },
    );
  }

  const { deviceId, type, note, lat, lon, placeName } = parsed.data;
  const now = new Date();

  try {
    // Camada principal de rate limiting: base de dados.
    const recent = await db.report.count({
      where: { deviceId, createdAt: { gt: new Date(now.getTime() - RATE_WINDOW_MS) } },
    });
    if (recent > 0) {
      const last = await db.report.findFirst({
        where: { deviceId },
        orderBy: { createdAt: 'desc' },
        select: { createdAt: true },
      });
      const nextAllowed = last ? last.createdAt.getTime() + RATE_WINDOW_MS : now.getTime() + RATE_WINDOW_MS;
      return Response.json(
        { error: 'Limite de reportes atingido', nextAllowedAt: new Date(nextAllowed).toISOString() },
        { status: 429 },
      );
    }

    // Camada secundária em memória (proteção contra abusos em rajada).
    const memLast = rateMemory.get(deviceId);
    if (memLast !== undefined && now.getTime() - memLast < RATE_WINDOW_MS) {
      return Response.json(
        { error: 'Limite de reportes atingido', nextAllowedAt: new Date(memLast + RATE_WINDOW_MS).toISOString() },
        { status: 429 },
      );
    }

    const created = await db.report.create({
      data: {
        deviceId,
        type,
        note: note ?? null,
        lat,
        lon,
        placeName: placeName ?? null,
        expiresAt: new Date(now.getTime() + EXPIRY_MS),
      },
    });

    rateMemory.set(deviceId, now.getTime());
    return Response.json({ data: serialize(created), notice: null }, { status: 201 });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha ao criar reporte: ${message}` }, { status: 500 });
  }
}
