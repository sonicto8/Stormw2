import { adaptGeocoding } from '@/lib/adapters/open-meteo';
import { fetchExternal } from '@/lib/services/upstream';

export const dynamic = 'force-dynamic';

export async function GET(req: Request): Promise<Response> {
  const params = new URL(req.url).searchParams;
  const query = (params.get('q') ?? '').trim();

  if (query.length < 2) {
    return Response.json({ error: 'Pesquisa demasiado curta' }, { status: 400 });
  }

  const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
  url.searchParams.set('name', query);
  url.searchParams.set('count', '10');
  url.searchParams.set('language', 'pt');
  url.searchParams.set('format', 'json');

  try {
    const raw = await fetchExternal(url.toString());
    return Response.json({ data: adaptGeocoding(raw) });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Erro desconhecido';
    return Response.json({ error: `Falha na pesquisa de localidades: ${message}` }, { status: 502 });
  }
}
