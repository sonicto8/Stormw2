/**
 * STORM AI — reformulação opcional por LLM.
 * O motor determinístico calcula tudo; o LLM só reformula o texto.
 * A resposta é validada: se os números não forem preservados exatamente,
 * devolve-se o texto original do motor.
 */
import { extractNumbers } from '@/lib/engines/intents';

export const dynamic = 'force-dynamic';

interface RephraseBody {
  answer?: string;
  question?: string;
}

function normalizeNumbers(text: string): string[] {
  return extractNumbers(text).map((n) => n.replace(',', '.'));
}

function numbersPreserved(original: string, candidate: string): boolean {
  const a = normalizeNumbers(original).sort();
  const b = normalizeNumbers(candidate).sort();
  if (a.length !== b.length) return false;
  return a.every((n, i) => Math.abs(parseFloat(n) - parseFloat(b[i])) < 1e-6);
}

export async function POST(req: Request): Promise<Response> {
  let body: RephraseBody;
  try {
    body = (await req.json()) as RephraseBody;
  } catch {
    return Response.json({ error: 'Corpo inválido' }, { status: 400 });
  }

  const original = (body.answer ?? '').trim();
  const question = (body.question ?? '').trim();

  if (original.length === 0) {
    return Response.json({ error: 'Resposta em falta' }, { status: 400 });
  }

  try {
    const { default: ZAI } = await import('z-ai-web-dev-sdk');
    const zai = await ZAI.create();
    const completion = (await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content:
            'És um reescritor para uma app meteorológica em português europeu. Reformula a resposta dada mantendo TODOS os números EXATAMENTE iguais (temperaturas, percentagens, horas, distâncias), o mesmo significado e um tom claro e futurista. Responde apenas com o texto reformulado, sem introduzir dados novos nem alterar valores. Máximo 3 frases.',
        },
        {
          role: 'user',
          content: `Pergunta: ${question}\nResposta calculada: ${original}`,
        },
      ],
      thinking: { type: 'disabled' },
    })) as { choices?: Array<{ message?: { content?: string } }> };

    const candidate = completion.choices?.[0]?.message?.content?.trim() ?? '';
    if (candidate.length > 0 && numbersPreserved(original, candidate)) {
      return Response.json({ text: candidate, source: 'llm' });
    }
    return Response.json({ text: original, source: 'engine' });
  } catch {
    // LLM indisponível: resposta determinística é a fonte da verdade.
    return Response.json({ text: original, source: 'engine' });
  }
}
