# Publicar a STORMWATCH sem custos (0 €)

Guia de publicação gratuito. Três caminhos — escolhe um conforme o que queres:

| | Caminho | Custo | Endereço | Precisa de PC ligado? | Comentários da comunidade guardados? |
| --- | --- | --- | --- | --- | --- |
| 1 | **Pré-visualização (já ativa)** | 0 € | painel de pré-visualização deste chat | — | Sim, durante a sessão |
| 2 | **Vercel + Turso** (recomendado) | 0 € | `https://teu-projeto.vercel.app` (fixo) | Não | Sim, permanente |
| 3 | **Cloudflare Tunnel** no teu PC | 0 € | fixo com domínio próprio; temporário sem | Sim | Sim (base no teu PC) |

> O ficheiro [`vercel.json`](./vercel.json) já inclui as cabeçalhos corretos para a PWA (Service Worker, manifest, ícones). Para os utilizadores: o [GUIA.md](./GUIA.md) explica em linguagem simples como instalar no iPhone e no Android.

> **Regra de ouro:** para instalar no iPhone (PWA), autorizar a localização e receber notificações, o endereço tem de ser **HTTPS**. As três opções cumprem-no.

---

## Opção 1 — Pré-visualização (já está a funcionar)

A aplicação já corre agora na pré-visualização deste chat. Usa o botão **«Abrir em novo separador»** do painel de pré-visualização: abre em HTTPS e já podes instalar no telemóvel (Safari no iPhone / Chrome no Android). Limitação: o endereço e os dados vivem nesta sessão — para um endereço permanente, usa a Opção 2 ou 3.

---

## Opção 2 — Vercel + Turso (endereço público permanente)

Tempo: ~15 minutos · Tudo em planos gratuitos.

### 2.1 Colocar o projeto no GitHub

```bash
cd stormwatch
git init
git add -A
git commit -m "STORMWATCH"
# cria um repositório vazio em github.com e liga-o:
git remote add origin https://github.com/TEU_UTILIZADOR/stormwatch.git
git push -u origin main
```

### 2.2 Base de dados gratuita (Turso) — para os comentários da comunidade

A Vercel não guarda ficheiros entre pedidos, por isso o SQLite local não serve. A **Turso** é SQLite na cloud com plano gratuito generoso:

```bash
# 1. cria conta em turso.tech (grátis) e instala o CLI:
curl -sSfL https://get.tur.so/install.sh | bash

# 2. cria a base de dados e obtém as credenciais:
turso db create stormwatch
turso db show stormwatch --url        # → DATABASE_URL (libsql://…)
turso db tokens create stormwatch     # → DATABASE_AUTH_TOKEN
```

Depois adapta o Prisma para falar libsql (Turso):

1. `bun add @libsql/client`
2. Em `prisma/schema.prisma`, muda o datasource:

```prisma
datasource db {
  provider  = "libsql"
  url       = env("DATABASE_URL")
}
```

3. Aplica o esquema na Turso e gera o cliente:

```bash
DATABASE_URL="libsql://stormwatch-<teu-utilizador>.turso.io?authToken=<TOKEN>" bun run db:push
bun run db:generate
```

4. Envia as alterações para o GitHub (`git add -A && git commit -m "Turso" && git push`).

> As funcionalidades que guardam dados no **dispositivo** (perfil, sensibilidades, favoritas, contactos de emergência, tema claro/escuro) continuam a funcionar sempre — não dependem desta base de dados.

### 2.3 Importar na Vercel

1. Entra em **vercel.com** com «Sign up with GitHub» (grátis).
2. **Add New → Project** → seleciona o repositório `stormwatch`.
3. Em **Environment Variables** adiciona:

```
DATABASE_URL          = libsql://stormwatch-…turso.io?authToken=…
DATABASE_AUTH_TOKEN   = …            (se preferires separar o token)
OPEN_METEO_API_KEY    = …            (opcional, recomendado — ver nota abaixo)
```

> **`OPEN_METEO_API_KEY`** — a Vercel partilha IPs entre muitos projetos e, sem chave, essa quota coletiva do Open-Meteo pode esgotar-se (a app mostra então os últimos dados em cache com um aviso). Cria uma conta **grátis** em open-meteo.com, copia a tua API key e cola aqui: a quota passa a ser tua e o aviso desaparece. Sem a chave, tudo funciona na mesma — só há mais probabilidade de ver dados em cache em dias de muito uso.

4. **Deploy** — a Vercel deteta o Next.js sozinha. No fim tens `https://teu-projeto.vercel.app`.

### 2.4 Notificações push (opcional)

O `alerts-service` (porta 3003) não corre na Vercel. Duas alternativas gratuitas:

- **Railway (plano de teste):** hospeda `mini-services/alerts-service` e define o URL público do serviço no cliente (`src/lib/services/alerts-service-client.ts`).
- **cron-job.org (grátis):** cria um job de 5 minutos que chama uma route handler `/api/ipma/warnings` do teu deploy — a app continua a detetar avisos novos a cada atualização e mostra as notificações dentro da app e do navegador.

Sem este passo, **tudo o resto funciona**: avisos do IPMA com cores oficiais, alertas internos, radar, comunidade e resumos — as notificações em segundo plano é que ficam marcadas como «Não configurado» nas Definições.

---

## Opção 3 — Cloudflare Tunnel no teu próprio computador

Mantém o SQLite local (nada a mudar no código) e expõe a app com HTTPS gratuito.

### URL temporário (1 comando, sem conta)

```bash
bun run dev                                     # terminal 1 — app na porta 3000
cd mini-services/alerts-service && bun run dev  # terminal 2 — porta 3003
cloudflared tunnel --url http://localhost:3000  # terminal 3 — dá um URL https://…trycloudflare.com
```

Abre o URL no telemóvel e instala. O URL muda a cada arranque do túnel.

### URL fixo (requer um domínio próprio)

```bash
cloudflared tunnel login
cloudflared tunnel create stormwatch
cloudflared tunnel route dns stormwatch tempo.teudominio.pt
cloudflared tunnel run stormwatch     # https://tempo.teudominio.pt — permanente
```

> Um domínio `.pt` tem custo anual; se quiseres **0 € absolutos**, usa o URL temporário do quick tunnel ou a Opção 2 (Vercel).

---

## Checklist pós-publicação

- [ ] Abre o endereço **https** no iPhone → ecrã de boas-vindas aparece
- [ ] «Ativar localização» pede permissão (HTTPS obrigatório)
- [ ] Safari → Partilhar → **Adicionar ao Ecrã Principal**
- [ ] App aberta pelo ícone → Definições → Notificações → autorizar (iOS 16.4+)
- [ ] Android → Chrome → ⋮ → **Instalar aplicação**
- [ ] Comunidade: publica um comentário e confirma que outro aparelho o vê
- [ ] Definições → Aparência → Claro/Escuro/Automático funciona no telemóvel
