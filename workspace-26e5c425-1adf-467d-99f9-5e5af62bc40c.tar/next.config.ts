import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Evitar que o indicador de dev sobreponha a doca de navegação em iOS/Android.
  devIndicators: false,
};

export default nextConfig;
